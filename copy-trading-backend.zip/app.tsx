"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Terminal } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function App() {
  const [isInstalling, setIsInstalling] = useState(false)
  const [isInstalled, setIsInstalled] = useState(false)

  const handleInstall = () => {
    setIsInstalling(true)
    // Simulate installation process
    setTimeout(() => {
      setIsInstalling(false)
      setIsInstalled(true)
    }, 2000)
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-2xl">Copy Trading Platform Backend</CardTitle>
          <CardDescription>
            A scalable backend structure for a real-time copy trading platform with REST API and WebSockets
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="structure">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="structure">Project Structure</TabsTrigger>
              <TabsTrigger value="setup">Setup Guide</TabsTrigger>
              <TabsTrigger value="api">API Overview</TabsTrigger>
            </TabsList>
            <TabsContent value="structure" className="mt-6">
              <div className="bg-muted p-4 rounded-md font-mono text-sm overflow-auto max-h-[400px]">
                <pre>
                  {`📁 backend/
  ├── 📁 src/
  │   ├── 📁 api/
  │   │   ├── 📁 controllers/
  │   │   │   ├── 📄 auth.controller.js
  │   │   │   ├── 📄 user.controller.js
  │   │   │   ├── 📄 trader.controller.js
  │   │   │   ├── 📄 broker.controller.js
  │   │   │   └── 📄 trade.controller.js
  │   │   ├── 📁 middlewares/
  │   │   │   ├── 📄 auth.middleware.js
  │   │   │   ├── 📄 error.middleware.js
  │   │   │   ├── 📄 validation.middleware.js
  │   │   │   └── 📄 rate-limit.middleware.js
  │   │   ├── 📁 routes/
  │   │   │   ├── 📄 auth.routes.js
  │   │   │   ├── 📄 user.routes.js
  │   │   │   ├── 📄 trader.routes.js
  │   │   │   ├── 📄 broker.routes.js
  │   │   │   └── 📄 trade.routes.js
  │   │   └── 📄 index.js
  │   ├── 📁 config/
  │   │   ├── 📄 database.js
  │   │   ├── 📄 env.js
  │   │   └── 📄 logger.js
  │   ├── 📁 models/
  │   │   ├── 📄 user.model.js
  │   │   ├── 📄 trader.model.js
  │   │   ├── 📄 broker.model.js
  │   │   ├── 📄 trade.model.js
  │   │   └── 📄 portfolio.model.js
  │   ├── 📁 services/
  │   │   ├── 📄 auth.service.js
  │   │   ├── 📄 user.service.js
  │   │   ├── 📄 trader.service.js
  │   │   ├── 📄 broker.service.js
  │   │   └── 📄 trade.service.js
  │   ├── 📁 utils/
  │   │   ├── 📄 errors.js
  │   │   ├── 📄 validators.js
  │   │   └── 📄 helpers.js
  │   ├── 📁 websockets/
  │   │   ├── 📄 handlers/
  │   │   │   ├── 📄 trade.handler.js
  │   │   │   ├── 📄 market.handler.js
  │   │   │   └── 📄 notification.handler.js
  │   │   ├── 📄 middleware.js
  │   │   └── 📄 index.js
  │   ├── 📁 brokers/
  │   │   ├── 📁 adapters/
  │   │   │   ├── 📄 schwab.adapter.js
  │   │   │   ├── 📄 tastytrade.adapter.js
  │   │   │   ├── 📄 binance.adapter.js
  │   │   │   └── 📄 oanda.adapter.js
  │   │   ├── 📄 broker.factory.js
  │   │   └── 📄 base.broker.js
  │   ├── 📁 trading/
  │   │   ├── 📄 copy-engine.js
  │   │   ├── 📄 risk-manager.js
  │   │   └── 📄 order-processor.js
  │   ├── 📁 notifications/
  │   │   ├── 📄 email.service.js
  │   │   ├── 📄 sms.service.js
  │   │   └── 📄 notification.factory.js
  │   └── 📄 app.js
  ├── 📄 package.json
  ├── 📄 .env.example
  ├── 📄 .gitignore
  ├── 📄 README.md
  └── 📄 server.js`}
                </pre>
              </div>
            </TabsContent>
            <TabsContent value="setup" className="space-y-4 mt-6">
              <Alert>
                <Terminal className="h-4 w-4" />
                <AlertTitle>Installation</AlertTitle>
                <AlertDescription>Follow these steps to set up your copy trading platform backend.</AlertDescription>
              </Alert>

              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">1. Clone the repository and install dependencies</h3>
                  <div className="bg-muted p-3 rounded-md font-mono text-sm">
                    <code>
                      git clone https://github.com/yourusername/copy-trading-platform.git
                      <br />
                      cd copy-trading-platform/backend
                      <br />
                      npm install
                    </code>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">2. Set up environment variables</h3>
                  <div className="bg-muted p-3 rounded-md font-mono text-sm">
                    <code>
                      cp .env.example .env
                      <br /># Edit .env with your configuration
                    </code>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">3. Start the development server</h3>
                  <div className="bg-muted p-3 rounded-md font-mono text-sm">
                    <code>npm run dev</code>
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="api" className="mt-6">
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">REST API Endpoints</h3>
                  <div className="bg-muted p-3 rounded-md font-mono text-sm">
                    <code>
                      # Authentication
                      <br />
                      POST /api/auth/register
                      <br />
                      POST /api/auth/login
                      <br />
                      POST /api/auth/refresh-token
                      <br />
                      <br /># Users
                      <br />
                      GET /api/users/profile
                      <br />
                      PUT /api/users/profile
                      <br />
                      <br /># Traders
                      <br />
                      GET /api/traders
                      <br />
                      GET /api/traders/:id
                      <br />
                      POST /api/traders/follow/:id
                      <br />
                      DELETE /api/traders/unfollow/:id
                      <br />
                      <br /># Brokers
                      <br />
                      GET /api/brokers
                      <br />
                      POST /api/brokers/connect
                      <br />
                      DELETE /api/brokers/:id
                      <br />
                      <br /># Trades
                      <br />
                      GET /api/trades
                      <br />
                      POST /api/trades
                      <br />
                      GET /api/trades/:id
                      <br />
                    </code>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">WebSocket Events</h3>
                  <div className="bg-muted p-3 rounded-md font-mono text-sm">
                    <code>
                      # Market Data
                      <br />
                      market:subscribe
                      <br />
                      market:unsubscribe
                      <br />
                      market:data
                      <br />
                      <br /># Trades
                      <br />
                      trade:new
                      <br />
                      trade:update
                      <br />
                      trade:close
                      <br />
                      <br /># Portfolio
                      <br />
                      portfolio:update
                      <br />
                      <br /># Notifications
                      <br />
                      notification:new
                      <br />
                    </code>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter>
          {!isInstalled ? (
            <Button onClick={handleInstall} disabled={isInstalling} className="w-full">
              {isInstalling ? "Installing..." : "Install Backend Boilerplate"}
            </Button>
          ) : (
            <Alert className="w-full bg-green-50 border-green-200">
              <AlertTitle className="text-green-800">Installation Complete</AlertTitle>
              <AlertDescription className="text-green-700">
                The backend boilerplate has been successfully installed.
              </AlertDescription>
            </Alert>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
