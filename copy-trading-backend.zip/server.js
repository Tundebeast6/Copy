/**
 * Copy Trading Platform - Server Entry Point
 *
 * This is the main entry point for the copy trading platform backend.
 * It initializes the Express app, connects to MongoDB, and sets up WebSockets.
 */

// Load environment variables
require("dotenv").config()

// Import dependencies
const http = require("http")
const app = require("./src/app")
const { connectDatabase } = require("./src/config/database")
const { setupWebSocketServer } = require("./src/websockets")
const logger = require("./src/config/logger")

// Create HTTP server
const server = http.createServer(app)

// Set port
const PORT = process.env.PORT || 5000

// Initialize WebSocket server
setupWebSocketServer(server)

// Start server
async function startServer() {
  try {
    // Connect to MongoDB
    await connectDatabase()

    // Start listening
    server.listen(PORT, () => {
      logger.info(`Server running on port ${PORT}`)
      logger.info(`Environment: ${process.env.NODE_ENV}`)
      logger.info("WebSocket server initialized")
    })
  } catch (error) {
    logger.error("Failed to start server:", error)
    process.exit(1)
  }
}

// Handle uncaught exceptions
process.on("uncaughtException", (error) => {
  logger.error("Uncaught Exception:", error)
  process.exit(1)
})

// Handle unhandled promise rejections
process.on("unhandledRejection", (reason, promise) => {
  logger.error("Unhandled Rejection at:", promise, "reason:", reason)
  process.exit(1)
})

// Start the server
startServer()
