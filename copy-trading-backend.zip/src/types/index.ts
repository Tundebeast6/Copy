// User types
export interface User {
  id: string
  email: string
  firstName: string
  lastName: string
  role: "admin" | "trader" | "follower"
  profilePicture?: string
  isEmailVerified: boolean
  isKycVerified: boolean
  createdAt: string
  updatedAt: string
}

// Trader types
export interface Trader {
  _id: string
  userId: {
    _id: string
    firstName: string
    lastName: string
    email: string
    profilePicture?: string
  }
  bio: string
  experience: "beginner" | "intermediate" | "advanced" | "professional"
  tradingStyle: "day" | "swing" | "position" | "scalping" | "algorithmic"
  riskLevel: "conservative" | "moderate" | "aggressive"
  performanceFee: number
  isVerified: boolean
  isActive: boolean
  followers: string[]
  followersCount: number
  totalTrades: number
  winRate: number
  averageProfit: number
  profitLossRatio: number
  maxDrawdown: number
  preferredAssets: string[]
  socialLinks: {
    twitter?: string
    linkedin?: string
    website?: string
  }
  createdAt: string
  updatedAt: string
}

// Trade types
export interface Trade {
  _id: string
  traderId: string
  brokerId: string
  symbol: string
  assetClass: "stock" | "option" | "forex" | "crypto" | "future" | "commodity"
  direction: "long" | "short"
  orderType: "market" | "limit" | "stop" | "stop_limit"
  status: "pending" | "open" | "closed" | "cancelled" | "rejected"
  quantity: number
  entryPrice: number
  exitPrice?: number
  stopLoss?: number
  takeProfit?: number
  entryTime?: string
  exitTime?: string
  profit: number
  profitPercentage: number
  notes?: string
  tags?: string[]
  isPublic: boolean
  copiedBy: {
    userId: string
    status: "pending" | "copied" | "failed"
    quantity: number
    entryPrice: number
    exitPrice?: number
    profit: number
  }[]
  createdAt: string
  updatedAt: string
}

// Broker types
export interface Broker {
  _id: string
  userId: string
  name: "schwab" | "tastytrade" | "oanda" | "binance"
  label: string
  isActive: boolean
  accountId: string
  accountType: "demo" | "live"
  balance: number
  currency: string
  lastSynced: string
  supportedAssets: string[]
  status: "connected" | "disconnected" | "error"
  errorMessage?: string
  createdAt: string
  updatedAt: string
}

// Portfolio types
export interface Portfolio {
  _id: string
  userId: string
  balance: number
  equity: number
  allocatedBalance: number
  availableBalance: number
  currency: string
  positions: Position[]
  performance: {
    daily: PerformanceMetric
    weekly: PerformanceMetric
    monthly: PerformanceMetric
    yearly: PerformanceMetric
    allTime: PerformanceMetric
  }
  stats: {
    totalTrades: number
    winningTrades: number
    losingTrades: number
    winRate: number
    averageWin: number
    averageLoss: number
    profitFactor: number
    maxDrawdown: number
    sharpeRatio: number
  }
  lastUpdated: string
  createdAt: string
  updatedAt: string
}

export interface Position {
  symbol: string
  assetClass: "stock" | "option" | "forex" | "crypto" | "future" | "commodity"
  direction: "long" | "short"
  quantity: number
  entryPrice: number
  currentPrice: number
  marketValue: number
  unrealizedPL: number
  unrealizedPLPercent: number
  openTime: string
  trades: string[]
}

export interface PerformanceMetric {
  date?: string
  startDate?: string
  endDate?: string
  month?: number
  year?: number
  balance: number
  profit: number
  profitPercent: number
}

// WebSocket types
export interface MarketData {
  symbol: string
  bid: number
  ask: number
  last: number
  change: number
  volume: number
  time: string
}

export interface Notification {
  id: string
  type: "trade" | "system" | "follow" | "account"
  title: string
  message: string
  isRead: boolean
  createdAt: string
}
