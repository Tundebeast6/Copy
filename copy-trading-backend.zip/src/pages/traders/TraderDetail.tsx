"use client"

import { useState, useEffect } from "react"
import { useParams, Link } from "react-router-dom"
import { useWebSocket } from "../../contexts/WebSocketContext"
import { fetchTraderById, followTrader, unfollowTrader } from "../../services/api"
import type { Trader, Trade } from "../../types"
import TraderHeader from "../../components/traders/TraderHeader"
import TraderStats from "../../components/traders/TraderStats"
import TraderPerformance from "../../components/traders/TraderPerformance"
import TradesList from "../../components/trades/TradesList"
import CopySettingsModal from "../../components/traders/CopySettingsModal"
import LoadingSpinner from "../../components/common/LoadingSpinner"
import { toast } from "react-hot-toast"

const TraderDetail = () => {
  const { id } = useParams<{ id: string }>()
  const { subscribeToTrader, unsubscribeFromTrader, trades } = useWebSocket()
  const [trader, setTrader] = useState<Trader | null>(null)
  const [traderTrades, setTraderTrades] = useState<Trade[]>([])
  const [loading, setLoading] = useState(true)
  const [following, setFollowing] = useState(false)
  const [showCopySettings, setShowCopySettings] = useState(false)

  useEffect(() => {
    const loadTraderData = async () => {
      try {
        setLoading(true)
        if (!id) return

        const traderData = await fetchTraderById(id)
        setTrader(traderData)

        // Check if user is following this trader
        setFollowing(traderData.followers.includes(localStorage.getItem("userId")))

        // Subscribe to trader's trades via WebSocket
        subscribeToTrader(id)
      } catch (error) {
        console.error("Error loading trader data:", error)
        toast.error("Failed to load trader data")
      } finally {
        setLoading(false)
      }
    }

    loadTraderData()

    // Cleanup WebSocket subscription
    return () => {
      if (id) {
        unsubscribeFromTrader(id)
      }
    }
  }, [id, subscribeToTrader, unsubscribeFromTrader])

  // Update trades when WebSocket receives new data
  useEffect(() => {
    if (id && trades[id]) {
      setTraderTrades(trades[id])
    }
  }, [id, trades])

  const handleFollow = async () => {
    try {
      if (!id) return

      if (following) {
        await unfollowTrader(id)
        setFollowing(false)
        toast.success("Unfollowed trader successfully")
      } else {
        setShowCopySettings(true)
      }
    } catch (error) {
      console.error("Error following/unfollowing trader:", error)
      toast.error("Failed to follow/unfollow trader")
    }
  }

  const handleCopySettingsSubmit = async (settings: any) => {
    try {
      if (!id) return

      await followTrader(id, settings)
      setFollowing(true)
      setShowCopySettings(false)
      toast.success("Now following trader")
    } catch (error) {
      console.error("Error following trader:", error)
      toast.error("Failed to follow trader")
    }
  }

  if (loading) {
    return <LoadingSpinner />
  }

  if (!trader) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Trader not found</h2>
        <p className="mb-4">The trader you're looking for doesn't exist or has been removed.</p>
        <Link to="/traders" className="text-blue-600 hover:text-blue-800">
          Back to Traders List
        </Link>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <TraderHeader trader={trader} following={following} onFollowClick={handleFollow} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
        {/* Main content - 2/3 width on large screens */}
        <div className="lg:col-span-2 space-y-6">
          <TraderPerformance trader={trader} />

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Recent Trades</h2>
            </div>
            <TradesList trades={traderTrades} />
          </div>
        </div>

        {/* Sidebar - 1/3 width on large screens */}
        <div className="space-y-6">
          <TraderStats trader={trader} />

          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">About</h2>
            <p className="text-gray-700">{trader.bio}</p>

            {trader.socialLinks && Object.keys(trader.socialLinks).length > 0 && (
              <div className="mt-4">
                <h3 className="text-lg font-medium mb-2">Social Links</h3>
                <div className="flex space-x-4">
                  {trader.socialLinks.twitter && (
                    <a
                      href={trader.socialLinks.twitter}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:text-blue-700"
                    >
                      <i className="fab fa-twitter"></i> Twitter
                    </a>
                  )}
                  {trader.socialLinks.linkedin && (
                    <a
                      href={trader.socialLinks.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:text-blue-700"
                    >
                      <i className="fab fa-linkedin"></i> LinkedIn
                    </a>
                  )}
                  {trader.socialLinks.website && (
                    <a
                      href={trader.socialLinks.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:text-blue-700"
                    >
                      <i className="fas fa-globe"></i> Website
                    </a>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Copy Settings Modal */}
      <CopySettingsModal
        show={showCopySettings}
        onClose={() => setShowCopySettings(false)}
        onSubmit={handleCopySettingsSubmit}
      />
    </div>
  )
}

export default TraderDetail
