"use client"

import { useState, useEffect } from "react"
import { Link } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"
import { useWebSocket } from "../../contexts/WebSocketContext"
import { fetchPortfolio, fetchTrades } from "../../services/api"
import DashboardHeader from "../../components/dashboard/DashboardHeader"
import PortfolioSummary from "../../components/dashboard/PortfolioSummary"
import TradesList from "../../components/trades/TradesList"
import MarketOverview from "../../components/dashboard/MarketOverview"
import FollowedTraders from "../../components/dashboard/FollowedTraders"
import NotificationsList from "../../components/dashboard/NotificationsList"
import LoadingSpinner from "../../components/common/LoadingSpinner"

const Dashboard = () => {
  const { user } = useAuth()
  const { subscribeToMarket, notifications } = useWebSocket()
  const [portfolio, setPortfolio] = useState(null)
  const [recentTrades, setRecentTrades] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true)
        const [portfolioData, tradesData] = await Promise.all([fetchPortfolio(), fetchTrades({ limit: 5 })])

        setPortfolio(portfolioData)
        setRecentTrades(tradesData.trades)

        // Subscribe to market data for common symbols
        subscribeToMarket(["BTC/USDT", "ETH/USDT", "EUR/USD", "AAPL", "MSFT"])
      } catch (error) {
        console.error("Error loading dashboard data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadDashboardData()
  }, [subscribeToMarket])

  if (loading) {
    return <LoadingSpinner />
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <DashboardHeader user={user} portfolio={portfolio} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
        {/* Main content - 2/3 width on large screens */}
        <div className="lg:col-span-2 space-y-6">
          <PortfolioSummary portfolio={portfolio} />

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Recent Trades</h2>
              <Link to="/trades" className="text-blue-600 hover:text-blue-800">
                View All
              </Link>
            </div>
            <TradesList trades={recentTrades} />
          </div>

          <MarketOverview />
        </div>

        {/* Sidebar - 1/3 width on large screens */}
        <div className="space-y-6">
          <FollowedTraders />

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Notifications</h2>
              <button className="text-sm text-blue-600 hover:text-blue-800">Mark All as Read</button>
            </div>
            <NotificationsList notifications={notifications.slice(0, 5)} />
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
