"use client"

import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from "react-router-dom"
import { Suspense, lazy, useEffect } from "react"
import { Toaster } from "react-hot-toast"
import { ErrorBoundary } from "@sentry/react"
import { AuthProvider, useAuth } from "./contexts/AuthContext"
import { WebSocketProvider } from "./contexts/WebSocketContext"
import Navbar from "./components/layout/Navbar"
import Footer from "./components/layout/Footer"
import LoadingSpinner from "./components/common/LoadingSpinner"
import ErrorFallback from "./components/common/ErrorFallback"
import { useApiMetrics } from "./hooks/useApiMetrics"
import { trackPageView, setUserContext, clearUserContext } from "./monitoring/analytics"

// Lazy load pages for better performance
const Home = lazy(() => import("./pages/Home"))
const Login = lazy(() => import("./pages/auth/Login"))
const Register = lazy(() => import("./pages/auth/Register"))
const Dashboard = lazy(() => import("./pages/dashboard/Dashboard"))
const TradersList = lazy(() => import("./pages/traders/TradersList"))
const TraderDetail = lazy(() => import("./pages/traders/TraderDetail"))
const Portfolio = lazy(() => import("./pages/portfolio/Portfolio"))
const Trades = lazy(() => import("./pages/trades/Trades"))
const BrokerConnections = lazy(() => import("./pages/brokers/BrokerConnections"))
const Settings = lazy(() => import("./pages/settings/Settings"))
const AdminDashboard = lazy(() => import("./pages/admin/AdminDashboard"))
const AdminUsers = lazy(() => import("./pages/admin/AdminUsers"))
const AdminTraders = lazy(() => import("./pages/admin/AdminTraders"))
const NotFound = lazy(() => import("./pages/NotFound"))

// Protected route component
const ProtectedRoute = ({ children, requiredRole = null }: { children: JSX.Element; requiredRole?: string | null }) => {
  const { user, loading } = useAuth()

  if (loading) {
    return <LoadingSpinner />
  }

  if (!user) {
    return <Navigate to="/login" replace />
  }

  if (requiredRole && user.role !== requiredRole) {
    return <Navigate to="/dashboard" replace />
  }

  return children
}

// Analytics tracker component
const AnalyticsTracker = () => {
  const location = useLocation()
  const { user } = useAuth()

  // Track page views
  useEffect(() => {
    trackPageView(location.pathname)
  }, [location])

  // Set user context for monitoring
  useEffect(() => {
    if (user) {
      setUserContext({
        id: user.id,
        email: user.email,
        role: user.role,
      })
    } else {
      clearUserContext()
    }
  }, [user])

  return null
}

function App() {
  // Initialize API metrics tracking
  useApiMetrics()

  return (
    <ErrorBoundary fallback={<ErrorFallback />}>
      <AuthProvider>
        <WebSocketProvider>
          <Router>
            <AnalyticsTracker />
            <div className="flex flex-col min-h-screen">
              <Navbar />
              <main className="flex-grow">
                <Suspense fallback={<LoadingSpinner />}>
                  <Routes>
                    {/* Public routes */}
                    <Route path="/" element={<Home />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />

                    {/* Protected routes */}
                    <Route
                      path="/dashboard"
                      element={
                        <ProtectedRoute>
                          <Dashboard />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/traders"
                      element={
                        <ProtectedRoute>
                          <TradersList />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/traders/:id"
                      element={
                        <ProtectedRoute>
                          <TraderDetail />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/portfolio"
                      element={
                        <ProtectedRoute>
                          <Portfolio />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/trades"
                      element={
                        <ProtectedRoute>
                          <Trades />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/brokers"
                      element={
                        <ProtectedRoute>
                          <BrokerConnections />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/settings"
                      element={
                        <ProtectedRoute>
                          <Settings />
                        </ProtectedRoute>
                      }
                    />

                    {/* Admin routes */}
                    <Route
                      path="/admin/dashboard"
                      element={
                        <ProtectedRoute requiredRole="admin">
                          <AdminDashboard />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/admin/users"
                      element={
                        <ProtectedRoute requiredRole="admin">
                          <AdminUsers />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/admin/traders"
                      element={
                        <ProtectedRoute requiredRole="admin">
                          <AdminTraders />
                        </ProtectedRoute>
                      }
                    />

                    {/* 404 route */}
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </Suspense>
              </main>
              <Footer />
            </div>
          </Router>
          <Toaster position="top-right" />
        </WebSocketProvider>
      </AuthProvider>
    </ErrorBoundary>
  )
}

export default App
