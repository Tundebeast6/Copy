/**
 * Broker Model
 *
 * This file defines the Broker schema and model for MongoDB.
 * Brokers represent trading platforms connected to user accounts.
 */

const mongoose = require("mongoose")
const { encrypt, decrypt } = require("../utils/encryption")

const brokerSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    name: {
      type: String,
      required: true,
      enum: ["schwab", "tastytrade", "oanda", "binance"],
      trim: true,
    },
    label: {
      type: String,
      required: true,
      trim: true,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    credentials: {
      // Encrypted credentials
      apiKey: {
        type: String,
        required: function () {
          return ["oanda", "binance"].includes(this.name)
        },
      },
      apiSecret: {
        type: String,
        required: function () {
          return ["binance"].includes(this.name)
        },
      },
      accessToken: {
        type: String,
        required: function () {
          return ["schwab", "tastytrade"].includes(this.name)
        },
      },
      refreshToken: {
        type: String,
        required: function () {
          return ["schwab", "tastytrade"].includes(this.name)
        },
      },
      tokenExpiry: {
        type: Date,
        required: function () {
          return ["schwab", "tastytrade"].includes(this.name)
        },
      },
    },
    accountId: {
      type: String,
      required: true,
      trim: true,
    },
    accountType: {
      type: String,
      enum: ["demo", "live"],
      default: "demo",
    },
    balance: {
      type: Number,
      default: 0,
    },
    currency: {
      type: String,
      default: "USD",
      trim: true,
    },
    lastSynced: {
      type: Date,
      default: Date.now,
    },
    supportedAssets: [
      {
        type: String,
        enum: ["stocks", "options", "forex", "crypto", "futures", "commodities"],
      },
    ],
    status: {
      type: String,
      enum: ["connected", "disconnected", "error"],
      default: "connected",
    },
    errorMessage: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
  },
)

// Encrypt sensitive data before saving
brokerSchema.pre("save", function (next) {
  if (this.isModified("credentials.apiKey") && this.credentials.apiKey) {
    this.credentials.apiKey = encrypt(this.credentials.apiKey)
  }

  if (this.isModified("credentials.apiSecret") && this.credentials.apiSecret) {
    this.credentials.apiSecret = encrypt(this.credentials.apiSecret)
  }

  if (this.isModified("credentials.accessToken") && this.credentials.accessToken) {
    this.credentials.accessToken = encrypt(this.credentials.accessToken)
  }

  if (this.isModified("credentials.refreshToken") && this.credentials.refreshToken) {
    this.credentials.refreshToken = encrypt(this.credentials.refreshToken)
  }

  next()
})

// Method to get decrypted credentials
brokerSchema.methods.getDecryptedCredentials = function () {
  const decrypted = { ...this.credentials }

  if (decrypted.apiKey) {
    decrypted.apiKey = decrypt(decrypted.apiKey)
  }

  if (decrypted.apiSecret) {
    decrypted.apiSecret = decrypt(decrypted.apiSecret)
  }

  if (decrypted.accessToken) {
    decrypted.accessToken = decrypt(decrypted.accessToken)
  }

  if (decrypted.refreshToken) {
    decrypted.refreshToken = decrypt(decrypted.refreshToken)
  }

  return decrypted
}

// Indexes for faster queries
brokerSchema.index({ userId: 1, name: 1 })
brokerSchema.index({ isActive: 1 })

const Broker = mongoose.model("Broker", brokerSchema)

module.exports = Broker
