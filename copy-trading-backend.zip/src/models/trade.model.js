/**
 * Trade Model
 *
 * This file defines the Trade schema and model for MongoDB.
 * Trades represent individual trading positions opened by traders.
 */

const mongoose = require("mongoose")

const tradeSchema = new mongoose.Schema(
  {
    traderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Trader",
      required: true,
    },
    brokerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Broker",
      required: true,
    },
    symbol: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },
    assetClass: {
      type: String,
      enum: ["stock", "option", "forex", "crypto", "future", "commodity"],
      required: true,
    },
    direction: {
      type: String,
      enum: ["long", "short"],
      required: true,
    },
    orderType: {
      type: String,
      enum: ["market", "limit", "stop", "stop_limit"],
      default: "market",
    },
    status: {
      type: String,
      enum: ["pending", "open", "closed", "cancelled", "rejected"],
      default: "pending",
    },
    quantity: {
      type: Number,
      required: true,
      min: 0,
    },
    entryPrice: {
      type: Number,
      min: 0,
    },
    exitPrice: {
      type: Number,
      min: 0,
    },
    stopLoss: {
      type: Number,
      min: 0,
    },
    takeProfit: {
      type: Number,
      min: 0,
    },
    entryTime: {
      type: Date,
    },
    exitTime: {
      type: Date,
    },
    profit: {
      type: Number,
      default: 0,
    },
    profitPercentage: {
      type: Number,
      default: 0,
    },
    notes: {
      type: String,
      trim: true,
      maxlength: 500,
    },
    tags: [
      {
        type: String,
        trim: true,
      },
    ],
    brokerOrderId: {
      type: String,
      trim: true,
    },
    brokerTradeId: {
      type: String,
      trim: true,
    },
    isPublic: {
      type: Boolean,
      default: true,
    },
    copiedBy: [
      {
        userId: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        status: {
          type: String,
          enum: ["pending", "copied", "failed"],
          default: "pending",
        },
        quantity: {
          type: Number,
          min: 0,
        },
        entryPrice: {
          type: Number,
          min: 0,
        },
        exitPrice: {
          type: Number,
          min: 0,
        },
        profit: {
          type: Number,
          default: 0,
        },
        brokerOrderId: {
          type: String,
          trim: true,
        },
      },
    ],
  },
  {
    timestamps: true,
  },
)

// Calculate profit when trade is closed
tradeSchema.pre("save", function (next) {
  if (this.status === "closed" && this.entryPrice && this.exitPrice && this.quantity) {
    if (this.direction === "long") {
      this.profit = (this.exitPrice - this.entryPrice) * this.quantity
      this.profitPercentage = ((this.exitPrice - this.entryPrice) / this.entryPrice) * 100
    } else {
      this.profit = (this.entryPrice - this.exitPrice) * this.quantity
      this.profitPercentage = ((this.entryPrice - this.exitPrice) / this.entryPrice) * 100
    }
  }
  next()
})

// Indexes for faster queries
tradeSchema.index({ traderId: 1, status: 1 })
tradeSchema.index({ symbol: 1, assetClass: 1 })
tradeSchema.index({ createdAt: -1 })

const Trade = mongoose.model("Trade", tradeSchema)

module.exports = Trade
