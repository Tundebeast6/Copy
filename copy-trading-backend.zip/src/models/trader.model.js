/**
 * Trader Model
 *
 * This file defines the Trader schema and model for MongoDB.
 * Traders are users who share their trades for others to copy.
 */

const mongoose = require("mongoose")

const traderSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      unique: true,
    },
    bio: {
      type: String,
      trim: true,
      maxlength: [500, "Bio cannot be more than 500 characters"],
    },
    experience: {
      type: String,
      enum: ["beginner", "intermediate", "advanced", "professional"],
      default: "intermediate",
    },
    tradingStyle: {
      type: String,
      enum: ["day", "swing", "position", "scalping", "algorithmic"],
      default: "swing",
    },
    riskLevel: {
      type: String,
      enum: ["conservative", "moderate", "aggressive"],
      default: "moderate",
    },
    performanceFee: {
      type: Number,
      min: 0,
      max: 50,
      default: 20,
    },
    isVerified: {
      type: Boolean,
      default: false,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
    followers: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    followersCount: {
      type: Number,
      default: 0,
    },
    totalTrades: {
      type: Number,
      default: 0,
    },
    winRate: {
      type: Number,
      min: 0,
      max: 100,
      default: 0,
    },
    averageProfit: {
      type: Number,
      default: 0,
    },
    profitLossRatio: {
      type: Number,
      default: 0,
    },
    maxDrawdown: {
      type: Number,
      default: 0,
    },
    preferredAssets: [
      {
        type: String,
        enum: ["stocks", "options", "forex", "crypto", "futures", "commodities"],
      },
    ],
    socialLinks: {
      twitter: String,
      linkedin: String,
      website: String,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  },
)

// Virtual for trader's full name
traderSchema.virtual("fullName").get(function () {
  return `${this.user?.firstName || ""} ${this.user?.lastName || ""}`
})

// Virtual for trader's performance metrics
traderSchema.virtual("performance").get(function () {
  return {
    winRate: this.winRate,
    averageProfit: this.averageProfit,
    profitLossRatio: this.profitLossRatio,
    maxDrawdown: this.maxDrawdown,
  }
})

// Pre-save middleware to update followers count
traderSchema.pre("save", function (next) {
  if (this.isModified("followers")) {
    this.followersCount = this.followers.length
  }
  next()
})

// Index for faster queries
traderSchema.index({ userId: 1 })
traderSchema.index({ isActive: 1, isVerified: 1 })
traderSchema.index({ winRate: -1, followersCount: -1 })

const Trader = mongoose.model("Trader", traderSchema)

module.exports = Trader
