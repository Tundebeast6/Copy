/**
 * Portfolio Model
 *
 * This file defines the Portfolio schema and model for MongoDB.
 * Portfolios track user's trading performance and positions.
 */

const mongoose = require("mongoose")

const portfolioSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      unique: true,
    },
    balance: {
      type: Number,
      default: 0,
    },
    equity: {
      type: Number,
      default: 0,
    },
    allocatedBalance: {
      type: Number,
      default: 0,
    },
    availableBalance: {
      type: Number,
      default: 0,
    },
    currency: {
      type: String,
      default: "USD",
      trim: true,
    },
    positions: [
      {
        symbol: {
          type: String,
          required: true,
          trim: true,
          uppercase: true,
        },
        assetClass: {
          type: String,
          enum: ["stock", "option", "forex", "crypto", "future", "commodity"],
          required: true,
        },
        direction: {
          type: String,
          enum: ["long", "short"],
          required: true,
        },
        quantity: {
          type: Number,
          required: true,
          min: 0,
        },
        entryPrice: {
          type: Number,
          required: true,
          min: 0,
        },
        currentPrice: {
          type: Number,
          required: true,
          min: 0,
        },
        marketValue: {
          type: Number,
          default: 0,
        },
        unrealizedPL: {
          type: Number,
          default: 0,
        },
        unrealizedPLPercent: {
          type: Number,
          default: 0,
        },
        openTime: {
          type: Date,
          default: Date.now,
        },
        trades: [
          {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Trade",
          },
        ],
      },
    ],
    performance: {
      daily: {
        date: Date,
        balance: Number,
        profit: Number,
        profitPercent: Number,
      },
      weekly: {
        startDate: Date,
        endDate: Date,
        balance: Number,
        profit: Number,
        profitPercent: Number,
      },
      monthly: {
        month: Number,
        year: Number,
        balance: Number,
        profit: Number,
        profitPercent: Number,
      },
      yearly: {
        year: Number,
        balance: Number,
        profit: Number,
        profitPercent: Number,
      },
      allTime: {
        startDate: Date,
        balance: Number,
        profit: Number,
        profitPercent: Number,
      },
    },
    stats: {
      totalTrades: {
        type: Number,
        default: 0,
      },
      winningTrades: {
        type: Number,
        default: 0,
      },
      losingTrades: {
        type: Number,
        default: 0,
      },
      winRate: {
        type: Number,
        default: 0,
      },
      averageWin: {
        type: Number,
        default: 0,
      },
      averageLoss: {
        type: Number,
        default: 0,
      },
      profitFactor: {
        type: Number,
        default: 0,
      },
      maxDrawdown: {
        type: Number,
        default: 0,
      },
      sharpeRatio: {
        type: Number,
        default: 0,
      },
    },
    lastUpdated: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  },
)

// Calculate available balance
portfolioSchema.pre("save", function (next) {
  this.availableBalance = this.balance - this.allocatedBalance

  // Calculate position values
  if (this.positions && this.positions.length > 0) {
    this.positions.forEach((position) => {
      position.marketValue = position.quantity * position.currentPrice

      if (position.direction === "long") {
        position.unrealizedPL = (position.currentPrice - position.entryPrice) * position.quantity
        position.unrealizedPLPercent = ((position.currentPrice - position.entryPrice) / position.entryPrice) * 100
      } else {
        position.unrealizedPL = (position.entryPrice - position.currentPrice) * position.quantity
        position.unrealizedPLPercent = ((position.entryPrice - position.currentPrice) / position.entryPrice) * 100
      }
    })
  }

  // Calculate equity
  const positionsValue = this.positions.reduce((total, position) => total + position.marketValue, 0)
  this.equity = this.balance + positionsValue

  // Update last updated timestamp
  this.lastUpdated = new Date()

  next()
})

// Calculate win rate
portfolioSchema.pre("save", function (next) {
  if (this.stats.totalTrades > 0) {
    this.stats.winRate = (this.stats.winningTrades / this.stats.totalTrades) * 100
  }

  if (this.stats.averageLoss !== 0) {
    this.stats.profitFactor = Math.abs(this.stats.averageWin / this.stats.averageLoss)
  }

  next()
})

// Indexes for faster queries
portfolioSchema.index({ userId: 1 })
portfolioSchema.index({ "positions.symbol": 1 })

const Portfolio = mongoose.model("Portfolio", portfolioSchema)

module.exports = Portfolio
