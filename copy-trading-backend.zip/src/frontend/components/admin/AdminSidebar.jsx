"use client"
import { Nav } from "react-bootstrap"
import { Link, useLocation } from "react-router-dom"
import { useAuth } from "../../contexts/AuthContext"

const AdminSidebar = () => {
  const location = useLocation()
  const { user } = useAuth()

  const isActive = (path) => {
    return location.pathname === path
  }

  return (
    <div className="bg-dark text-white min-vh-100">
      <div className="p-3 border-bottom border-secondary">
        <h5 className="mb-0">Admin Panel</h5>
      </div>
      <div className="p-3 border-bottom border-secondary">
        <div className="d-flex align-items-center">
          <img
            src={user?.profilePicture || "/default-avatar.png"}
            alt={user?.firstName}
            className="rounded-circle me-2"
            width="40"
            height="40"
          />
          <div>
            <div>{`${user?.firstName} ${user?.lastName}`}</div>
            <small className="text-muted">{user?.email}</small>
          </div>
        </div>
      </div>
      <Nav className="flex-column p-3">
        <Nav.Link
          as={Link}
          to="/admin/dashboard"
          className={`mb-2 ${isActive("/admin/dashboard") ? "bg-primary rounded" : "text-white"}`}
        >
          <i className="bi bi-speedometer2 me-2"></i>
          Dashboard
        </Nav.Link>
        <Nav.Link
          as={Link}
          to="/admin/users"
          className={`mb-2 ${isActive("/admin/users") ? "bg-primary rounded" : "text-white"}`}
        >
          <i className="bi bi-people me-2"></i>
          Users
        </Nav.Link>
        <Nav.Link
          as={Link}
          to="/admin/traders"
          className={`mb-2 ${isActive("/admin/traders") ? "bg-primary rounded" : "text-white"}`}
        >
          <i className="bi bi-graph-up me-2"></i>
          Traders
        </Nav.Link>
        <Nav.Link
          as={Link}
          to="/admin/trades"
          className={`mb-2 ${isActive("/admin/trades") ? "bg-primary rounded" : "text-white"}`}
        >
          <i className="bi bi-currency-exchange me-2"></i>
          Trades
        </Nav.Link>
        <Nav.Link
          as={Link}
          to="/admin/brokers"
          className={`mb-2 ${isActive("/admin/brokers") ? "bg-primary rounded" : "text-white"}`}
        >
          <i className="bi bi-building me-2"></i>
          Brokers
        </Nav.Link>
        <Nav.Link
          as={Link}
          to="/admin/settings"
          className={`mb-2 ${isActive("/admin/settings") ? "bg-primary rounded" : "text-white"}`}
        >
          <i className="bi bi-gear me-2"></i>
          Settings
        </Nav.Link>
        <hr className="my-3" />
        <Nav.Link as={Link} to="/" className="text-white">
          <i className="bi bi-arrow-left me-2"></i>
          Back to Platform
        </Nav.Link>
      </Nav>
    </div>
  )
}

export default AdminSidebar
