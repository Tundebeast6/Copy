"use client"

import { useState, useEffect } from "react"
import { Container, Row, Col, Card, Button, Table, Badge, Spinner } from "react-bootstrap"
import { Line } from "react-chartjs-2"
import { Link } from "react-router-dom"
import { useAuth } from "../contexts/AuthContext"
import { fetchTopTraders, fetchMarketData } from "../services/api"

const HomePage = () => {
  const { user } = useAuth()
  const [topTraders, setTopTraders] = useState([])
  const [marketData, setMarketData] = useState({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadData = async () => {
      try {
        const [tradersData, marketDataResponse] = await Promise.all([
          fetchTopTraders(),
          fetchMarketData(["BTC/USDT", "ETH/USDT", "EUR/USD", "AAPL", "MSFT"]),
        ])

        setTopTraders(tradersData.traders)
        setMarketData(marketDataResponse)
      } catch (error) {
        console.error("Error loading home page data:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  const chartData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    datasets: [
      {
        label: "Platform Trading Volume",
        data: [12, 19, 13, 15, 22, 27],
        fill: false,
        backgroundColor: "rgb(75, 192, 192)",
        borderColor: "rgba(75, 192, 192, 0.2)",
      },
    ],
  }

  if (loading) {
    return (
      <Container className="d-flex justify-content-center align-items-center" style={{ height: "80vh" }}>
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </Container>
    )
  }

  return (
    <Container className="py-5">
      {/* Hero Section */}
      <Row className="mb-5">
        <Col md={7}>
          <h1 className="display-4 fw-bold">Copy Trading Platform</h1>
          <p className="lead">
            Follow top traders and automatically copy their trades in real-time. Start building your portfolio with the
            wisdom of successful traders.
          </p>
          {!user ? (
            <div className="d-flex gap-3">
              <Button as={Link} to="/register" variant="primary" size="lg">
                Get Started
              </Button>
              <Button as={Link} to="/login" variant="outline-secondary" size="lg">
                Log In
              </Button>
            </div>
          ) : (
            <Button as={Link} to="/dashboard" variant="primary" size="lg">
              Go to Dashboard
            </Button>
          )}
        </Col>
        <Col md={5}>
          <Card className="shadow-sm">
            <Card.Body>
              <h5 className="card-title">Platform Statistics</h5>
              <div className="d-flex justify-content-between mb-3">
                <div className="text-center">
                  <h2>10,000+</h2>
                  <p className="text-muted">Users</p>
                </div>
                <div className="text-center">
                  <h2>500+</h2>
                  <p className="text-muted">Traders</p>
                </div>
                <div className="text-center">
                  <h2>$25M+</h2>
                  <p className="text-muted">Volume</p>
                </div>
              </div>
              <div style={{ height: "200px" }}>
                <Line data={chartData} options={{ maintainAspectRatio: false }} />
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Top Traders Section */}
      <Row className="mb-5">
        <Col>
          <Card className="shadow-sm">
            <Card.Header className="bg-white">
              <div className="d-flex justify-content-between align-items-center">
                <h4 className="mb-0">Top Performing Traders</h4>
                <Button as={Link} to="/traders" variant="outline-primary" size="sm">
                  View All
                </Button>
              </div>
            </Card.Header>
            <Card.Body>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>Trader</th>
                    <th>Win Rate</th>
                    <th>Profit</th>
                    <th>Followers</th>
                    <th>Style</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {topTraders.map((trader) => (
                    <tr key={trader._id}>
                      <td>
                        <div className="d-flex align-items-center">
                          <img
                            src={trader.userId.profilePicture || "/default-avatar.png"}
                            alt={trader.userId.firstName}
                            className="rounded-circle me-2"
                            width="40"
                            height="40"
                          />
                          <div>
                            <div>{`${trader.userId.firstName} ${trader.userId.lastName}`}</div>
                            <small className="text-muted">{trader.experience}</small>
                          </div>
                        </div>
                      </td>
                      <td>{trader.winRate.toFixed(2)}%</td>
                      <td className="text-success">+{trader.averageProfit.toFixed(2)}%</td>
                      <td>{trader.followersCount}</td>
                      <td>
                        <Badge bg="light" text="dark">
                          {trader.tradingStyle}
                        </Badge>
                      </td>
                      <td>
                        <Button as={Link} to={`/traders/${trader._id}`} variant="outline-primary" size="sm">
                          View
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Market Data Section */}
      <Row className="mb-5">
        <Col>
          <Card className="shadow-sm">
            <Card.Header className="bg-white">
              <h4 className="mb-0">Market Overview</h4>
            </Card.Header>
            <Card.Body>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>Symbol</th>
                    <th>Last Price</th>
                    <th>24h Change</th>
                    <th>24h Volume</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(marketData).map(([symbol, data]) => (
                    <tr key={symbol}>
                      <td>{symbol}</td>
                      <td>{data.last.toFixed(2)}</td>
                      <td className={data.change >= 0 ? "text-success" : "text-danger"}>
                        {data.change >= 0 ? "+" : ""}
                        {data.change.toFixed(2)}%
                      </td>
                      <td>{data.volume.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Features Section */}
      <Row className="mb-5">
        <Col md={4} className="mb-4">
          <Card className="h-100 shadow-sm">
            <Card.Body className="text-center p-4">
              <div className="mb-3">
                <i className="bi bi-graph-up-arrow" style={{ fontSize: "2rem", color: "#0d6efd" }}></i>
              </div>
              <h5>Follow Top Traders</h5>
              <p className="text-muted">
                Browse and follow top-performing traders based on their track record, trading style, and risk profile.
              </p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4} className="mb-4">
          <Card className="h-100 shadow-sm">
            <Card.Body className="text-center p-4">
              <div className="mb-3">
                <i className="bi bi-lightning-charge" style={{ fontSize: "2rem", color: "#0d6efd" }}></i>
              </div>
              <h5>Real-Time Copy Trading</h5>
              <p className="text-muted">
                Automatically copy trades from your followed traders in real-time with customizable risk management.
              </p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4} className="mb-4">
          <Card className="h-100 shadow-sm">
            <Card.Body className="text-center p-4">
              <div className="mb-3">
                <i className="bi bi-shield-check" style={{ fontSize: "2rem", color: "#0d6efd" }}></i>
              </div>
              <h5>Risk Management</h5>
              <p className="text-muted">
                Set your risk parameters, including position size, stop-loss, and maximum drawdown to protect your
                capital.
              </p>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* CTA Section */}
      <Row className="mb-5">
        <Col>
          <Card className="bg-primary text-white shadow">
            <Card.Body className="p-5 text-center">
              <h2>Ready to start your copy trading journey?</h2>
              <p className="lead">
                Join thousands of traders and followers on our platform and start building your portfolio today.
              </p>
              <Button as={Link} to="/register" variant="light" size="lg" className="mt-3">
                Create Free Account
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  )
}

export default HomePage
