"use client"

import { useState, useEffect } from "react"
import {
  Container,
  Row,
  Col,
  Card,
  Table,
  Button,
  Form,
  InputGroup,
  Pagination,
  Badge,
  Spinner,
  Alert,
  Modal,
} from "react-bootstrap"
import { useAuth } from "../../contexts/AuthContext"
import { fetchTraders, verifyTrader, suspendTrader } from "../../services/api"
import AdminSidebar from "../../components/admin/AdminSidebar"

const AdminTraders = () => {
  const { user } = useAuth()
  const [traders, setTraders] = useState([])
  const [filteredTraders, setFilteredTraders] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [selectedExperience, setSelectedExperience] = useState("all")
  const [selectedVerification, setSelectedVerification] = useState("all")
  const [showSuspendModal, setShowSuspendModal] = useState(false)
  const [traderToSuspend, setTraderToSuspend] = useState(null)

  const tradersPerPage = 10

  useEffect(() => {
    const loadTraders = async () => {
      try {
        const response = await fetchTraders()
        setTraders(response.traders)
        setFilteredTraders(response.traders)
        setTotalPages(Math.ceil(response.traders.length / tradersPerPage))
      } catch (error) {
        console.error("Error loading traders:", error)
        setError("Failed to load traders. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    loadTraders()
  }, [])

  useEffect(() => {
    // Filter traders based on search term, experience, and verification status
    let result = traders

    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      result = result.filter(
        (trader) =>
          trader.userId.email.toLowerCase().includes(term) ||
          trader.userId.firstName.toLowerCase().includes(term) ||
          trader.userId.lastName.toLowerCase().includes(term),
      )
    }

    if (selectedExperience !== "all") {
      result = result.filter((trader) => trader.experience === selectedExperience)
    }

    if (selectedVerification !== "all") {
      const isVerified = selectedVerification === "verified"
      result = result.filter((trader) => trader.isVerified === isVerified)
    }

    setFilteredTraders(result)
    setTotalPages(Math.ceil(result.length / tradersPerPage))
    setCurrentPage(1)
  }, [searchTerm, selectedExperience, selectedVerification, traders])

  const handleExperienceChange = (e) => {
    setSelectedExperience(e.target.value)
  }

  const handleVerificationChange = (e) => {
    setSelectedVerification(e.target.value)
  }

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value)
  }

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber)
  }

  const handleSuspendClick = (trader) => {
    setTraderToSuspend(trader)
    setShowSuspendModal(true)
  }

  const handleSuspendConfirm = async () => {
    try {
      await suspendTrader(traderToSuspend._id)
      setTraders(traders.map((t) => (t._id === traderToSuspend._id ? { ...t, isActive: false } : t)))
      setShowSuspendModal(false)
    } catch (error) {
      console.error("Error suspending trader:", error)
      setError("Failed to suspend trader. Please try again later.")
    }
  }

  const handleVerifyTrader = async (traderId, isVerified) => {
    try {
      await verifyTrader(traderId, isVerified)
      setTraders(traders.map((t) => (t._id === traderId ? { ...t, isVerified } : t)))
    } catch (error) {
      console.error("Error updating trader verification status:", error)
      setError("Failed to update trader verification status. Please try again later.")
    }
  }

  // Get current traders
  const indexOfLastTrader = currentPage * tradersPerPage
  const indexOfFirstTrader = indexOfLastTrader - tradersPerPage
  const currentTraders = filteredTraders.slice(indexOfFirstTrader, indexOfLastTrader)

  // Pagination items
  const paginationItems = []
  for (let number = 1; number <= totalPages; number++) {
    paginationItems.push(
      <Pagination.Item key={number} active={number === currentPage} onClick={() => handlePageChange(number)}>
        {number}
      </Pagination.Item>,
    )
  }

  if (loading) {
    return (
      <Container fluid>
        <Row>
          <Col md={2} className="p-0">
            <AdminSidebar />
          </Col>
          <Col md={10} className="d-flex justify-content-center align-items-center" style={{ height: "80vh" }}>
            <Spinner animation="border" role="status">
              <span className="visually-hidden">Loading...</span>
            </Spinner>
          </Col>
        </Row>
      </Container>
    )
  }

  return (
    <Container fluid>
      <Row>
        <Col md={2} className="p-0">
          <AdminSidebar />
        </Col>
        <Col md={10} className="p-4">
          <h2 className="mb-4">Trader Management</h2>

          {error && <Alert variant="danger">{error}</Alert>}

          <Card className="shadow-sm mb-4">
            <Card.Body>
              <Row className="align-items-center">
                <Col md={4}>
                  <InputGroup>
                    <Form.Control
                      placeholder="Search by name or email"
                      value={searchTerm}
                      onChange={handleSearchChange}
                    />
                    <Button variant="outline-secondary">
                      <i className="bi bi-search"></i>
                    </Button>
                  </InputGroup>
                </Col>
                <Col md={3}>
                  <Form.Select value={selectedExperience} onChange={handleExperienceChange}>
                    <option value="all">All Experience Levels</option>
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                    <option value="professional">Professional</option>
                  </Form.Select>
                </Col>
                <Col md={3}>
                  <Form.Select value={selectedVerification} onChange={handleVerificationChange}>
                    <option value="all">All Verification Status</option>
                    <option value="verified">Verified</option>
                    <option value="unverified">Unverified</option>
                  </Form.Select>
                </Col>
                <Col md={2} className="text-end">
                  <Button variant="primary">
                    <i className="bi bi-download me-2"></i>
                    Export
                  </Button>
                </Col>
              </Row>
            </Card.Body>
          </Card>

          <Card className="shadow-sm">
            <Card.Body>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>Trader</th>
                    <th>Experience</th>
                    <th>Trading Style</th>
                    <th>Win Rate</th>
                    <th>Followers</th>
                    <th>Verified</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {currentTraders.map((trader) => (
                    <tr key={trader._id}>
                      <td>
                        <div className="d-flex align-items-center">
                          <img
                            src={trader.userId.profilePicture || "/default-avatar.png"}
                            alt={trader.userId.firstName}
                            className="rounded-circle me-2"
                            width="40"
                            height="40"
                          />
                          <div>
                            <div>{`${trader.userId.firstName} ${trader.userId.lastName}`}</div>
                            <small className="text-muted">{trader.userId.email}</small>
                          </div>
                        </div>
                      </td>
                      <td>
                        <Badge
                          bg={
                            trader.experience === "beginner"
                              ? "secondary"
                              : trader.experience === "intermediate"
                                ? "info"
                                : trader.experience === "advanced"
                                  ? "primary"
                                  : "success"
                          }
                        >
                          {trader.experience}
                        </Badge>
                      </td>
                      <td>{trader.tradingStyle}</td>
                      <td>{trader.winRate.toFixed(2)}%</td>
                      <td>{trader.followersCount}</td>
                      <td>
                        <Form.Check
                          type="switch"
                          id={`verification-switch-${trader._id}`}
                          checked={trader.isVerified}
                          onChange={(e) => handleVerifyTrader(trader._id, e.target.checked)}
                          label={trader.isVerified ? "Verified" : "Unverified"}
                        />
                      </td>
                      <td>
                        <Badge bg={trader.isActive ? "success" : "danger"}>
                          {trader.isActive ? "Active" : "Suspended"}
                        </Badge>
                      </td>
                      <td>
                        <Button variant="outline-primary" size="sm" className="me-2">
                          <i className="bi bi-eye"></i>
                        </Button>
                        {trader.isActive ? (
                          <Button variant="outline-danger" size="sm" onClick={() => handleSuspendClick(trader)}>
                            <i className="bi bi-slash-circle"></i>
                          </Button>
                        ) : (
                          <Button
                            variant="outline-success"
                            size="sm"
                            onClick={() => handleVerifyTrader(trader._id, true)}
                          >
                            <i className="bi bi-check-circle"></i>
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>

              {filteredTraders.length === 0 && (
                <div className="text-center py-4">
                  <p className="text-muted">No traders found matching your criteria.</p>
                </div>
              )}

              <div className="d-flex justify-content-between align-items-center mt-3">
                <div>
                  Showing {indexOfFirstTrader + 1} to {Math.min(indexOfLastTrader, filteredTraders.length)} of{" "}
                  {filteredTraders.length} traders
                </div>
                <Pagination>
                  <Pagination.First onClick={() => handlePageChange(1)} disabled={currentPage === 1} />
                  <Pagination.Prev onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} />
                  {paginationItems}
                  <Pagination.Next
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  />
                  <Pagination.Last onClick={() => handlePageChange(totalPages)} disabled={currentPage === totalPages} />
                </Pagination>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Suspend Confirmation Modal */}
      <Modal show={showSuspendModal} onHide={() => setShowSuspendModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Suspension</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to suspend trader{" "}
          {traderToSuspend ? `${traderToSuspend.userId.firstName} ${traderToSuspend.userId.lastName}` : ""}? This will
          prevent them from creating new trades and their existing trades will no longer be copied.
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowSuspendModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleSuspendConfirm}>
            Suspend
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  )
}

export default AdminTraders
