"use client"

import { useState, useEffect } from "react"
import { Container, Row, Col, Card, Table, Button, Spinner, Alert, Tabs, Tab } from "react-bootstrap"
import { Line, Bar, Pie } from "react-chartjs-2"
import { useAuth } from "../../contexts/AuthContext"
import { fetchAdminStats, fetchUserGrowth, fetchTradingVolume } from "../../services/api"
import AdminSidebar from "../../components/admin/AdminSidebar"

const AdminDashboard = () => {
  const { user } = useAuth()
  const [stats, setStats] = useState(null)
  const [userGrowth, setUserGrowth] = useState(null)
  const [tradingVolume, setTradingVolume] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    const loadData = async () => {
      try {
        const [statsData, userGrowthData, tradingVolumeData] = await Promise.all([
          fetchAdminStats(),
          fetchUserGrowth(),
          fetchTradingVolume(),
        ])

        setStats(statsData)
        setUserGrowth(userGrowthData)
        setTradingVolume(tradingVolumeData)
      } catch (error) {
        console.error("Error loading admin dashboard data:", error)
        setError("Failed to load dashboard data. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  const userGrowthChart = {
    labels: userGrowth?.labels || [],
    datasets: [
      {
        label: "New Users",
        data: userGrowth?.data || [],
        fill: false,
        backgroundColor: "rgb(75, 192, 192)",
        borderColor: "rgba(75, 192, 192, 0.2)",
      },
    ],
  }

  const tradingVolumeChart = {
    labels: tradingVolume?.labels || [],
    datasets: [
      {
        label: "Trading Volume",
        data: tradingVolume?.data || [],
        backgroundColor: "rgba(54, 162, 235, 0.2)",
        borderColor: "rgb(54, 162, 235)",
        borderWidth: 1,
      },
    ],
  }

  const userTypeChart = {
    labels: ["Traders", "Followers", "Both"],
    datasets: [
      {
        data: stats?.userTypes || [0, 0, 0],
        backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56"],
        hoverBackgroundColor: ["#FF6384", "#36A2EB", "#FFCE56"],
      },
    ],
  }

  if (loading) {
    return (
      <Container fluid>
        <Row>
          <Col md={2} className="p-0">
            <AdminSidebar />
          </Col>
          <Col md={10} className="d-flex justify-content-center align-items-center" style={{ height: "80vh" }}>
            <Spinner animation="border" role="status">
              <span className="visually-hidden">Loading...</span>
            </Spinner>
          </Col>
        </Row>
      </Container>
    )
  }

  if (error) {
    return (
      <Container fluid>
        <Row>
          <Col md={2} className="p-0">
            <AdminSidebar />
          </Col>
          <Col md={10} className="p-4">
            <Alert variant="danger">{error}</Alert>
          </Col>
        </Row>
      </Container>
    )
  }

  return (
    <Container fluid>
      <Row>
        <Col md={2} className="p-0">
          <AdminSidebar />
        </Col>
        <Col md={10} className="p-4">
          <h2 className="mb-4">Admin Dashboard</h2>

          {/* Stats Cards */}
          <Row className="mb-4">
            <Col md={3}>
              <Card className="shadow-sm h-100">
                <Card.Body>
                  <h6 className="text-muted">Total Users</h6>
                  <h2>{stats.totalUsers}</h2>
                  <small className="text-success">+{stats.newUsersToday} today</small>
                </Card.Body>
              </Card>
            </Col>
            <Col md={3}>
              <Card className="shadow-sm h-100">
                <Card.Body>
                  <h6 className="text-muted">Total Traders</h6>
                  <h2>{stats.totalTraders}</h2>
                  <small className="text-success">+{stats.newTradersToday} today</small>
                </Card.Body>
              </Card>
            </Col>
            <Col md={3}>
              <Card className="shadow-sm h-100">
                <Card.Body>
                  <h6 className="text-muted">Trading Volume (24h)</h6>
                  <h2>${stats.tradingVolume24h.toLocaleString()}</h2>
                  <small className={stats.volumeChange24h >= 0 ? "text-success" : "text-danger"}>
                    {stats.volumeChange24h >= 0 ? "+" : ""}
                    {stats.volumeChange24h}% from yesterday
                  </small>
                </Card.Body>
              </Card>
            </Col>
            <Col md={3}>
              <Card className="shadow-sm h-100">
                <Card.Body>
                  <h6 className="text-muted">Total Trades (24h)</h6>
                  <h2>{stats.totalTrades24h}</h2>
                  <small className={stats.tradesChange24h >= 0 ? "text-success" : "text-danger"}>
                    {stats.tradesChange24h >= 0 ? "+" : ""}
                    {stats.tradesChange24h}% from yesterday
                  </small>
                </Card.Body>
              </Card>
            </Col>
          </Row>

          {/* Charts */}
          <Row className="mb-4">
            <Col md={8}>
              <Card className="shadow-sm">
                <Card.Body>
                  <h5 className="card-title">User Growth</h5>
                  <div style={{ height: "300px" }}>
                    <Line data={userGrowthChart} options={{ maintainAspectRatio: false }} />
                  </div>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="shadow-sm h-100">
                <Card.Body>
                  <h5 className="card-title">User Types</h5>
                  <div style={{ height: "300px" }} className="d-flex justify-content-center align-items-center">
                    <Pie data={userTypeChart} options={{ maintainAspectRatio: false }} />
                  </div>
                </Card.Body>
              </Card>
            </Col>
          </Row>

          <Row className="mb-4">
            <Col>
              <Card className="shadow-sm">
                <Card.Body>
                  <h5 className="card-title">Trading Volume</h5>
                  <div style={{ height: "300px" }}>
                    <Bar data={tradingVolumeChart} options={{ maintainAspectRatio: false }} />
                  </div>
                </Card.Body>
              </Card>
            </Col>
          </Row>

          {/* Recent Activity */}
          <Row className="mb-4">
            <Col>
              <Card className="shadow-sm">
                <Card.Header className="bg-white">
                  <h5 className="mb-0">Recent Activity</h5>
                </Card.Header>
                <Card.Body>
                  <Tabs defaultActiveKey="users" className="mb-3">
                    <Tab eventKey="users" title="New Users">
                      <Table responsive hover>
                        <thead>
                          <tr>
                            <th>User</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Registered</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {stats.recentUsers.map((user) => (
                            <tr key={user._id}>
                              <td>
                                <div className="d-flex align-items-center">
                                  <img
                                    src={user.profilePicture || "/default-avatar.png"}
                                    alt={user.firstName}
                                    className="rounded-circle me-2"
                                    width="32"
                                    height="32"
                                  />
                                  <span>{`${user.firstName} ${user.lastName}`}</span>
                                </div>
                              </td>
                              <td>{user.email}</td>
                              <td>{user.role}</td>
                              <td>{new Date(user.createdAt).toLocaleString()}</td>
                              <td>
                                <Button variant="outline-primary" size="sm" className="me-2">
                                  View
                                </Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </Tab>
                    <Tab eventKey="trades" title="Recent Trades">
                      <Table responsive hover>
                        <thead>
                          <tr>
                            <th>Trader</th>
                            <th>Symbol</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Time</th>
                          </tr>
                        </thead>
                        <tbody>
                          {stats.recentTrades.map((trade) => (
                            <tr key={trade._id}>
                              <td>{`${trade.trader.firstName} ${trade.trader.lastName}`}</td>
                              <td>{trade.symbol}</td>
                              <td>{trade.direction === "long" ? "Buy" : "Sell"}</td>
                              <td>{trade.quantity}</td>
                              <td>
                                <span
                                  className={`badge bg-${
                                    trade.status === "open"
                                      ? "success"
                                      : trade.status === "closed"
                                        ? "secondary"
                                        : trade.status === "pending"
                                          ? "warning"
                                          : "danger"
                                  }`}
                                >
                                  {trade.status}
                                </span>
                              </td>
                              <td>{new Date(trade.createdAt).toLocaleString()}</td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </Tab>
                  </Tabs>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Col>
      </Row>
    </Container>
  )
}

export default AdminDashboard
