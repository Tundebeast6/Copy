"use client"

import { useState, useEffect } from "react"
import {
  Container,
  Row,
  Col,
  Card,
  Table,
  Button,
  Form,
  InputGroup,
  Pagination,
  Badge,
  Spinner,
  Alert,
  Modal,
} from "react-bootstrap"
import { useAuth } from "../../contexts/AuthContext"
import { fetchUsers, updateUserStatus, deleteUser } from "../../services/api"
import AdminSidebar from "../../components/admin/AdminSidebar"

const AdminUsers = () => {
  const { user } = useAuth()
  const [users, setUsers] = useState([])
  const [filteredUsers, setFilteredUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [selectedRole, setSelectedRole] = useState("all")
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [userToDelete, setUserToDelete] = useState(null)

  const usersPerPage = 10

  useEffect(() => {
    const loadUsers = async () => {
      try {
        const response = await fetchUsers()
        setUsers(response.users)
        setFilteredUsers(response.users)
        setTotalPages(Math.ceil(response.users.length / usersPerPage))
      } catch (error) {
        console.error("Error loading users:", error)
        setError("Failed to load users. Please try again later.")
      } finally {
        setLoading(false)
      }
    }

    loadUsers()
  }, [])

  useEffect(() => {
    // Filter users based on search term and role
    let result = users

    if (searchTerm) {
      const term = searchTerm.toLowerCase()
      result = result.filter(
        (user) =>
          user.email.toLowerCase().includes(term) ||
          user.firstName.toLowerCase().includes(term) ||
          user.lastName.toLowerCase().includes(term),
      )
    }

    if (selectedRole !== "all") {
      result = result.filter((user) => user.role === selectedRole)
    }

    setFilteredUsers(result)
    setTotalPages(Math.ceil(result.length / usersPerPage))
    setCurrentPage(1)
  }, [searchTerm, selectedRole, users])

  const handleRoleChange = (e) => {
    setSelectedRole(e.target.value)
  }

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value)
  }

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber)
  }

  const handleDeleteClick = (user) => {
    setUserToDelete(user)
    setShowDeleteModal(true)
  }

  const handleDeleteConfirm = async () => {
    try {
      await deleteUser(userToDelete._id)
      setUsers(users.filter((u) => u._id !== userToDelete._id))
      setShowDeleteModal(false)
    } catch (error) {
      console.error("Error deleting user:", error)
      setError("Failed to delete user. Please try again later.")
    }
  }

  const handleStatusChange = async (userId, isActive) => {
    try {
      await updateUserStatus(userId, isActive)
      setUsers(users.map((u) => (u._id === userId ? { ...u, isActive } : u)))
    } catch (error) {
      console.error("Error updating user status:", error)
      setError("Failed to update user status. Please try again later.")
    }
  }

  // Get current users
  const indexOfLastUser = currentPage * usersPerPage
  const indexOfFirstUser = indexOfLastUser - usersPerPage
  const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser)

  // Pagination items
  const paginationItems = []
  for (let number = 1; number <= totalPages; number++) {
    paginationItems.push(
      <Pagination.Item key={number} active={number === currentPage} onClick={() => handlePageChange(number)}>
        {number}
      </Pagination.Item>,
    )
  }

  if (loading) {
    return (
      <Container fluid>
        <Row>
          <Col md={2} className="p-0">
            <AdminSidebar />
          </Col>
          <Col md={10} className="d-flex justify-content-center align-items-center" style={{ height: "80vh" }}>
            <Spinner animation="border" role="status">
              <span className="visually-hidden">Loading...</span>
            </Spinner>
          </Col>
        </Row>
      </Container>
    )
  }

  return (
    <Container fluid>
      <Row>
        <Col md={2} className="p-0">
          <AdminSidebar />
        </Col>
        <Col md={10} className="p-4">
          <h2 className="mb-4">User Management</h2>

          {error && <Alert variant="danger">{error}</Alert>}

          <Card className="shadow-sm mb-4">
            <Card.Body>
              <Row className="align-items-center">
                <Col md={6}>
                  <InputGroup>
                    <Form.Control
                      placeholder="Search by name or email"
                      value={searchTerm}
                      onChange={handleSearchChange}
                    />
                    <Button variant="outline-secondary">
                      <i className="bi bi-search"></i>
                    </Button>
                  </InputGroup>
                </Col>
                <Col md={3}>
                  <Form.Select value={selectedRole} onChange={handleRoleChange}>
                    <option value="all">All Roles</option>
                    <option value="admin">Admin</option>
                    <option value="trader">Trader</option>
                    <option value="follower">Follower</option>
                  </Form.Select>
                </Col>
                <Col md={3} className="text-end">
                  <Button variant="primary">
                    <i className="bi bi-plus-lg me-2"></i>
                    Add User
                  </Button>
                </Col>
              </Row>
            </Card.Body>
          </Card>

          <Card className="shadow-sm">
            <Card.Body>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>User</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Registered</th>
                    <th>Last Login</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {currentUsers.map((user) => (
                    <tr key={user._id}>
                      <td>
                        <div className="d-flex align-items-center">
                          <img
                            src={user.profilePicture || "/default-avatar.png"}
                            alt={user.firstName}
                            className="rounded-circle me-2"
                            width="40"
                            height="40"
                          />
                          <div>
                            <div>{`${user.firstName} ${user.lastName}`}</div>
                            {user.role === "admin" && (
                              <Badge bg="danger" className="me-1">
                                Admin
                              </Badge>
                            )}
                          </div>
                        </div>
                      </td>
                      <td>{user.email}</td>
                      <td>
                        <Badge bg={user.role === "admin" ? "danger" : user.role === "trader" ? "primary" : "secondary"}>
                          {user.role}
                        </Badge>
                      </td>
                      <td>
                        <Form.Check
                          type="switch"
                          id={`status-switch-${user._id}`}
                          checked={user.isActive}
                          onChange={(e) => handleStatusChange(user._id, e.target.checked)}
                          label={user.isActive ? "Active" : "Inactive"}
                        />
                      </td>
                      <td>{new Date(user.createdAt).toLocaleDateString()}</td>
                      <td>{user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : "Never"}</td>
                      <td>
                        <Button variant="outline-primary" size="sm" className="me-2">
                          <i className="bi bi-pencil"></i>
                        </Button>
                        <Button
                          variant="outline-danger"
                          size="sm"
                          onClick={() => handleDeleteClick(user)}
                          disabled={user._id === user._id} // Prevent deleting yourself
                        >
                          <i className="bi bi-trash"></i>
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>

              {filteredUsers.length === 0 && (
                <div className="text-center py-4">
                  <p className="text-muted">No users found matching your criteria.</p>
                </div>
              )}

              <div className="d-flex justify-content-between align-items-center mt-3">
                <div>
                  Showing {indexOfFirstUser + 1} to {Math.min(indexOfLastUser, filteredUsers.length)} of{" "}
                  {filteredUsers.length} users
                </div>
                <Pagination>
                  <Pagination.First onClick={() => handlePageChange(1)} disabled={currentPage === 1} />
                  <Pagination.Prev onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} />
                  {paginationItems}
                  <Pagination.Next
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  />
                  <Pagination.Last onClick={() => handlePageChange(totalPages)} disabled={currentPage === totalPages} />
                </Pagination>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Delete Confirmation Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Confirm Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete user{" "}
          {userToDelete ? `${userToDelete.firstName} ${userToDelete.lastName}` : ""}? This action cannot be undone.
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDeleteConfirm}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  )
}

export default AdminUsers
