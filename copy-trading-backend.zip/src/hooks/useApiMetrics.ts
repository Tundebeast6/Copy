"use client"

import { useEffect } from "react"
import { api } from "../services/api"
import { trackApiCall } from "../monitoring/performance"

export const useApiMetrics = () => {
  useEffect(() => {
    // Add request interceptor to track API call start time
    const requestInterceptor = api.interceptors.request.use(
      (config) => {
        config.metadata = { startTime: performance.now() }
        return config
      },
      (error) => {
        return Promise.reject(error)
      },
    )

    // Add response interceptor to track API call duration
    const responseInterceptor = api.interceptors.response.use(
      (response) => {
        const { config } = response
        const startTime = config.metadata?.startTime
        if (startTime) {
          trackApiCall(config.url || "", config.method?.toUpperCase() || "UNKNOWN", startTime)
        }
        return response
      },
      (error) => {
        const { config } = error
        if (config) {
          const startTime = config.metadata?.startTime
          if (startTime) {
            trackApiCall(config.url || "", config.method?.toUpperCase() || "UNKNOWN", startTime)
          }
        }
        return Promise.reject(error)
      },
    )

    // Clean up interceptors on unmount
    return () => {
      api.interceptors.request.eject(requestInterceptor)
      api.interceptors.response.eject(responseInterceptor)
    }
  }, [])
}
