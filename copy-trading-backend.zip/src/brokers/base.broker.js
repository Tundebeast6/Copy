/**
 * Base Broker Class
 *
 * This file defines the base broker class that all broker adapters extend.
 */

const { ApiError } = require("../utils/errors")
const logger = require("../config/logger")

/**
 * Base Broker class
 * @class BaseBroker
 */
class BaseBroker {
  /**
   * Create a broker instance
   * @param {Object} credentials - Broker credentials
   * @param {Object} config - Broker configuration
   */
  constructor(credentials, config = {}) {
    if (this.constructor === BaseBroker) {
      throw new Error("BaseBroker cannot be instantiated directly")
    }

    this.credentials = credentials
    this.config = config
    this.isConnected = false
    this.lastError = null
  }

  /**
   * Connect to broker
   * @returns {Promise<boolean>} Connection status
   */
  async connect() {
    try {
      this.isConnected = true
      return true
    } catch (error) {
      this.isConnected = false
      this.lastError = error.message
      logger.error(`Failed to connect to broker: ${error.message}`)
      throw new ApiError(500, `Failed to connect to broker: ${error.message}`)
    }
  }

  /**
   * Disconnect from broker
   * @returns {Promise<boolean>} Disconnection status
   */
  async disconnect() {
    try {
      this.isConnected = false
      return true
    } catch (error) {
      this.lastError = error.message
      logger.error(`Failed to disconnect from broker: ${error.message}`)
      throw new ApiError(500, `Failed to disconnect from broker: ${error.message}`)
    }
  }

  /**
   * Get account information
   * @returns {Promise<Object>} Account information
   */
  async getAccount() {
    throw new Error("Method not implemented")
  }

  /**
   * Get account balance
   * @returns {Promise<number>} Account balance
   */
  async getBalance() {
    throw new Error("Method not implemented")
  }

  /**
   * Get open positions
   * @returns {Promise<Array>} Open positions
   */
  async getPositions() {
    throw new Error("Method not implemented")
  }

  /**
   * Get order history
   * @param {Object} options - Query options
   * @returns {Promise<Array>} Order history
   */
  async getOrderHistory(options = {}) {
    throw new Error("Method not implemented")
  }

  /**
   * Get trade history
   * @param {Object} options - Query options
   * @returns {Promise<Array>} Trade history
   */
  async getTradeHistory(options = {}) {
    throw new Error("Method not implemented")
  }

  /**
   * Place a market order
   * @param {Object} order - Order details
   * @returns {Promise<Object>} Order result
   */
  async placeMarketOrder(order) {
    throw new Error("Method not implemented")
  }

  /**
   * Place a limit order
   * @param {Object} order - Order details
   * @returns {Promise<Object>} Order result
   */
  async placeLimitOrder(order) {
    throw new Error("Method not implemented")
  }

  /**
   * Place a stop order
   * @param {Object} order - Order details
   * @returns {Promise<Object>} Order result
   */
  async placeStopOrder(order) {
    throw new Error("Method not implemented")
  }

  /**
   * Cancel an order
   * @param {string} orderId - Order ID
   * @returns {Promise<boolean>} Cancellation status
   */
  async cancelOrder(orderId) {
    throw new Error("Method not implemented")
  }

  /**
   * Get order status
   * @param {string} orderId - Order ID
   * @returns {Promise<Object>} Order status
   */
  async getOrderStatus(orderId) {
    throw new Error("Method not implemented")
  }

  /**
   * Get market data
   * @param {string} symbol - Symbol
   * @returns {Promise<Object>} Market data
   */
  async getMarketData(symbol) {
    throw new Error("Method not implemented")
  }

  /**
   * Subscribe to market data
   * @param {string} symbol - Symbol
   * @param {Function} callback - Callback function
   * @returns {Promise<boolean>} Subscription status
   */
  async subscribeToMarketData(symbol, callback) {
    throw new Error("Method not implemented")
  }

  /**
   * Unsubscribe from market data
   * @param {string} symbol - Symbol
   * @returns {Promise<boolean>} Unsubscription status
   */
  async unsubscribeFromMarketData(symbol) {
    throw new Error("Method not implemented")
  }

  /**
   * Check if broker is connected
   * @returns {boolean} Connection status
   */
  isActive() {
    return this.isConnected
  }

  /**
   * Get last error
   * @returns {string} Last error message
   */
  getLastError() {
    return this.lastError
  }

  /**
   * Reset last error
   */
  resetLastError() {
    this.lastError = null
  }
}

module.exports = BaseBroker
