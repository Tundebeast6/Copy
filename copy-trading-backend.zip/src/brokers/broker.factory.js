/**
 * Broker Factory
 *
 * This file provides a factory for creating broker instances.
 */

const SchwabAdapter = require("./adapters/schwab.adapter")
const TastytradeAdapter = require("./adapters/tastytrade.adapter")
const OandaAdapter = require("./adapters/oanda.adapter")
const BinanceAdapter = require("./adapters/binance.adapter")
const { ApiError } = require("../utils/errors")
const logger = require("../config/logger")

/**
 * Create a broker instance
 * @param {string} brokerName - Broker name
 * @param {Object} credentials - Broker credentials
 * @param {Object} config - Broker configuration
 * @returns {Object} Broker instance
 */
const createBroker = (brokerName, credentials, config = {}) => {
  logger.info(`Creating broker instance for ${brokerName}`)

  switch (brokerName.toLowerCase()) {
    case "schwab":
      return new SchwabAdapter(credentials, config)

    case "tastytrade":
      return new TastytradeAdapter(credentials, config)

    case "oanda":
      return new OandaAdapter(credentials, config)

    case "binance":
      return new BinanceAdapter(credentials, config)

    default:
      logger.error(`Unsupported broker: ${brokerName}`)
      throw new ApiError(400, `Unsupported broker: ${brokerName}`)
  }
}

module.exports = {
  createBroker,
}
