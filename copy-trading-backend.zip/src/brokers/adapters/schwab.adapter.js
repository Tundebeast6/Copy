/**
 * Schwab Broker Adapter
 *
 * This file implements the Schwab broker adapter.
 */

const BaseBroker = require("../base.broker")
const { ApiError } = require("../../utils/errors")
const logger = require("../../config/logger")

/**
 * Schwab Broker Adapter
 * @class SchwabAdapter
 * @extends BaseBroker
 */
class SchwabAdapter extends BaseBroker {
  /**
   * Create a Schwab broker instance
   * @param {Object} credentials - Schwab credentials
   * @param {Object} config - Schwab configuration
   */
  constructor(credentials, config = {}) {
    super(credentials, config)

    this.clientId = process.env.SCHWAB_CLIENT_ID
    this.clientSecret = process.env.SCHWAB_CLIENT_SECRET
    this.redirectUri = process.env.SCHWAB_REDIRECT_URI
    this.accessToken = credentials.accessToken
    this.refreshToken = credentials.refreshToken
    this.tokenExpiry = credentials.tokenExpiry
    this.accountId = config.accountId
    this.baseUrl = "https://api.schwab.com/v1" // Example URL, replace with actual Schwab API URL
  }

  /**
   * Connect to Schwab
   * @returns {Promise<boolean>} Connection status
   */
  async connect() {
    try {
      logger.info("Connecting to Schwab")

      // Check if access token is expired
      if (new Date() > new Date(this.tokenExpiry)) {
        await this.refreshAccessToken()
      }

      // Test connection by getting account info
      await this.getAccount()

      this.isConnected = true
      logger.info("Connected to Schwab successfully")

      return true
    } catch (error) {
      this.isConnected = false
      this.lastError = error.message
      logger.error(`Failed to connect to Schwab: ${error.message}`)
      throw new ApiError(500, `Failed to connect to Schwab: ${error.message}`)
    }
  }

  /**
   * Refresh access token
   * @returns {Promise<void>}
   */
  async refreshAccessToken() {
    try {
      logger.info("Refreshing Schwab access token")

      const response = await fetch("https://api.schwab.com/v1/oauth2/token", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Authorization: `Basic ${Buffer.from(`${this.clientId}:${this.clientSecret}`).toString("base64")}`,
        },
        body: new URLSearchParams({
          grant_type: "refresh_token",
          refresh_token: this.refreshToken,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error_description || `HTTP error ${response.status}`)
      }

      const data = await response.json()

      this.accessToken = data.access_token
      this.refreshToken = data.refresh_token
      this.tokenExpiry = new Date(Date.now() + data.expires_in * 1000)

      logger.info("Schwab access token refreshed successfully")
    } catch (error) {
      logger.error(`Failed to refresh Schwab access token: ${error.message}`)
      throw new ApiError(500, `Failed to refresh Schwab access token: ${error.message}`)
    }
  }

  /**
   * Make API request to Schwab
   * @param {string} endpoint - API endpoint
   * @param {string} method - HTTP method
   * @param {Object} data - Request data
   * @returns {Promise<Object>} Response data
   */
  async makeRequest(endpoint, method = "GET", data = null) {
    try {
      // Check if access token is expired
      if (new Date() > new Date(this.tokenExpiry)) {
        await this.refreshAccessToken()
      }

      const url = `${this.baseUrl}/${endpoint}`

      const options = {
        method,
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": "application/json",
        },
      }

      if (data && (method === "POST" || method === "PUT" || method === "PATCH")) {
        options.body = JSON.stringify(data)
      }

      const response = await fetch(url, options)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || `HTTP error ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      logger.error(`Schwab API request failed: ${error.message}`)
      throw new ApiError(500, `Schwab API request failed: ${error.message}`)
    }
  }

  /**
   * Get account information
   * @returns {Promise<Object>} Account information
   */
  async getAccount() {
    try {
      const response = await this.makeRequest(`accounts/${this.accountId}`)

      return {
        id: response.accountId,
        name: response.accountName,
        type: response.accountType,
        status: response.accountStatus,
        balance: response.balance,
        currency: response.currency,
      }
    } catch (error) {
      logger.error(`Failed to get Schwab account: ${error.message}`)
      throw new ApiError(500, `Failed to get Schwab account: ${error.message}`)
    }
  }

  /**
   * Get account balance
   * @returns {Promise<number>} Account balance
   */
  async getBalance() {
    try {
      const account = await this.getAccount()

      return Number.parseFloat(account.balance)
    } catch (error) {
      logger.error(`Failed to get Schwab balance: ${error.message}`)
      throw new ApiError(500, `Failed to get Schwab balance: ${error.message}`)
    }
  }

  /**
   * Get open positions
   * @returns {Promise<Array>} Open positions
   */
  async getPositions() {
    try {
      const response = await this.makeRequest(`accounts/${this.accountId}/positions`)

      return response.positions.map((position) => ({
        symbol: position.symbol,
        assetClass: position.assetType,
        direction: position.longQuantity > 0 ? "long" : "short",
        quantity: Math.abs(position.longQuantity > 0 ? position.longQuantity : position.shortQuantity),
        entryPrice: position.averagePrice,
        currentPrice:
          position.marketValue / Math.abs(position.longQuantity > 0 ? position.longQuantity : position.shortQuantity),
        marketValue: position.marketValue,
        unrealizedPL: position.unrealizedProfitLoss,
        unrealizedPLPercent: (position.unrealizedProfitLoss / position.marketValue) * 100,
        openTime: new Date(position.acquisitionDate),
      }))
    } catch (error) {
      logger.error(`Failed to get Schwab positions: ${error.message}`)
      throw new ApiError(500, `Failed to get Schwab positions: ${error.message}`)
    }
  }

  /**
   * Place a market order
   * @param {Object} order - Order details
   * @returns {Promise<Object>} Order result
   */
  async placeMarketOrder(order) {
    try {
      const data = {
        orderType: "MARKET",
        session: "NORMAL",
        duration: "DAY",
        orderStrategyType: "SINGLE",
        orderLegCollection: [
          {
            instruction: order.direction === "long" ? "BUY" : "SELL",
            quantity: order.quantity,
            instrument: {
              symbol: order.symbol,
              assetType: order.assetClass || "EQUITY",
            },
          },
        ],
      }

      // Add stop loss if provided
      if (order.stopLoss) {
        data.stopPrice = order.stopLoss
      }

      // Add take profit if provided
      if (order.takeProfit) {
        data.stopPriceLinkBasis = "TRIGGER"
        data.stopPriceLinkType = "PERCENT"
        data.stopPriceOffset = order.takeProfit
      }

      const response = await this.makeRequest(`accounts/${this.accountId}/orders`, "POST", data)

      return {
        id: response.orderId,
        symbol: order.symbol,
        type: "market",
        direction: order.direction,
        quantity: order.quantity,
        status: response.status,
        filledPrice: response.filledPrice,
        timestamp: new Date().toISOString(),
      }
    } catch (error) {
      logger.error(`Failed to place Schwab market order: ${error.message}`)
      throw new ApiError(500, `Failed to place Schwab market order: ${error.message}`)
    }
  }

  /**
   * Get market data
   * @param {string} symbol - Symbol
   * @returns {Promise<Object>} Market data
   */
  async getMarketData(symbol) {
    try {
      const response = await this.makeRequest(`marketdata/${symbol}/quotes`)

      return {
        symbol,
        bid: response.bidPrice,
        ask: response.askPrice,
        last: response.lastPrice,
        volume: response.totalVolume,
        time: new Date(response.quoteTimeInLong).toISOString(),
      }
    } catch (error) {
      logger.error(`Failed to get Schwab market data: ${error.message}`)
      throw new ApiError(500, `Failed to get Schwab market data: ${error.message}`)
    }
  }
}

module.exports = SchwabAdapter
