/**
 * Binance Broker Adapter
 *
 * This file implements the Binance broker adapter.
 */

const BaseBroker = require("../base.broker")
const { ApiError } = require("../../utils/errors")
const logger = require("../../config/logger")
const crypto = require("crypto")

/**
 * Binance Broker Adapter
 * @class BinanceAdapter
 * @extends BaseBroker
 */
class BinanceAdapter extends BaseBroker {
  /**
   * Create a Binance broker instance
   * @param {Object} credentials - Binance credentials
   * @param {Object} config - Binance configuration
   */
  constructor(credentials, config = {}) {
    super(credentials, config)

    this.apiKey = credentials.apiKey
    this.apiSecret = credentials.apiSecret
    this.accountId = config.accountId // Not used for Binance, but kept for consistency
    this.baseUrl = process.env.BINANCE_BASE_URL || "https://api.binance.com"
  }

  /**
   * Connect to Binance
   * @returns {Promise<boolean>} Connection status
   */
  async connect() {
    try {
      logger.info("Connecting to Binance")

      // Validate credentials
      if (!this.apiKey) {
        throw new Error("API key is required")
      }

      if (!this.apiSecret) {
        throw new Error("API secret is required")
      }

      // Test connection by getting account info
      await this.getAccount()

      this.isConnected = true
      logger.info("Connected to Binance successfully")

      return true
    } catch (error) {
      this.isConnected = false
      this.lastError = error.message
      logger.error(`Failed to connect to Binance: ${error.message}`)
      throw new ApiError(500, `Failed to connect to Binance: ${error.message}`)
    }
  }

  /**
   * Generate signature for Binance API
   * @param {string} queryString - Query string
   * @returns {string} Signature
   */
  generateSignature(queryString) {
    return crypto.createHmac("sha256", this.apiSecret).update(queryString).digest("hex")
  }

  /**
   * Make API request to Binance
   * @param {string} endpoint - API endpoint
   * @param {string} method - HTTP method
   * @param {Object} params - Request parameters
   * @param {boolean} signed - Whether the request needs a signature
   * @returns {Promise<Object>} Response data
   */
  async makeRequest(endpoint, method = "GET", params = {}, signed = false) {
    try {
      let url = `${this.baseUrl}/${endpoint}`
      let queryString = ""

      // Add timestamp for signed requests
      if (signed) {
        params.timestamp = Date.now()
        queryString = Object.entries(params)
          .map(([key, value]) => `${key}=${value}`)
          .join("&")
        params.signature = this.generateSignature(queryString)
      }

      // Build query string
      if (Object.keys(params).length > 0) {
        queryString = Object.entries(params)
          .map(([key, value]) => `${key}=${value}`)
          .join("&")
        url += `?${queryString}`
      }

      const options = {
        method,
        headers: {
          "X-MBX-APIKEY": this.apiKey,
        },
      }

      const response = await fetch(url, options)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.msg || `HTTP error ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      logger.error(`Binance API request failed: ${error.message}`)
      throw new ApiError(500, `Binance API request failed: ${error.message}`)
    }
  }

  /**
   * Get account information
   * @returns {Promise<Object>} Account information
   */
  async getAccount() {
    try {
      const response = await this.makeRequest("api/v3/account", "GET", {}, true)

      return {
        id: response.accountType,
        name: "Binance Account",
        type: response.accountType,
        status: "Active",
        balance: this.calculateTotalBalance(response.balances),
        currency: "USDT", // Using USDT as the base currency
      }
    } catch (error) {
      logger.error(`Failed to get Binance account: ${error.message}`)
      throw new ApiError(500, `Failed to get Binance account: ${error.message}`)
    }
  }

  /**
   * Calculate total balance from Binance balances
   * @param {Array} balances - Binance balances
   * @returns {number} Total balance in USDT
   */
  async calculateTotalBalance(balances) {
    try {
      // Filter out zero balances
      const nonZeroBalances = balances.filter(
        (balance) => Number.parseFloat(balance.free) > 0 || Number.parseFloat(balance.locked) > 0,
      )

      let totalBalance = 0

      // For each asset, get its price in USDT
      for (const balance of nonZeroBalances) {
        const asset = balance.asset
        const amount = Number.parseFloat(balance.free) + Number.parseFloat(balance.locked)

        if (asset === "USDT") {
          totalBalance += amount
        } else {
          try {
            // Get price in USDT
            const ticker = await this.makeRequest(`api/v3/ticker/price?symbol=${asset}USDT`)
            const price = Number.parseFloat(ticker.price)
            totalBalance += amount * price
          } catch (error) {
            // If the asset doesn't have a USDT pair, skip it
            logger.warn(`Could not get price for ${asset}USDT: ${error.message}`)
          }
        }
      }

      return totalBalance
    } catch (error) {
      logger.error(`Failed to calculate total balance: ${error.message}`)
      return 0
    }
  }

  /**
   * Get account balance
   * @returns {Promise<number>} Account balance
   */
  async getBalance() {
    try {
      const account = await this.getAccount()

      return account.balance
    } catch (error) {
      logger.error(`Failed to get Binance balance: ${error.message}`)
      throw new ApiError(500, `Failed to get Binance balance: ${error.message}`)
    }
  }

  /**
   * Get open positions
   * @returns {Promise<Array>} Open positions
   */
  async getPositions() {
    try {
      // For spot trading, get account balances
      const account = await this.makeRequest("api/v3/account", "GET", {}, true)

      // Filter out zero balances
      const nonZeroBalances = account.balances.filter(
        (balance) => Number.parseFloat(balance.free) > 0 || Number.parseFloat(balance.locked) > 0,
      )

      const positions = []

      // For each asset, get its current price and create a position
      for (const balance of nonZeroBalances) {
        const asset = balance.asset
        const quantity = Number.parseFloat(balance.free) + Number.parseFloat(balance.locked)

        if (asset !== "USDT" && quantity > 0) {
          try {
            // Get current price
            const ticker = await this.makeRequest(`api/v3/ticker/price?symbol=${asset}USDT`)
            const currentPrice = Number.parseFloat(ticker.price)

            // Get trade history to estimate entry price
            const trades = await this.makeRequest(`api/v3/myTrades?symbol=${asset}USDT`, "GET", { limit: 1000 }, true)

            // Calculate average entry price
            let totalQuantity = 0
            let totalCost = 0

            for (const trade of trades) {
              if (trade.isBuyer) {
                totalQuantity += Number.parseFloat(trade.qty)
                totalCost += Number.parseFloat(trade.qty) * Number.parseFloat(trade.price)
              }
            }

            const entryPrice = totalQuantity > 0 ? totalCost / totalQuantity : currentPrice

            positions.push({
              symbol: `${asset}/USDT`,
              assetClass: "crypto",
              direction: "long",
              quantity,
              entryPrice,
              currentPrice,
              marketValue: quantity * currentPrice,
              unrealizedPL: quantity * (currentPrice - entryPrice),
              unrealizedPLPercent: ((currentPrice - entryPrice) / entryPrice) * 100,
              openTime: new Date(),
            })
          } catch (error) {
            logger.warn(`Could not get position for ${asset}: ${error.message}`)
          }
        }
      }

      return positions
    } catch (error) {
      logger.error(`Failed to get Binance positions: ${error.message}`)
      throw new ApiError(500, `Failed to get Binance positions: ${error.message}`)
    }
  }

  /**
   * Place a market order
   * @param {Object} order - Order details
   * @returns {Promise<Object>} Order result
   */
  async placeMarketOrder(order) {
    try {
      const params = {
        symbol: order.symbol.replace("/", ""), // Remove slash from symbol (e.g., BTC/USDT -> BTCUSDT)
        side: order.direction === "long" ? "BUY" : "SELL",
        type: "MARKET",
        quantity: order.quantity,
      }

      const response = await this.makeRequest("api/v3/order", "POST", params, true)

      return {
        id: response.orderId,
        symbol: order.symbol,
        type: "market",
        direction: order.direction,
        quantity: order.quantity,
        status: response.status,
        filledPrice: Number.parseFloat(response.fills[0]?.price) || 0,
        timestamp: new Date(response.transactTime).toISOString(),
      }
    } catch (error) {
      logger.error(`Failed to place Binance market order: ${error.message}`)
      throw new ApiError(500, `Failed to place Binance market order: ${error.message}`)
    }
  }

  /**
   * Get market data
   * @param {string} symbol - Symbol
   * @returns {Promise<Object>} Market data
   */
  async getMarketData(symbol) {
    try {
      // Remove slash from symbol (e.g., BTC/USDT -> BTCUSDT)
      const formattedSymbol = symbol.replace("/", "")

      // Get ticker
      const ticker = await this.makeRequest(`api/v3/ticker/24hr?symbol=${formattedSymbol}`)

      // Get order book
      const orderBook = await this.makeRequest(`api/v3/depth?symbol=${formattedSymbol}&limit=5`)

      return {
        symbol,
        bid: Number.parseFloat(orderBook.bids[0][0]),
        ask: Number.parseFloat(orderBook.asks[0][0]),
        last: Number.parseFloat(ticker.lastPrice),
        volume: Number.parseFloat(ticker.volume),
        time: new Date(ticker.closeTime).toISOString(),
      }
    } catch (error) {
      logger.error(`Failed to get Binance market data: ${error.message}`)
      throw new ApiError(500, `Failed to get Binance market data: ${error.message}`)
    }
  }
}

module.exports = BinanceAdapter
