/**
 * Tastytrade Broker Adapter
 *
 * This file implements the Tastytrade broker adapter.
 */

const BaseBroker = require("../base.broker")
const { ApiError } = require("../../utils/errors")
const logger = require("../../config/logger")

/**
 * Tastytrade Broker Adapter
 * @class TastytradeAdapter
 * @extends BaseBroker
 */
class TastytradeAdapter extends BaseBroker {
  /**
   * Create a Tastytrade broker instance
   * @param {Object} credentials - Tastytrade credentials
   * @param {Object} config - Tastytrade configuration
   */
  constructor(credentials, config = {}) {
    super(credentials, config)

    this.accessToken = credentials.accessToken
    this.refreshToken = credentials.refreshToken
    this.tokenExpiry = credentials.tokenExpiry
    this.accountId = config.accountId
    this.baseUrl = process.env.TASTYTRADE_BASE_URL || "https://api.tastytrade.com"
  }

  /**
   * Connect to Tastytrade
   * @returns {Promise<boolean>} Connection status
   */
  async connect() {
    try {
      logger.info("Connecting to Tastytrade")

      // Check if access token is expired
      if (new Date() > new Date(this.tokenExpiry)) {
        await this.refreshAccessToken()
      }

      // Test connection by getting account info
      await this.getAccount()

      this.isConnected = true
      logger.info("Connected to Tastytrade successfully")

      return true
    } catch (error) {
      this.isConnected = false
      this.lastError = error.message
      logger.error(`Failed to connect to Tastytrade: ${error.message}`)
      throw new ApiError(500, `Failed to connect to Tastytrade: ${error.message}`)
    }
  }

  /**
   * Refresh access token
   * @returns {Promise<void>}
   */
  async refreshAccessToken() {
    try {
      logger.info("Refreshing Tastytrade access token")

      const response = await fetch(`${this.baseUrl}/sessions/refresh`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          refresh_token: this.refreshToken,
        }),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || `HTTP error ${response.status}`)
      }

      const data = await response.json()

      this.accessToken = data.access_token
      this.refreshToken = data.refresh_token
      this.tokenExpiry = new Date(Date.now() + data.expires_in * 1000)

      logger.info("Tastytrade access token refreshed successfully")
    } catch (error) {
      logger.error(`Failed to refresh Tastytrade access token: ${error.message}`)
      throw new ApiError(500, `Failed to refresh Tastytrade access token: ${error.message}`)
    }
  }

  /**
   * Make API request to Tastytrade
   * @param {string} endpoint - API endpoint
   * @param {string} method - HTTP method
   * @param {Object} data - Request data
   * @returns {Promise<Object>} Response data
   */
  async makeRequest(endpoint, method = "GET", data = null) {
    try {
      // Check if access token is expired
      if (new Date() > new Date(this.tokenExpiry)) {
        await this.refreshAccessToken()
      }

      const url = `${this.baseUrl}/${endpoint}`

      const options = {
        method,
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          "Content-Type": "application/json",
        },
      }

      if (data && (method === "POST" || method === "PUT" || method === "PATCH")) {
        options.body = JSON.stringify(data)
      }

      const response = await fetch(url, options)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || `HTTP error ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      logger.error(`Tastytrade API request failed: ${error.message}`)
      throw new ApiError(500, `Tastytrade API request failed: ${error.message}`)
    }
  }

  /**
   * Get account information
   * @returns {Promise<Object>} Account information
   */
  async getAccount() {
    try {
      const response = await this.makeRequest(`accounts/${this.accountId}`)

      return {
        id: response.account.account_number,
        name: response.account.nickname,
        type: response.account.account_type_name,
        status: response.account.status,
        balance: response.account.equity,
        currency: "USD", // Tastytrade accounts are in USD
      }
    } catch (error) {
      logger.error(`Failed to get Tastytrade account: ${error.message}`)
      throw new ApiError(500, `Failed to get Tastytrade account: ${error.message}`)
    }
  }

  /**
   * Get account balance
   * @returns {Promise<number>} Account balance
   */
  async getBalance() {
    try {
      const response = await this.makeRequest(`accounts/${this.accountId}/balances`)

      return Number.parseFloat(response.balance.equity)
    } catch (error) {
      logger.error(`Failed to get Tastytrade balance: ${error.message}`)
      throw new ApiError(500, `Failed to get Tastytrade balance: ${error.message}`)
    }
  }

  /**
   * Get open positions
   * @returns {Promise<Array>} Open positions
   */
  async getPositions() {
    try {
      const response = await this.makeRequest(`accounts/${this.accountId}/positions`)

      return response.items.map((position) => ({
        symbol: position.symbol,
        assetClass: this.mapAssetClass(position.instrument_type),
        direction: position.quantity > 0 ? "long" : "short",
        quantity: Math.abs(position.quantity),
        entryPrice: position.average_open_price,
        currentPrice: position.mark_price,
        marketValue: position.mark_value,
        unrealizedPL: position.unrealized_day_pl_point,
        unrealizedPLPercent: (position.unrealized_day_pl_point / position.average_open_price) * 100,
        openTime: new Date(position.created_at),
      }))
    } catch (error) {
      logger.error(`Failed to get Tastytrade positions: ${error.message}`)
      throw new ApiError(500, `Failed to get Tastytrade positions: ${error.message}`)
    }
  }

  /**
   * Map Tastytrade asset class to platform asset class
   * @param {string} instrumentType - Tastytrade instrument type
   * @returns {string} Platform asset class
   */
  mapAssetClass(instrumentType) {
    const mapping = {
      Equity: "stock",
      "Equity Option": "option",
      Future: "future",
      "Future Option": "option",
      "Crypto Currency": "crypto",
    }

    return mapping[instrumentType] || "stock"
  }

  /**
   * Place a market order
   * @param {Object} order - Order details
   * @returns {Promise<Object>} Order result
   */
  async placeMarketOrder(order) {
    try {
      const data = {
        account_number: this.accountId,
        source: "API",
        order_type: "Market",
        price_effect: order.direction === "long" ? "Debit" : "Credit",
        legs: [
          {
            instrument_type: this.mapToTastytradeAssetClass(order.assetClass),
            symbol: order.symbol,
            action: order.direction === "long" ? "Buy" : "Sell",
            quantity: order.quantity,
          },
        ],
      }

      const response = await this.makeRequest("orders", "POST", data)

      return {
        id: response.order.id,
        symbol: order.symbol,
        type: "market",
        direction: order.direction,
        quantity: order.quantity,
        status: response.order.status,
        filledPrice: response.order.price,
        timestamp: new Date(response.order.created_at).toISOString(),
      }
    } catch (error) {
      logger.error(`Failed to place Tastytrade market order: ${error.message}`)
      throw new ApiError(500, `Failed to place Tastytrade market order: ${error.message}`)
    }
  }

  /**
   * Map platform asset class to Tastytrade asset class
   * @param {string} assetClass - Platform asset class
   * @returns {string} Tastytrade asset class
   */
  mapToTastytradeAssetClass(assetClass) {
    const mapping = {
      stock: "Equity",
      option: "Equity Option",
      future: "Future",
      crypto: "Crypto Currency",
    }

    return mapping[assetClass] || "Equity"
  }

  /**
   * Get market data
   * @param {string} symbol - Symbol
   * @returns {Promise<Object>} Market data
   */
  async getMarketData(symbol) {
    try {
      const response = await this.makeRequest(`market-data/quotes/${symbol}`)

      return {
        symbol,
        bid: response.quote.bid,
        ask: response.quote.ask,
        last: response.quote.last,
        volume: response.quote.volume,
        time: new Date(response.quote.updated_at).toISOString(),
      }
    } catch (error) {
      logger.error(`Failed to get Tastytrade market data: ${error.message}`)
      throw new ApiError(500, `Failed to get Tastytrade market data: ${error.message}`)
    }
  }
}

module.exports = TastytradeAdapter
