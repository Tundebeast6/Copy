/**
 * OANDA Broker Adapter
 *
 * This file implements the OANDA broker adapter.
 */

const BaseBroker = require("../base.broker")
const { ApiError } = require("../../utils/errors")
const logger = require("../../config/logger")

/**
 * OANDA Broker Adapter
 * @class OandaAdapter
 * @extends BaseBroker
 */
class OandaAdapter extends BaseBroker {
  /**
   * Create an OANDA broker instance
   * @param {Object} credentials - OANDA credentials
   * @param {Object} config - OANDA configuration
   */
  constructor(credentials, config = {}) {
    super(credentials, config)

    this.apiKey = credentials.apiKey
    this.accountId = config.accountId
    this.baseUrl = config.baseUrl || process.env.OANDA_BASE_URL || "https://api-fxpractice.oanda.com"
    this.apiVersion = "v3"
    this.headers = {
      Authorization: `Bearer ${this.apiKey}`,
      "Content-Type": "application/json",
      "Accept-Datetime-Format": "RFC3339",
    }
  }

  /**
   * Connect to OANDA
   * @returns {Promise<boolean>} Connection status
   */
  async connect() {
    try {
      logger.info("Connecting to OANDA")

      // Validate credentials
      if (!this.apiKey) {
        throw new Error("API key is required")
      }

      if (!this.accountId) {
        throw new Error("Account ID is required")
      }

      // Test connection by getting account info
      await this.getAccount()

      this.isConnected = true
      logger.info("Connected to OANDA successfully")

      return true
    } catch (error) {
      this.isConnected = false
      this.lastError = error.message
      logger.error(`Failed to connect to OANDA: ${error.message}`)
      throw new ApiError(500, `Failed to connect to OANDA: ${error.message}`)
    }
  }

  /**
   * Make API request to OANDA
   * @param {string} endpoint - API endpoint
   * @param {string} method - HTTP method
   * @param {Object} data - Request data
   * @returns {Promise<Object>} Response data
   */
  async makeRequest(endpoint, method = "GET", data = null) {
    try {
      const url = `${this.baseUrl}/${this.apiVersion}/${endpoint}`

      const options = {
        method,
        headers: this.headers,
      }

      if (data && (method === "POST" || method === "PUT" || method === "PATCH")) {
        options.body = JSON.stringify(data)
      }

      const response = await fetch(url, options)

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.errorMessage || `HTTP error ${response.status}`)
      }

      return await response.json()
    } catch (error) {
      logger.error(`OANDA API request failed: ${error.message}`)
      throw new ApiError(500, `OANDA API request failed: ${error.message}`)
    }
  }

  /**
   * Get account information
   * @returns {Promise<Object>} Account information
   */
  async getAccount() {
    try {
      const endpoint = `accounts/${this.accountId}`
      const response = await this.makeRequest(endpoint)

      return response.account
    } catch (error) {
      logger.error(`Failed to get OANDA account: ${error.message}`)
      throw new ApiError(500, `Failed to get OANDA account: ${error.message}`)
    }
  }

  /**
   * Get account balance
   * @returns {Promise<number>} Account balance
   */
  async getBalance() {
    try {
      const account = await this.getAccount()

      return Number.parseFloat(account.balance)
    } catch (error) {
      logger.error(`Failed to get OANDA balance: ${error.message}`)
      throw new ApiError(500, `Failed to get OANDA balance: ${error.message}`)
    }
  }

  /**
   * Get open positions
   * @returns {Promise<Array>} Open positions
   */
  async getPositions() {
    try {
      const endpoint = `accounts/${this.accountId}/openPositions`
      const response = await this.makeRequest(endpoint)

      return response.positions.map((position) => ({
        symbol: position.instrument,
        direction: position.long.units > 0 ? "long" : "short",
        quantity: Math.abs(position.long.units > 0 ? position.long.units : position.short.units),
        entryPrice: position.long.units > 0 ? position.long.averagePrice : position.short.averagePrice,
        currentPrice: 0, // Need to get current price separately
        unrealizedPL: position.long.units > 0 ? position.long.unrealizedPL : position.short.unrealizedPL,
      }))
    } catch (error) {
      logger.error(`Failed to get OANDA positions: ${error.message}`)
      throw new ApiError(500, `Failed to get OANDA positions: ${error.message}`)
    }
  }

  /**
   * Place a market order
   * @param {Object} order - Order details
   * @returns {Promise<Object>} Order result
   */
  async placeMarketOrder(order) {
    try {
      const endpoint = `accounts/${this.accountId}/orders`

      const data = {
        order: {
          type: "MARKET",
          instrument: order.symbol,
          units: order.direction === "long" ? order.quantity : -order.quantity,
          timeInForce: "FOK",
          positionFill: "DEFAULT",
        },
      }

      // Add stop loss if provided
      if (order.stopLoss) {
        data.order.stopLossOnFill = {
          price: order.stopLoss.toString(),
          timeInForce: "GTC",
        }
      }

      // Add take profit if provided
      if (order.takeProfit) {
        data.order.takeProfitOnFill = {
          price: order.takeProfit.toString(),
          timeInForce: "GTC",
        }
      }

      const response = await this.makeRequest(endpoint, "POST", data)

      return {
        id: response.orderCreateTransaction.id,
        symbol: response.orderCreateTransaction.instrument,
        type: "market",
        direction: response.orderCreateTransaction.units > 0 ? "long" : "short",
        quantity: Math.abs(response.orderCreateTransaction.units),
        status: response.orderFillTransaction ? "filled" : "pending",
        filledPrice: response.orderFillTransaction ? response.orderFillTransaction.price : null,
        timestamp: response.orderCreateTransaction.time,
      }
    } catch (error) {
      logger.error(`Failed to place OANDA market order: ${error.message}`)
      throw new ApiError(500, `Failed to place OANDA market order: ${error.message}`)
    }
  }

  /**
   * Get market data
   * @param {string} symbol - Symbol
   * @returns {Promise<Object>} Market data
   */
  async getMarketData(symbol) {
    try {
      const endpoint = `instruments/${symbol}/candles?count=1&price=M&granularity=S5`
      const response = await this.makeRequest(endpoint)

      const candle = response.candles[0]

      return {
        symbol,
        bid: Number.parseFloat(candle.mid.c),
        ask: Number.parseFloat(candle.mid.c), // OANDA doesn't provide bid/ask in candles
        time: candle.time,
      }
    } catch (error) {
      logger.error(`Failed to get OANDA market data: ${error.message}`)
      throw new ApiError(500, `Failed to get OANDA market data: ${error.message}`)
    }
  }
}

module.exports = OandaAdapter
