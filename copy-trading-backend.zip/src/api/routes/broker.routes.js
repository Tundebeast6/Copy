/**
 * Broker Routes
 *
 * This file defines routes for broker operations.
 */

const express = require("express")
const brokerController = require("../controllers/broker.controller")
const { authenticate } = require("../middlewares/auth.middleware")
const validate = require("../middlewares/validation.middleware")
const { brokerValidation } = require("../../utils/validators")

const router = express.Router()

// Apply authentication middleware to all routes
router.use(authenticate)

/**
 * @route GET /api/brokers
 * @desc Get all brokers
 * @access Private
 */
router.get("/", brokerController.getAllBrokers)

/**
 * @route GET /api/brokers/:id
 * @desc Get broker by ID
 * @access Private
 */
router.get("/:id", brokerController.getBrokerById)

/**
 * @route POST /api/brokers/connect
 * @desc Connect a broker
 * @access Private
 */
router.post("/connect", validate(brokerValidation.connect), brokerController.connectBroker)

/**
 * @route PUT /api/brokers/:id
 * @desc Update broker
 * @access Private
 */
router.put("/:id", validate(brokerValidation.update), brokerController.updateBroker)

/**
 * @route DELETE /api/brokers/:id
 * @desc Disconnect broker
 * @access Private
 */
router.delete("/:id", brokerController.disconnectBroker)

/**
 * @route POST /api/brokers/:id/sync
 * @desc Sync broker
 * @access Private
 */
router.post("/:id/sync", brokerController.syncBroker)

/**
 * @route GET /api/brokers/:id/positions
 * @desc Get broker positions
 * @access Private
 */
router.get("/:id/positions", brokerController.getBrokerPositions)

/**
 * @route GET /api/brokers/:id/orders
 * @desc Get broker order history
 * @access Private
 */
router.get("/:id/orders", brokerController.getBrokerOrderHistory)

module.exports = router
