/**
 * Broker Controller
 *
 * This file contains handlers for broker-related routes.
 */

const brokerService = require("../../services/broker.service")
const { ApiError } = require("../../utils/errors")

/**
 * Get all brokers
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getAllBrokers = async (req, res, next) => {
  try {
    const userId = req.user._id

    const brokers = await brokerService.getAllBrokers(userId)

    res.status(200).json({
      success: true,
      data: brokers,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get broker by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getBrokerById = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { id } = req.params

    const broker = await brokerService.getBrokerById(id, userId)

    res.status(200).json({
      success: true,
      data: broker,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Connect broker
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const connectBroker = async (req, res, next) => {
  try {
    const userId = req.user._id

    const brokerData = {
      userId,
      ...req.body,
    }

    const broker = await brokerService.connectBroker(brokerData)

    res.status(201).json({
      success: true,
      message: "Broker connected successfully",
      data: broker,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Update broker
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const updateBroker = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { id } = req.params

    const broker = await brokerService.updateBroker(id, req.body, userId)

    res.status(200).json({
      success: true,
      message: "Broker updated successfully",
      data: broker,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Disconnect broker
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const disconnectBroker = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { id } = req.params

    await brokerService.disconnectBroker(id, userId)

    res.status(200).json({
      success: true,
      message: "Broker disconnected successfully",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Sync broker
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const syncBroker = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { id } = req.params

    const broker = await brokerService.syncBroker(id, userId)

    res.status(200).json({
      success: true,
      message: "Broker synced successfully",
      data: broker,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get broker positions
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getBrokerPositions = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { id } = req.params

    const positions = await brokerService.getBrokerPositions(id, userId)

    res.status(200).json({
      success: true,
      data: positions,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get broker order history
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getBrokerOrderHistory = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { id } = req.params
    const { limit, from, to } = req.query

    const options = {
      limit: limit ? Number.parseInt(limit) : undefined,
      from: from ? new Date(from) : undefined,
      to: to ? new Date(to) : undefined,
    }

    const orderHistory = await brokerService.getBrokerOrderHistory(id, userId, options)

    res.status(200).json({
      success: true,
      data: orderHistory,
    })
  } catch (error) {
    next(error)
  }
}

module.exports = {
  getAllBrokers,
  getBrokerById,
  connectBroker,
  updateBroker,
  disconnectBroker,
  syncBroker,
  getBrokerPositions,
  getBrokerOrderHistory,
}
