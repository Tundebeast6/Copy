/**
 * Trader Controller
 *
 * This file contains handlers for trader-related routes.
 */

const traderService = require("../../services/trader.service")
const { ApiError } = require("../../utils/errors")

/**
 * Get all traders
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getAllTraders = async (req, res, next) => {
  try {
    const { page = 1, limit = 10, sort = "winRate", order = "desc", filter } = req.query

    const traders = await traderService.getAllTraders({
      page: Number.parseInt(page),
      limit: Number.parseInt(limit),
      sort,
      order,
      filter: filter ? JSON.parse(filter) : {},
    })

    res.status(200).json({
      success: true,
      data: traders,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get trader by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getTraderById = async (req, res, next) => {
  try {
    const { id } = req.params

    const trader = await traderService.getTraderById(id)

    if (!trader) {
      throw new ApiError(404, "Trader not found")
    }

    res.status(200).json({
      success: true,
      data: trader,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get trader profile
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getTraderProfile = async (req, res, next) => {
  try {
    const userId = req.user._id

    const trader = await traderService.getTraderByUserId(userId)

    if (!trader) {
      throw new ApiError(404, "Trader profile not found")
    }

    res.status(200).json({
      success: true,
      data: trader,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Create trader profile
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const createTraderProfile = async (req, res, next) => {
  try {
    const userId = req.user._id

    // Check if trader profile already exists
    const existingTrader = await traderService.getTraderByUserId(userId)

    if (existingTrader) {
      throw new ApiError(409, "Trader profile already exists")
    }

    const traderData = {
      userId,
      ...req.body,
    }

    const trader = await traderService.createTrader(traderData)

    res.status(201).json({
      success: true,
      message: "Trader profile created successfully",
      data: trader,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Update trader profile
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const updateTraderProfile = async (req, res, next) => {
  try {
    const userId = req.user._id

    const trader = await traderService.getTraderByUserId(userId)

    if (!trader) {
      throw new ApiError(404, "Trader profile not found")
    }

    const updatedTrader = await traderService.updateTrader(trader._id, req.body)

    res.status(200).json({
      success: true,
      message: "Trader profile updated successfully",
      data: updatedTrader,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Follow a trader
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const followTrader = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { id: traderId } = req.params
    const { copySettings } = req.body

    await traderService.followTrader(traderId, userId, copySettings)

    res.status(200).json({
      success: true,
      message: "Trader followed successfully",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Unfollow a trader
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const unfollowTrader = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { id: traderId } = req.params

    await traderService.unfollowTrader(traderId, userId)

    res.status(200).json({
      success: true,
      message: "Trader unfollowed successfully",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get trader's trades
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getTraderTrades = async (req, res, next) => {
  try {
    const { id: traderId } = req.params
    const { page = 1, limit = 10, status } = req.query

    const trades = await traderService.getTraderTrades(traderId, {
      page: Number.parseInt(page),
      limit: Number.parseInt(limit),
      status,
    })

    res.status(200).json({
      success: true,
      data: trades,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get trader's followers
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getTraderFollowers = async (req, res, next) => {
  try {
    const { id: traderId } = req.params
    const { page = 1, limit = 10 } = req.query

    const followers = await traderService.getTraderFollowers(traderId, {
      page: Number.parseInt(page),
      limit: Number.parseInt(limit),
    })

    res.status(200).json({
      success: true,
      data: followers,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get trader's performance
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getTraderPerformance = async (req, res, next) => {
  try {
    const { id: traderId } = req.params
    const { period = "all" } = req.query

    const performance = await traderService.getTraderPerformance(traderId, period)

    res.status(200).json({
      success: true,
      data: performance,
    })
  } catch (error) {
    next(error)
  }
}

module.exports = {
  getAllTraders,
  getTraderById,
  getTraderProfile,
  createTraderProfile,
  updateTraderProfile,
  followTrader,
  unfollowTrader,
  getTraderTrades,
  getTraderFollowers,
  getTraderPerformance,
}
