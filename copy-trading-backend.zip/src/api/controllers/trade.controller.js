/**
 * Trade Controller
 *
 * This file contains handlers for trade-related routes.
 */

const tradeService = require("../../services/trade.service")
const { ApiError } = require("../../utils/errors")

/**
 * Get all trades
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getAllTrades = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { page = 1, limit = 10, status, symbol, assetClass, direction } = req.query

    const trades = await tradeService.getAllTrades(userId, {
      page: Number.parseInt(page),
      limit: Number.parseInt(limit),
      status,
      symbol,
      assetClass,
      direction,
    })

    res.status(200).json({
      success: true,
      data: trades,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get trade by ID
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getTradeById = async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.user._id

    const trade = await tradeService.getTradeById(id, userId)

    if (!trade) {
      throw new ApiError(404, "Trade not found")
    }

    res.status(200).json({
      success: true,
      data: trade,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Create a new trade
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const createTrade = async (req, res, next) => {
  try {
    const userId = req.user._id

    // Check if user is a trader
    const isTrader = await tradeService.isUserTrader(userId)

    if (!isTrader) {
      throw new ApiError(403, "Only traders can create trades")
    }

    const tradeData = {
      ...req.body,
      traderId: isTrader._id,
    }

    const trade = await tradeService.createTrade(tradeData)

    // Notify followers about the new trade via WebSockets
    // This will be handled by the WebSocket server

    res.status(201).json({
      success: true,
      message: "Trade created successfully",
      data: trade,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Update a trade
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const updateTrade = async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.user._id

    // Check if user is a trader
    const isTrader = await tradeService.isUserTrader(userId)

    if (!isTrader) {
      throw new ApiError(403, "Only traders can update trades")
    }

    // Check if trade belongs to the trader
    const trade = await tradeService.getTradeById(id)

    if (!trade) {
      throw new ApiError(404, "Trade not found")
    }

    if (trade.traderId.toString() !== isTrader._id.toString()) {
      throw new ApiError(403, "You can only update your own trades")
    }

    const updatedTrade = await tradeService.updateTrade(id, req.body)

    // Notify followers about the updated trade via WebSockets
    // This will be handled by the WebSocket server

    res.status(200).json({
      success: true,
      message: "Trade updated successfully",
      data: updatedTrade,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Close a trade
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const closeTrade = async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.user._id
    const { exitPrice } = req.body

    // Check if user is a trader
    const isTrader = await tradeService.isUserTrader(userId)

    if (!isTrader) {
      throw new ApiError(403, "Only traders can close trades")
    }

    // Check if trade belongs to the trader
    const trade = await tradeService.getTradeById(id)

    if (!trade) {
      throw new ApiError(404, "Trade not found")
    }

    if (trade.traderId.toString() !== isTrader._id.toString()) {
      throw new ApiError(403, "You can only close your own trades")
    }

    if (trade.status === "closed") {
      throw new ApiError(400, "Trade is already closed")
    }

    const closedTrade = await tradeService.closeTrade(id, exitPrice)

    // Notify followers about the closed trade via WebSockets
    // This will be handled by the WebSocket server

    res.status(200).json({
      success: true,
      message: "Trade closed successfully",
      data: closedTrade,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Delete a trade
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const deleteTrade = async (req, res, next) => {
  try {
    const { id } = req.params
    const userId = req.user._id

    // Check if user is a trader
    const isTrader = await tradeService.isUserTrader(userId)

    if (!isTrader) {
      throw new ApiError(403, "Only traders can delete trades")
    }

    // Check if trade belongs to the trader
    const trade = await tradeService.getTradeById(id)

    if (!trade) {
      throw new ApiError(404, "Trade not found")
    }

    if (trade.traderId.toString() !== isTrader._id.toString()) {
      throw new ApiError(403, "You can only delete your own trades")
    }

    await tradeService.deleteTrade(id)

    res.status(200).json({
      success: true,
      message: "Trade deleted successfully",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get copied trades
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getCopiedTrades = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { page = 1, limit = 10, status } = req.query

    const trades = await tradeService.getCopiedTrades(userId, {
      page: Number.parseInt(page),
      limit: Number.parseInt(limit),
      status,
    })

    res.status(200).json({
      success: true,
      data: trades,
    })
  } catch (error) {
    next(error)
  }
}

module.exports = {
  getAllTrades,
  getTradeById,
  createTrade,
  updateTrade,
  closeTrade,
  deleteTrade,
  getCopiedTrades,
}
