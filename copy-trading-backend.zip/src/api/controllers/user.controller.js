/**
 * User Controller
 *
 * This file contains handlers for user-related routes.
 */

const userService = require("../../services/user.service")
const portfolioService = require("../../services/portfolio.service")
const { ApiError } = require("../../utils/errors")

/**
 * Get user profile
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getUserProfile = async (req, res, next) => {
  try {
    const userId = req.user._id

    const profile = await userService.getUserProfile(userId)

    res.status(200).json({
      success: true,
      data: profile,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Update user profile
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const updateUserProfile = async (req, res, next) => {
  try {
    const userId = req.user._id

    const profile = await userService.updateUserProfile(userId, req.body)

    res.status(200).json({
      success: true,
      message: "Profile updated successfully",
      data: profile,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Change password
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const changePassword = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { currentPassword, newPassword } = req.body

    await userService.changePassword(userId, currentPassword, newPassword)

    res.status(200).json({
      success: true,
      message: "Password changed successfully",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Enable two-factor authentication
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const enableTwoFactor = async (req, res, next) => {
  try {
    const userId = req.user._id

    const result = await userService.enableTwoFactor(userId)

    res.status(200).json({
      success: true,
      message: "Two-factor authentication setup initiated",
      data: result,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Verify two-factor authentication
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const verifyTwoFactor = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { code } = req.body

    await userService.verifyTwoFactor(userId, code)

    res.status(200).json({
      success: true,
      message: "Two-factor authentication enabled successfully",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Disable two-factor authentication
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const disableTwoFactor = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { code } = req.body

    await userService.disableTwoFactor(userId, code)

    res.status(200).json({
      success: true,
      message: "Two-factor authentication disabled successfully",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get user portfolio
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getUserPortfolio = async (req, res, next) => {
  try {
    const userId = req.user._id

    const portfolio = await portfolioService.getUserPortfolio(userId)

    res.status(200).json({
      success: true,
      data: portfolio,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Sync user portfolio
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const syncUserPortfolio = async (req, res, next) => {
  try {
    const userId = req.user._id

    const portfolio = await portfolioService.syncPortfolio(userId)

    res.status(200).json({
      success: true,
      message: "Portfolio synced successfully",
      data: portfolio,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get portfolio performance
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getPortfolioPerformance = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { period } = req.query

    const performance = await portfolioService.getPortfolioPerformance(userId, period)

    res.status(200).json({
      success: true,
      data: performance,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get portfolio positions
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getPortfolioPositions = async (req, res, next) => {
  try {
    const userId = req.user._id

    const positions = await portfolioService.getPortfolioPositions(userId)

    res.status(200).json({
      success: true,
      data: positions,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get portfolio statistics
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getPortfolioStats = async (req, res, next) => {
  try {
    const userId = req.user._id

    const stats = await portfolioService.getPortfolioStats(userId)

    res.status(200).json({
      success: true,
      data: stats,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get followed traders
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getFollowedTraders = async (req, res, next) => {
  try {
    const userId = req.user._id

    const traders = await userService.getFollowedTraders(userId)

    res.status(200).json({
      success: true,
      data: traders,
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Delete user account
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const deleteAccount = async (req, res, next) => {
  try {
    const userId = req.user._id
    const { password } = req.body

    await userService.deleteAccount(userId, password)

    res.status(200).json({
      success: true,
      message: "Account deleted successfully",
    })
  } catch (error) {
    next(error)
  }
}

module.exports = {
  getUserProfile,
  updateUserProfile,
  changePassword,
  enableTwoFactor,
  verifyTwoFactor,
  disableTwoFactor,
  getUserPortfolio,
  syncUserPortfolio,
  getPortfolioPerformance,
  getPortfolioPositions,
  getPortfolioStats,
  getFollowedTraders,
  deleteAccount,
}
