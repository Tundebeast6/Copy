/**
 * Authentication Controller
 *
 * This file contains handlers for authentication-related routes.
 */

const authService = require("../../services/auth.service")
const { ApiError } = require("../../utils/errors")

/**
 * Register a new user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const register = async (req, res, next) => {
  try {
    const { email, password, firstName, lastName, role } = req.body

    const { user, token, refreshToken } = await authService.register({
      email,
      password,
      firstName,
      lastName,
      role: role || "follower", // Default role is follower
    })

    res.status(201).json({
      success: true,
      message: "User registered successfully",
      data: {
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        },
        token,
        refreshToken,
      },
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Login user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const login = async (req, res, next) => {
  try {
    const { email, password } = req.body

    const { user, token, refreshToken } = await authService.login(email, password)

    res.status(200).json({
      success: true,
      message: "Login successful",
      data: {
        user: {
          id: user._id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role,
        },
        token,
        refreshToken,
      },
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Refresh access token
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const refreshToken = async (req, res, next) => {
  try {
    const { refreshToken } = req.body

    const { token, newRefreshToken } = await authService.refreshToken(refreshToken)

    res.status(200).json({
      success: true,
      message: "Token refreshed successfully",
      data: {
        token,
        refreshToken: newRefreshToken,
      },
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Logout user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const logout = async (req, res, next) => {
  try {
    const userId = req.user._id

    await authService.logout(userId)

    res.status(200).json({
      success: true,
      message: "Logout successful",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Verify user email
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const verifyEmail = async (req, res, next) => {
  try {
    const { token } = req.body

    await authService.verifyEmail(token)

    res.status(200).json({
      success: true,
      message: "Email verified successfully",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Request password reset
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body

    await authService.forgotPassword(email)

    res.status(200).json({
      success: true,
      message: "Password reset email sent",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Reset password with token
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const resetPassword = async (req, res, next) => {
  try {
    const { token, password } = req.body

    await authService.resetPassword(token, password)

    res.status(200).json({
      success: true,
      message: "Password reset successful",
    })
  } catch (error) {
    next(error)
  }
}

/**
 * Get current user
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const getCurrentUser = async (req, res, next) => {
  try {
    res.status(200).json({
      success: true,
      data: {
        user: {
          id: req.user._id,
          email: req.user.email,
          firstName: req.user.firstName,
          lastName: req.user.lastName,
          role: req.user.role,
        },
      },
    })
  } catch (error) {
    next(error)
  }
}

module.exports = {
  register,
  login,
  refreshToken,
  logout,
  verifyEmail,
  forgotPassword,
  resetPassword,
  getCurrentUser,
}
