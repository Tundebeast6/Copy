/**
 * API Routes Index
 *
 * This file aggregates all API routes and exports them as a single router.
 */

const express = require("express")
const authRoutes = require("./routes/auth.routes")
const userRoutes = require("./routes/user.routes")
const traderRoutes = require("./routes/trader.routes")
const brokerRoutes = require("./routes/broker.routes")
const tradeRoutes = require("./routes/trade.routes")

const router = express.Router()

// API routes
router.use("/auth", authRoutes)
router.use("/users", userRoutes)
router.use("/traders", traderRoutes)
router.use("/brokers", brokerRoutes)
router.use("/trades", tradeRoutes)

// API documentation route
router.get("/", (req, res) => {
  res.json({
    message: "Copy Trading Platform API",
    version: "1.0.0",
    endpoints: {
      auth: "/api/auth",
      users: "/api/users",
      traders: "/api/traders",
      brokers: "/api/brokers",
      trades: "/api/trades",
    },
  })
})

module.exports = router
