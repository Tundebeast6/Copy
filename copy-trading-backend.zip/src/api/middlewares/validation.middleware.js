/**
 * Validation Middleware
 *
 * This middleware validates request data using Joi schemas.
 */

const { ApiError } = require("../../utils/errors")

/**
 * Validate request data against a Joi schema
 * @param {Object} schema - Joi schema
 * @param {String} property - Request property to validate (body, params, query)
 * @returns {Function} Middleware function
 */
const validate = (schema, property = "body") => {
  return (req, res, next) => {
    const { error } = schema.validate(req[property], {
      abortEarly: false,
      stripUnknown: true,
    })

    if (!error) {
      return next()
    }

    const errors = error.details.map((detail) => detail.message)

    next(new ApiError(400, "Validation error", errors))
  }
}

module.exports = validate
