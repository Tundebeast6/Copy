/**
 * Error Handling Middleware
 *
 * This middleware handles errors and sends appropriate responses.
 */

const { ApiError } = require("../../utils/errors")
const logger = require("../../config/logger")

/**
 * Error handling middleware
 * @param {Error} err - Error object
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const errorMiddleware = (err, req, res, next) => {
  // Log error
  logger.error(`${err.name}: ${err.message}`, {
    stack: err.stack,
    path: req.path,
    method: req.method,
    ip: req.ip,
  })

  // Handle ApiError
  if (err instanceof ApiError) {
    return res.status(err.statusCode).json({
      success: false,
      message: err.message,
      error: err.name,
      ...(process.env.NODE_ENV === "development" && { stack: err.stack }),
    })
  }

  // Handle Mongoose validation errors
  if (err.name === "ValidationError") {
    const errors = Object.values(err.errors).map((error) => error.message)

    return res.status(400).json({
      success: false,
      message: "Validation error",
      errors,
    })
  }

  // Handle Mongoose duplicate key errors
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue)[0]

    return res.status(409).json({
      success: false,
      message: `${field} already exists`,
      error: "Duplicate Key",
    })
  }

  // Handle other errors
  const statusCode = err.statusCode || 500
  const message = err.message || "Internal Server Error"

  res.status(statusCode).json({
    success: false,
    message,
    error: err.name || "Error",
    ...(process.env.NODE_ENV === "development" && { stack: err.stack }),
  })
}

module.exports = errorMiddleware
