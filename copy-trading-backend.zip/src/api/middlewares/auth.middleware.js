/**
 * Authentication Middleware
 *
 * This middleware verifies JWT tokens and attaches the user to the request.
 */

const jwt = require("jsonwebtoken")
const { jwt: jwtConfig } = require("../../config/env")
const { ApiError } = require("../../utils/errors")
const User = require("../../models/user.model")

/**
 * Authenticate user by verifying JWT token
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 * @param {Function} next - Express next function
 */
const authenticate = async (req, res, next) => {
  try {
    // Get token from Authorization header
    const authHeader = req.headers.authorization

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      throw new ApiError(401, "Authentication required")
    }

    const token = authHeader.split(" ")[1]

    if (!token) {
      throw new ApiError(401, "Authentication token required")
    }

    // Verify token
    const decoded = jwt.verify(token, jwtConfig.secret)

    // Find user
    const user = await User.findById(decoded.id).select("-password")

    if (!user) {
      throw new ApiError(401, "Invalid authentication token")
    }

    // Attach user to request
    req.user = user

    next()
  } catch (error) {
    if (error.name === "JsonWebTokenError") {
      return next(new ApiError(401, "Invalid authentication token"))
    }

    if (error.name === "TokenExpiredError") {
      return next(new ApiError(401, "Authentication token expired"))
    }

    next(error)
  }
}

/**
 * Check if user has required role
 * @param {String[]} roles - Array of allowed roles
 * @returns {Function} Middleware function
 */
const authorize = (roles = []) => {
  return (req, res, next) => {
    if (!req.user) {
      return next(new ApiError(401, "Authentication required"))
    }

    if (roles.length && !roles.includes(req.user.role)) {
      return next(new ApiError(403, "Insufficient permissions"))
    }

    next()
  }
}

module.exports = {
  authenticate,
  authorize,
}
