/**
 * Broker Service
 *
 * This file contains business logic for broker-related operations.
 */

const Broker = require("../models/broker.model")
const { createBroker } = require("../brokers/broker.factory")
const { ApiError, NotFoundError } = require("../utils/errors")
const logger = require("../config/logger")

/**
 * Get all brokers for a user
 * @param {string} userId - User ID
 * @returns {Promise<Array>} Brokers
 */
const getAllBrokers = async (userId) => {
  try {
    const brokers = await Broker.find({ userId })
    return brokers
  } catch (error) {
    logger.error(`Error in getAllBrokers service: ${error.message}`)
    throw error
  }
}

/**
 * Get broker by ID
 * @param {string} id - Broker ID
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Broker
 */
const getBrokerById = async (id, userId) => {
  try {
    const broker = await Broker.findOne({ _id: id, userId })

    if (!broker) {
      throw new NotFoundError("Broker not found")
    }

    return broker
  } catch (error) {
    logger.error(`Error in getBrokerById service: ${error.message}`)
    throw error
  }
}

/**
 * Connect a broker
 * @param {Object} brokerData - Broker data
 * @returns {Promise<Object>} Connected broker
 */
const connectBroker = async (brokerData) => {
  try {
    // Check if broker already exists
    const existingBroker = await Broker.findOne({
      userId: brokerData.userId,
      name: brokerData.name,
      accountId: brokerData.accountId,
    })

    if (existingBroker) {
      throw new ApiError(409, "Broker already connected")
    }

    // Validate broker connection
    try {
      // Create broker instance
      const brokerInstance = createBroker(brokerData.name, brokerData.credentials, { accountId: brokerData.accountId })

      // Connect to broker
      await brokerInstance.connect()

      // Get account info
      const account = await brokerInstance.getAccount()

      // Update broker data with account info
      brokerData.balance = account.balance || 0
      brokerData.currency = account.currency || "USD"
      brokerData.status = "connected"
    } catch (error) {
      logger.error(`Failed to connect to broker: ${error.message}`)

      // Set status to error
      brokerData.status = "error"
      brokerData.errorMessage = error.message
    }

    // Create broker
    const broker = await Broker.create(brokerData)

    return broker
  } catch (error) {
    logger.error(`Error in connectBroker service: ${error.message}`)
    throw error
  }
}

/**
 * Update broker
 * @param {string} id - Broker ID
 * @param {Object} brokerData - Broker data
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Updated broker
 */
const updateBroker = async (id, brokerData, userId) => {
  try {
    const broker = await Broker.findOne({ _id: id, userId })

    if (!broker) {
      throw new NotFoundError("Broker not found")
    }

    // Update allowed fields
    const allowedFields = ["label", "isActive"]

    allowedFields.forEach((field) => {
      if (brokerData[field] !== undefined) {
        broker[field] = brokerData[field]
      }
    })

    // Update credentials if provided
    if (brokerData.credentials) {
      Object.keys(brokerData.credentials).forEach((key) => {
        if (brokerData.credentials[key]) {
          broker.credentials[key] = brokerData.credentials[key]
        }
      })
    }

    // Test connection if credentials were updated
    if (brokerData.credentials) {
      try {
        // Get decrypted credentials
        const credentials = broker.getDecryptedCredentials()

        // Create broker instance
        const brokerInstance = createBroker(broker.name, credentials, { accountId: broker.accountId })

        // Connect to broker
        await brokerInstance.connect()

        // Get account info
        const account = await brokerInstance.getAccount()

        // Update broker data with account info
        broker.balance = account.balance || broker.balance
        broker.currency = account.currency || broker.currency
        broker.status = "connected"
        broker.errorMessage = null
      } catch (error) {
        logger.error(`Failed to connect to broker: ${error.message}`)

        // Set status to error
        broker.status = "error"
        broker.errorMessage = error.message
      }
    }

    await broker.save()

    return broker
  } catch (error) {
    logger.error(`Error in updateBroker service: ${error.message}`)
    throw error
  }
}

/**
 * Disconnect broker
 * @param {string} id - Broker ID
 * @param {string} userId - User ID
 * @returns {Promise<boolean>} Success status
 */
const disconnectBroker = async (id, userId) => {
  try {
    const broker = await Broker.findOne({ _id: id, userId })

    if (!broker) {
      throw new NotFoundError("Broker not found")
    }

    // Delete broker
    await Broker.deleteOne({ _id: id })

    return true
  } catch (error) {
    logger.error(`Error in disconnectBroker service: ${error.message}`)
    throw error
  }
}

/**
 * Sync broker
 * @param {string} id - Broker ID
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Synced broker
 */
const syncBroker = async (id, userId) => {
  try {
    const broker = await Broker.findOne({ _id: id, userId })

    if (!broker) {
      throw new NotFoundError("Broker not found")
    }

    try {
      // Get decrypted credentials
      const credentials = broker.getDecryptedCredentials()

      // Create broker instance
      const brokerInstance = createBroker(broker.name, credentials, { accountId: broker.accountId })

      // Connect to broker
      await brokerInstance.connect()

      // Get account info
      const account = await brokerInstance.getAccount()

      // Update broker data with account info
      broker.balance = account.balance || broker.balance
      broker.currency = account.currency || broker.currency
      broker.status = "connected"
      broker.errorMessage = null
      broker.lastSynced = new Date()

      await broker.save()
    } catch (error) {
      logger.error(`Failed to sync broker: ${error.message}`)

      // Set status to error
      broker.status = "error"
      broker.errorMessage = error.message
      broker.lastSynced = new Date()

      await broker.save()

      throw new ApiError(500, `Failed to sync broker: ${error.message}`)
    }

    return broker
  } catch (error) {
    logger.error(`Error in syncBroker service: ${error.message}`)
    throw error
  }
}

/**
 * Get broker positions
 * @param {string} id - Broker ID
 * @param {string} userId - User ID
 * @returns {Promise<Array>} Positions
 */
const getBrokerPositions = async (id, userId) => {
  try {
    const broker = await Broker.findOne({ _id: id, userId })

    if (!broker) {
      throw new NotFoundError("Broker not found")
    }

    try {
      // Get decrypted credentials
      const credentials = broker.getDecryptedCredentials()

      // Create broker instance
      const brokerInstance = createBroker(broker.name, credentials, { accountId: broker.accountId })

      // Connect to broker
      await brokerInstance.connect()

      // Get positions
      const positions = await brokerInstance.getPositions()

      return positions
    } catch (error) {
      logger.error(`Failed to get broker positions: ${error.message}`)
      throw new ApiError(500, `Failed to get broker positions: ${error.message}`)
    }
  } catch (error) {
    logger.error(`Error in getBrokerPositions service: ${error.message}`)
    throw error
  }
}

/**
 * Get broker order history
 * @param {string} id - Broker ID
 * @param {string} userId - User ID
 * @param {Object} options - Query options
 * @returns {Promise<Array>} Order history
 */
const getBrokerOrderHistory = async (id, userId, options = {}) => {
  try {
    const broker = await Broker.findOne({ _id: id, userId })

    if (!broker) {
      throw new NotFoundError("Broker not found")
    }

    try {
      // Get decrypted credentials
      const credentials = broker.getDecryptedCredentials()

      // Create broker instance
      const brokerInstance = createBroker(broker.name, credentials, { accountId: broker.accountId })

      // Connect to broker
      await brokerInstance.connect()

      // Get order history
      const orderHistory = await brokerInstance.getOrderHistory(options)

      return orderHistory
    } catch (error) {
      logger.error(`Failed to get broker order history: ${error.message}`)
      throw new ApiError(500, `Failed to get broker order history: ${error.message}`)
    }
  } catch (error) {
    logger.error(`Error in getBrokerOrderHistory service: ${error.message}`)
    throw error
  }
}

module.exports = {
  getAllBrokers,
  getBrokerById,
  connectBroker,
  updateBroker,
  disconnectBroker,
  syncBroker,
  getBrokerPositions,
  getBrokerOrderHistory,
}
