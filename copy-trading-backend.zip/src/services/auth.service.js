/**
 * Authentication Service
 *
 * This file contains business logic for authentication.
 */

const jwt = require("jsonwebtoken")
const crypto = require("crypto")
const { v4: uuidv4 } = require("uuid")
const User = require("../models/user.model")
const { jwt: jwtConfig } = require("../config/env")
const { UnauthorizedError, BadRequestError, NotFoundError } = require("../utils/errors")
const logger = require("../config/logger")

/**
 * Generate JWT token
 * @param {Object} payload - Token payload
 * @param {string} expiresIn - Token expiration time
 * @returns {string} JWT token
 */
const generateToken = (payload, expiresIn = jwtConfig.expiresIn) => {
  return jwt.sign(payload, jwtConfig.secret, { expiresIn })
}

/**
 * Generate refresh token
 * @returns {Object} Refresh token and expiry date
 */
const generateRefreshToken = () => {
  const token = uuidv4()
  const expiresAt = new Date()
  expiresAt.setDate(expiresAt.getDate() + 7) // 7 days

  return { token, expiresAt }
}

/**
 * Register a new user
 * @param {Object} userData - User data
 * @returns {Object} User, token, and refresh token
 */
const register = async (userData) => {
  try {
    // Check if user already exists
    const existingUser = await User.findOne({ email: userData.email })

    if (existingUser) {
      throw new BadRequestError("Email already in use")
    }

    // Create user
    const user = await User.create(userData)

    // Generate tokens
    const token = generateToken({ id: user._id })
    const refreshToken = generateRefreshToken()

    // Save refresh token
    user.refreshTokens.push(refreshToken)
    await user.save()

    // Generate email verification token
    const emailVerificationToken = crypto.randomBytes(32).toString("hex")
    user.emailVerificationToken = emailVerificationToken
    user.emailVerificationExpires = new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
    await user.save()

    // TODO: Send verification email

    return { user, token, refreshToken: refreshToken.token }
  } catch (error) {
    logger.error("Error in register service:", error)
    throw error
  }
}

/**
 * Login user
 * @param {string} email - User email
 * @param {string} password - User password
 * @returns {Object} User, token, and refresh token
 */
const login = async (email, password) => {
  try {
    // Find user
    const user = await User.findOne({ email })

    if (!user) {
      throw new UnauthorizedError("Invalid email or password")
    }

    // Check password
    const isPasswordValid = await user.comparePassword(password)

    if (!isPasswordValid) {
      throw new UnauthorizedError("Invalid email or password")
    }

    // Generate tokens
    const token = generateToken({ id: user._id })
    const refreshToken = generateRefreshToken()

    // Save refresh token
    user.refreshTokens.push(refreshToken)
    user.lastLogin = new Date()
    await user.save()

    return { user, token, refreshToken: refreshToken.token }
  } catch (error) {
    logger.error("Error in login service:", error)
    throw error
  }
}

/**
 * Refresh access token
 * @param {string} refreshToken - Refresh token
 * @returns {Object} New token and refresh token
 */
const refreshToken = async (refreshToken) => {
  try {
    // Find user with refresh token
    const user = await User.findOne({
      "refreshTokens.token": refreshToken,
      "refreshTokens.expiresAt": { $gt: new Date() },
    })

    if (!user) {
      throw new UnauthorizedError("Invalid refresh token")
    }

    // Remove old refresh token
    user.refreshTokens = user.refreshTokens.filter((token) => token.token !== refreshToken)

    // Generate new tokens
    const token = generateToken({ id: user._id })
    const newRefreshToken = generateRefreshToken()

    // Save new refresh token
    user.refreshTokens.push(newRefreshToken)
    await user.save()

    return { token, newRefreshToken: newRefreshToken.token }
  } catch (error) {
    logger.error("Error in refreshToken service:", error)
    throw error
  }
}

/**
 * Logout user
 * @param {string} userId - User ID
 * @returns {boolean} Success status
 */
const logout = async (userId) => {
  try {
    // Find user
    const user = await User.findById(userId)

    if (!user) {
      throw new NotFoundError("User not found")
    }

    // Clear refresh tokens
    user.refreshTokens = []
    await user.save()

    return true
  } catch (error) {
    logger.error("Error in logout service:", error)
    throw error
  }
}

/**
 * Verify user email
 * @param {string} token - Email verification token
 * @returns {boolean} Success status
 */
const verifyEmail = async (token) => {
  try {
    // Find user with verification token
    const user = await User.findOne({
      emailVerificationToken: token,
      emailVerificationExpires: { $gt: new Date() },
    })

    if (!user) {
      throw new BadRequestError("Invalid or expired verification token")
    }

    // Update user
    user.isEmailVerified = true
    user.emailVerificationToken = undefined
    user.emailVerificationExpires = undefined
    await user.save()

    return true
  } catch (error) {
    logger.error("Error in verifyEmail service:", error)
    throw error
  }
}

/**
 * Request password reset
 * @param {string} email - User email
 * @returns {boolean} Success status
 */
const forgotPassword = async (email) => {
  try {
    // Find user
    const user = await User.findOne({ email })

    if (!user) {
      throw new NotFoundError("User not found")
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString("hex")
    user.resetPasswordToken = resetToken
    user.resetPasswordExpires = new Date(Date.now() + 1 * 60 * 60 * 1000) // 1 hour
    await user.save()

    // TODO: Send password reset email

    return true
  } catch (error) {
    logger.error("Error in forgotPassword service:", error)
    throw error
  }
}

/**
 * Reset password with token
 * @param {string} token - Password reset token
 * @param {string} password - New password
 * @returns {boolean} Success status
 */
const resetPassword = async (token, password) => {
  try {
    // Find user with reset token
    const user = await User.findOne({
      resetPasswordToken: token,
      resetPasswordExpires: { $gt: new Date() },
    })

    if (!user) {
      throw new BadRequestError("Invalid or expired reset token")
    }

    // Update password
    user.password = password
    user.resetPasswordToken = undefined
    user.resetPasswordExpires = undefined
    await user.save()

    return true
  } catch (error) {
    logger.error("Error in resetPassword service:", error)
    throw error
  }
}

module.exports = {
  register,
  login,
  refreshToken,
  logout,
  verifyEmail,
  forgotPassword,
  resetPassword,
}
