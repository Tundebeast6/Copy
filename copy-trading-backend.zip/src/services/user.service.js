/**
 * User Service
 *
 * This file contains business logic for user-related operations.
 */

const User = require("../models/user.model")
const bcrypt = require("bcryptjs")
const crypto = require("crypto")
const { ApiError, NotFoundError } = require("../utils/errors")
const logger = require("../config/logger")

/**
 * Get user by ID
 * @param {string} id - User ID
 * @returns {Promise<Object>} User
 */
const getUserById = async (id) => {
  try {
    const user = await User.findById(id)

    if (!user) {
      throw new NotFoundError("User not found")
    }

    return user
  } catch (error) {
    logger.error(`Error in getUserById service: ${error.message}`)
    throw error
  }
}

/**
 * Get user profile
 * @param {string} id - User ID
 * @returns {Promise<Object>} User profile
 */
const getUserProfile = async (id) => {
  try {
    const user = await User.findById(id)

    if (!user) {
      throw new NotFoundError("User not found")
    }

    return {
      id: user._id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      fullName: user.fullName,
      role: user.role,
      isEmailVerified: user.isEmailVerified,
      isKycVerified: user.isKycVerified,
      profilePicture: user.profilePicture,
      phoneNumber: user.phoneNumber,
      country: user.country,
      lastLogin: user.lastLogin,
      twoFactorEnabled: user.twoFactorEnabled,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    }
  } catch (error) {
    logger.error(`Error in getUserProfile service: ${error.message}`)
    throw error
  }
}

/**
 * Update user profile
 * @param {string} id - User ID
 * @param {Object} profileData - Profile data
 * @returns {Promise<Object>} Updated user profile
 */
const updateUserProfile = async (id, profileData) => {
  try {
    const user = await User.findById(id)

    if (!user) {
      throw new NotFoundError("User not found")
    }

    // Update allowed fields
    const allowedFields = ["firstName", "lastName", "phoneNumber", "country", "profilePicture"]

    allowedFields.forEach((field) => {
      if (profileData[field] !== undefined) {
        user[field] = profileData[field]
      }
    })

    await user.save()

    return {
      id: user._id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      fullName: user.fullName,
      role: user.role,
      isEmailVerified: user.isEmailVerified,
      isKycVerified: user.isKycVerified,
      profilePicture: user.profilePicture,
      phoneNumber: user.phoneNumber,
      country: user.country,
      lastLogin: user.lastLogin,
      twoFactorEnabled: user.twoFactorEnabled,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    }
  } catch (error) {
    logger.error(`Error in updateUserProfile service: ${error.message}`)
    throw error
  }
}

/**
 * Change user password
 * @param {string} id - User ID
 * @param {string} currentPassword - Current password
 * @param {string} newPassword - New password
 * @returns {Promise<boolean>} Success status
 */
const changePassword = async (id, currentPassword, newPassword) => {
  try {
    const user = await User.findById(id)

    if (!user) {
      throw new NotFoundError("User not found")
    }

    // Check current password
    const isPasswordValid = await user.comparePassword(currentPassword)

    if (!isPasswordValid) {
      throw new ApiError(400, "Current password is incorrect")
    }

    // Update password
    user.password = newPassword

    // Clear refresh tokens
    user.refreshTokens = []

    await user.save()

    return true
  } catch (error) {
    logger.error(`Error in changePassword service: ${error.message}`)
    throw error
  }
}

/**
 * Enable two-factor authentication
 * @param {string} id - User ID
 * @returns {Promise<Object>} Two-factor secret and QR code URL
 */
const enableTwoFactor = async (id) => {
  try {
    const user = await User.findById(id)

    if (!user) {
      throw new NotFoundError("User not found")
    }

    // Check if 2FA is already enabled
    if (user.twoFactorEnabled) {
      throw new ApiError(400, "Two-factor authentication is already enabled")
    }

    // Generate secret
    const secret = crypto.randomBytes(20).toString("hex")

    // In a real implementation, would use a library like speakeasy to generate a proper TOTP secret
    // and QR code URL

    // Save secret
    user.twoFactorSecret = secret
    await user.save()

    return {
      secret,
      qrCodeUrl: `otpauth://totp/CopyTradingPlatform:${user.email}?secret=${secret}&issuer=CopyTradingPlatform`,
    }
  } catch (error) {
    logger.error(`Error in enableTwoFactor service: ${error.message}`)
    throw error
  }
}

/**
 * Verify two-factor authentication
 * @param {string} id - User ID
 * @param {string} code - Verification code
 * @returns {Promise<boolean>} Success status
 */
const verifyTwoFactor = async (id, code) => {
  try {
    const user = await User.findById(id)

    if (!user) {
      throw new NotFoundError("User not found")
    }

    // Check if 2FA is already enabled
    if (user.twoFactorEnabled) {
      throw new ApiError(400, "Two-factor authentication is already enabled")
    }

    // In a real implementation, would use a library like speakeasy to verify the TOTP code
    // For this example, we'll just check if the code is '123456' (dummy implementation)
    if (code !== "123456") {
      throw new ApiError(400, "Invalid verification code")
    }

    // Enable 2FA
    user.twoFactorEnabled = true
    await user.save()

    return true
  } catch (error) {
    logger.error(`Error in verifyTwoFactor service: ${error.message}`)
    throw error
  }
}

/**
 * Disable two-factor authentication
 * @param {string} id - User ID
 * @param {string} code - Verification code
 * @returns {Promise<boolean>} Success status
 */
const disableTwoFactor = async (id, code) => {
  try {
    const user = await User.findById(id)

    if (!user) {
      throw new NotFoundError("User not found")
    }

    // Check if 2FA is enabled
    if (!user.twoFactorEnabled) {
      throw new ApiError(400, "Two-factor authentication is not enabled")
    }

    // In a real implementation, would use a library like speakeasy to verify the TOTP code
    // For this example, we'll just check if the code is '123456' (dummy implementation)
    if (code !== "123456") {
      throw new ApiError(400, "Invalid verification code")
    }

    // Disable 2FA
    user.twoFactorEnabled = false
    user.twoFactorSecret = undefined
    await user.save()

    return true
  } catch (error) {
    logger.error(`Error in disableTwoFactor service: ${error.message}`)
    throw error
  }
}

/**
 * Get followed traders
 * @param {string} id - User ID
 * @returns {Promise<Array>} Followed traders
 */
const getFollowedTraders = async (id) => {
  try {
    // This would typically be a more complex query joining the Trader model
    // For simplicity, we'll just return the trader IDs from the Trader model
    const traders = await require("../models/trader.model")
      .find({ followers: id })
      .populate("userId", "firstName lastName email profilePicture")

    return traders
  } catch (error) {
    logger.error(`Error in getFollowedTraders service: ${error.message}`)
    throw error
  }
}

/**
 * Delete user account
 * @param {string} id - User ID
 * @param {string} password - User password
 * @returns {Promise<boolean>} Success status
 */
const deleteAccount = async (id, password) => {
  try {
    const user = await User.findById(id)

    if (!user) {
      throw new NotFoundError("User not found")
    }

    // Check password
    const isPasswordValid = await user.comparePassword(password)

    if (!isPasswordValid) {
      throw new ApiError(400, "Password is incorrect")
    }

    // In a real implementation, would need to handle:
    // 1. Delete user's trades
    // 2. Remove user from trader followers
    // 3. Delete user's portfolio
    // 4. Delete user's brokers
    // 5. Any other related data

    // Delete user
    await User.deleteOne({ _id: id })

    return true
  } catch (error) {
    logger.error(`Error in deleteAccount service: ${error.message}`)
    throw error
  }
}

module.exports = {
  getUserById,
  getUserProfile,
  updateUserProfile,
  changePassword,
  enableTwoFactor,
  verifyTwoFactor,
  disableTwoFactor,
  getFollowedTraders,
  deleteAccount,
}
