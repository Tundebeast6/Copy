import axios from "axios"
import toast from "react-hot-toast"

// Create axios instance
export const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || "http://localhost:5000/api",
  headers: {
    "Content-Type": "application/json",
  },
})

// Add request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token")
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  },
)

// Add response interceptor
api.interceptors.response.use(
  (response) => {
    return response
  },
  async (error) => {
    const originalRequest = error.config

    // If error is 401 and not already retrying
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true

      try {
        // Try to refresh token
        const refreshToken = localStorage.getItem("refreshToken")
        if (!refreshToken) {
          throw new Error("No refresh token available")
        }

        const response = await axios.post(
          `${process.env.REACT_APP_API_URL || "http://localhost:5000/api"}/auth/refresh-token`,
          { refreshToken },
        )

        const { token, newRefreshToken } = response.data.data

        // Update tokens
        localStorage.setItem("token", token)
        localStorage.setItem("refreshToken", newRefreshToken)

        // Update auth header
        api.defaults.headers.common["Authorization"] = `Bearer ${token}`
        originalRequest.headers.Authorization = `Bearer ${token}`

        // Retry original request
        return api(originalRequest)
      } catch (refreshError) {
        // If refresh fails, logout
        localStorage.removeItem("token")
        localStorage.removeItem("refreshToken")

        // Redirect to login
        window.location.href = "/login"

        toast.error("Your session has expired. Please log in again.")
        return Promise.reject(refreshError)
      }
    }

    // Handle other errors
    const errorMessage = error.response?.data?.message || "An unexpected error occurred"
    toast.error(errorMessage)

    return Promise.reject(error)
  },
)

// API functions for traders
export const fetchTraders = async (params = {}) => {
  const response = await api.get("/traders", { params })
  return response.data.data
}

export const fetchTraderById = async (id: string) => {
  const response = await api.get(`/traders/${id}`)
  return response.data.data
}

export const followTrader = async (id: string, copySettings = {}) => {
  const response = await api.post(`/traders/follow/${id}`, { copySettings })
  return response.data
}

export const unfollowTrader = async (id: string) => {
  const response = await api.delete(`/traders/unfollow/${id}`)
  return response.data
}

// API functions for trades
export const fetchTrades = async (params = {}) => {
  const response = await api.get("/trades", { params })
  return response.data.data
}

export const fetchTradeById = async (id: string) => {
  const response = await api.get(`/trades/${id}`)
  return response.data.data
}

export const createTrade = async (tradeData: any) => {
  const response = await api.post("/trades", tradeData)
  return response.data.data
}

export const updateTrade = async (id: string, tradeData: any) => {
  const response = await api.put(`/trades/${id}`, tradeData)
  return response.data.data
}

export const closeTrade = async (id: string, exitPrice: number) => {
  const response = await api.post(`/trades/${id}/close`, { exitPrice })
  return response.data.data
}

// API functions for brokers
export const fetchBrokers = async () => {
  const response = await api.get("/brokers")
  return response.data.data
}

export const connectBroker = async (brokerData: any) => {
  const response = await api.post("/brokers/connect", brokerData)
  return response.data.data
}

export const disconnectBroker = async (id: string) => {
  const response = await api.delete(`/brokers/${id}`)
  return response.data
}

export const syncBroker = async (id: string) => {
  const response = await api.post(`/brokers/${id}/sync`)
  return response.data.data
}

// API functions for portfolio
export const fetchPortfolio = async () => {
  const response = await api.get("/users/portfolio")
  return response.data.data
}

export const syncPortfolio = async () => {
  const response = await api.post("/users/portfolio/sync")
  return response.data.data
}

export const fetchPortfolioPerformance = async (period = "all") => {
  const response = await api.get(`/users/portfolio/performance?period=${period}`)
  return response.data.data
}

// API functions for user
export const fetchUserProfile = async () => {
  const response = await api.get("/users/profile")
  return response.data.data
}

export const updateUserProfile = async (profileData: any) => {
  const response = await api.put("/users/profile", profileData)
  return response.data.data
}

export const changePassword = async (currentPassword: string, newPassword: string) => {
  const response = await api.post("/users/change-password", { currentPassword, newPassword })
  return response.data
}

// Admin API functions
export const fetchAdminStats = async () => {
  const response = await api.get("/admin/stats")
  return response.data.data
}

export const fetchUsers = async (params = {}) => {
  const response = await api.get("/admin/users", { params })
  return response.data.data
}

export const updateUserStatus = async (userId: string, isActive: boolean) => {
  const response = await api.put(`/admin/users/${userId}/status`, { isActive })
  return response.data
}

export const deleteUser = async (userId: string) => {
  const response = await api.delete(`/admin/users/${userId}`)
  return response.data
}
