/**
 * Trader Service
 *
 * This file contains business logic for trader-related operations.
 */

const Trader = require("../models/trader.model")
const User = require("../models/user.model")
const Trade = require("../models/trade.model")
const Portfolio = require("../models/portfolio.model")
const copyEngine = require("../trading/copy-engine")
const { ApiError, NotFoundError } = require("../utils/errors")
const logger = require("../config/logger")

/**
 * Get all traders
 * @param {Object} options - Query options
 * @returns {Promise<Object>} Traders with pagination
 */
const getAllTraders = async (options) => {
  try {
    const { page, limit, sort, order, filter } = options
    const skip = (page - 1) * limit

    // Build query
    const query = { isActive: true, ...filter }

    // Build sort
    const sortOptions = {}
    sortOptions[sort] = order === "desc" ? -1 : 1

    // Count total
    const total = await Trader.countDocuments(query)

    // Get traders
    const traders = await Trader.find(query)
      .sort(sortOptions)
      .skip(skip)
      .limit(limit)
      .populate("userId", "firstName lastName email profilePicture")

    return {
      traders,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
    }
  } catch (error) {
    logger.error("Error in getAllTraders service:", error)
    throw error
  }
}

/**
 * Get trader by ID
 * @param {string} id - Trader ID
 * @returns {Promise<Object>} Trader
 */
const getTraderById = async (id) => {
  try {
    const trader = await Trader.findById(id).populate("userId", "firstName lastName email profilePicture")

    if (!trader) {
      throw new NotFoundError("Trader not found")
    }

    return trader
  } catch (error) {
    logger.error(`Error in getTraderById service: ${error.message}`)
    throw error
  }
}

/**
 * Get trader by user ID
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Trader
 */
const getTraderByUserId = async (userId) => {
  try {
    const trader = await Trader.findOne({ userId }).populate("userId", "firstName lastName email profilePicture")

    return trader
  } catch (error) {
    logger.error(`Error in getTraderByUserId service: ${error.message}`)
    throw error
  }
}

/**
 * Create trader
 * @param {Object} traderData - Trader data
 * @returns {Promise<Object>} Created trader
 */
const createTrader = async (traderData) => {
  try {
    // Check if user exists
    const user = await User.findById(traderData.userId)

    if (!user) {
      throw new NotFoundError("User not found")
    }

    // Check if trader already exists
    const existingTrader = await Trader.findOne({ userId: traderData.userId })

    if (existingTrader) {
      throw new ApiError(409, "Trader already exists")
    }

    // Update user role to trader
    user.role = "trader"
    await user.save()

    // Create trader
    const trader = await Trader.create(traderData)

    return trader
  } catch (error) {
    logger.error(`Error in createTrader service: ${error.message}`)
    throw error
  }
}

/**
 * Update trader
 * @param {string} id - Trader ID
 * @param {Object} traderData - Trader data
 * @returns {Promise<Object>} Updated trader
 */
const updateTrader = async (id, traderData) => {
  try {
    const trader = await Trader.findById(id)

    if (!trader) {
      throw new NotFoundError("Trader not found")
    }

    // Update trader
    Object.keys(traderData).forEach((key) => {
      trader[key] = traderData[key]
    })

    await trader.save()

    return trader
  } catch (error) {
    logger.error(`Error in updateTrader service: ${error.message}`)
    throw error
  }
}

/**
 * Follow trader
 * @param {string} traderId - Trader ID
 * @param {string} userId - User ID
 * @param {Object} copySettings - Copy settings
 * @returns {Promise<boolean>} Success status
 */
const followTrader = async (traderId, userId, copySettings = {}) => {
  try {
    const trader = await Trader.findById(traderId)

    if (!trader) {
      throw new NotFoundError("Trader not found")
    }

    // Check if user is already following trader
    if (trader.followers.includes(userId)) {
      throw new ApiError(409, "Already following this trader")
    }

    // Add user to followers
    trader.followers.push(userId)
    await trader.save()

    // Add trader to copy engine
    copyEngine.addFollower(userId, traderId, copySettings)

    return true
  } catch (error) {
    logger.error(`Error in followTrader service: ${error.message}`)
    throw error
  }
}

/**
 * Unfollow trader
 * @param {string} traderId - Trader ID
 * @param {string} userId - User ID
 * @returns {Promise<boolean>} Success status
 */
const unfollowTrader = async (traderId, userId) => {
  try {
    const trader = await Trader.findById(traderId)

    if (!trader) {
      throw new NotFoundError("Trader not found")
    }

    // Check if user is following trader
    if (!trader.followers.includes(userId)) {
      throw new ApiError(400, "Not following this trader")
    }

    // Remove user from followers
    trader.followers = trader.followers.filter((followerId) => followerId.toString() !== userId.toString())

    await trader.save()

    // Remove trader from copy engine
    copyEngine.removeFollower(userId, traderId)

    return true
  } catch (error) {
    logger.error(`Error in unfollowTrader service: ${error.message}`)
    throw error
  }
}

/**
 * Get trader trades
 * @param {string} traderId - Trader ID
 * @param {Object} options - Query options
 * @returns {Promise<Object>} Trades with pagination
 */
const getTraderTrades = async (traderId, options) => {
  try {
    const { page, limit, status } = options
    const skip = (page - 1) * limit

    // Build query
    const query = { traderId }

    if (status) {
      query.status = status
    }

    // Count total
    const total = await Trade.countDocuments(query)

    // Get trades
    const trades = await Trade.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit)

    return {
      trades,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
    }
  } catch (error) {
    logger.error(`Error in getTraderTrades service: ${error.message}`)
    throw error
  }
}

/**
 * Get trader followers
 * @param {string} traderId - Trader ID
 * @param {Object} options - Query options
 * @returns {Promise<Object>} Followers with pagination
 */
const getTraderFollowers = async (traderId, options) => {
  try {
    const { page, limit } = options

    const trader = await Trader.findById(traderId)

    if (!trader) {
      throw new NotFoundError("Trader not found")
    }

    const skip = (page - 1) * limit
    const total = trader.followers.length

    // Get followers
    const followerIds = trader.followers.slice(skip, skip + limit)

    const followers = await User.find({ _id: { $in: followerIds } }).select("firstName lastName email profilePicture")

    return {
      followers,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
    }
  } catch (error) {
    logger.error(`Error in getTraderFollowers service: ${error.message}`)
    throw error
  }
}

/**
 * Get trader performance
 * @param {string} traderId - Trader ID
 * @param {string} period - Time period
 * @returns {Promise<Object>} Performance data
 */
const getTraderPerformance = async (traderId, period) => {
  try {
    const trader = await Trader.findById(traderId)

    if (!trader) {
      throw new NotFoundError("Trader not found")
    }

    // Get trades for performance calculation
    const query = { traderId, status: "closed" }

    // Add date filter based on period
    const now = new Date()

    if (period === "day") {
      const startOfDay = new Date(now.setHours(0, 0, 0, 0))
      query.exitTime = { $gte: startOfDay }
    } else if (period === "week") {
      const startOfWeek = new Date(now)
      startOfWeek.setDate(now.getDate() - now.getDay())
      startOfWeek.setHours(0, 0, 0, 0)
      query.exitTime = { $gte: startOfWeek }
    } else if (period === "month") {
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
      query.exitTime = { $gte: startOfMonth }
    } else if (period === "year") {
      const startOfYear = new Date(now.getFullYear(), 0, 1)
      query.exitTime = { $gte: startOfYear }
    }

    const trades = await Trade.find(query)

    // Calculate performance metrics
    const totalTrades = trades.length
    const winningTrades = trades.filter((trade) => trade.profit > 0).length
    const losingTrades = trades.filter((trade) => trade.profit <= 0).length

    const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0

    const totalProfit = trades.reduce((sum, trade) => sum + trade.profit, 0)
    const averageProfit = totalTrades > 0 ? totalProfit / totalTrades : 0

    const winningTradesProfit = trades.filter((trade) => trade.profit > 0).reduce((sum, trade) => sum + trade.profit, 0)

    const losingTradesLoss = Math.abs(
      trades.filter((trade) => trade.profit <= 0).reduce((sum, trade) => sum + trade.profit, 0),
    )

    const averageWin = winningTrades > 0 ? winningTradesProfit / winningTrades : 0
    const averageLoss = losingTrades > 0 ? losingTradesLoss / losingTrades : 0

    const profitFactor = losingTradesLoss > 0 ? winningTradesProfit / losingTradesLoss : 0

    // Calculate drawdown
    let maxDrawdown = 0
    let peak = 0
    let runningTotal = 0

    trades.forEach((trade) => {
      runningTotal += trade.profit

      if (runningTotal > peak) {
        peak = runningTotal
      }

      const drawdown = peak - runningTotal

      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown
      }
    })

    return {
      totalTrades,
      winningTrades,
      losingTrades,
      winRate,
      totalProfit,
      averageProfit,
      averageWin,
      averageLoss,
      profitFactor,
      maxDrawdown,
      period,
    }
  } catch (error) {
    logger.error(`Error in getTraderPerformance service: ${error.message}`)
    throw error
  }
}

module.exports = {
  getAllTraders,
  getTraderById,
  getTraderByUserId,
  createTrader,
  updateTrader,
  followTrader,
  unfollowTrader,
  getTraderTrades,
  getTraderFollowers,
  getTraderPerformance,
}
