/**
 * Trade Service
 *
 * This file contains business logic for trade-related operations.
 */

const Trade = require("../models/trade.model")
const Trader = require("../models/trader.model")
const Broker = require("../models/broker.model")
const Portfolio = require("../models/portfolio.model")
const { createBroker } = require("../brokers/broker.factory")
const { ApiError, NotFoundError } = require("../utils/errors")
const logger = require("../config/logger")

/**
 * Check if user is a trader
 * @param {string} userId - User ID
 * @returns {Promise<Object|null>} Trader object or null
 */
const isUserTrader = async (userId) => {
  try {
    const trader = await Trader.findOne({ userId })
    return trader
  } catch (error) {
    logger.error(`Error in isUserTrader service: ${error.message}`)
    throw error
  }
}

/**
 * Get all trades for a user
 * @param {string} userId - User ID
 * @param {Object} options - Query options
 * @returns {Promise<Object>} Trades with pagination
 */
const getAllTrades = async (userId, options) => {
  try {
    const { page, limit, status, symbol, assetClass, direction } = options
    const skip = (page - 1) * limit

    // Get trader ID if user is a trader
    const trader = await Trader.findOne({ userId })

    // Build query
    const query = {}

    if (trader) {
      // If user is a trader, get their trades
      query.traderId = trader._id
    } else {
      // If user is a follower, get trades they've copied
      query["copiedBy.userId"] = userId
    }

    if (status) {
      query.status = status
    }

    if (symbol) {
      query.symbol = symbol
    }

    if (assetClass) {
      query.assetClass = assetClass
    }

    if (direction) {
      query.direction = direction
    }

    // Count total
    const total = await Trade.countDocuments(query)

    // Get trades
    const trades = await Trade.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate("traderId", "userId")
      .populate("brokerId", "name label")

    return {
      trades,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
    }
  } catch (error) {
    logger.error(`Error in getAllTrades service: ${error.message}`)
    throw error
  }
}

/**
 * Get trade by ID
 * @param {string} id - Trade ID
 * @param {string} userId - User ID (optional)
 * @returns {Promise<Object>} Trade
 */
const getTradeById = async (id, userId = null) => {
  try {
    const trade = await Trade.findById(id).populate("traderId", "userId").populate("brokerId", "name label")

    if (!trade) {
      throw new NotFoundError("Trade not found")
    }

    // If userId is provided, check if user has access to this trade
    if (userId) {
      const trader = await Trader.findById(trade.traderId)

      // Check if user is the trader or has copied this trade
      const isTrader = trader && trader.userId.toString() === userId.toString()
      const hasCopied = trade.copiedBy.some((copy) => copy.userId.toString() === userId.toString())

      if (!isTrader && !hasCopied && !trade.isPublic) {
        throw new ApiError(403, "You do not have access to this trade")
      }
    }

    return trade
  } catch (error) {
    logger.error(`Error in getTradeById service: ${error.message}`)
    throw error
  }
}

/**
 * Create a new trade
 * @param {Object} tradeData - Trade data
 * @returns {Promise<Object>} Created trade
 */
const createTrade = async (tradeData) => {
  try {
    // Validate trader
    const trader = await Trader.findById(tradeData.traderId)

    if (!trader) {
      throw new NotFoundError("Trader not found")
    }

    // Validate broker
    const broker = await Broker.findById(tradeData.brokerId)

    if (!broker) {
      throw new NotFoundError("Broker not found")
    }

    // Create trade in database
    const trade = await Trade.create({
      ...tradeData,
      status: "pending",
    })

    // Execute trade with broker if not in simulation mode
    if (broker.accountType !== "demo" && process.env.SIMULATION_MODE !== "true") {
      try {
        // Get broker credentials
        const credentials = broker.getDecryptedCredentials()

        // Create broker instance
        const brokerInstance = createBroker(broker.name, credentials, {
          accountId: broker.accountId,
        })

        // Connect to broker
        await brokerInstance.connect()

        // Place order
        const orderResult = await brokerInstance.placeMarketOrder({
          symbol: trade.symbol,
          direction: trade.direction,
          quantity: trade.quantity,
          stopLoss: trade.stopLoss,
          takeProfit: trade.takeProfit,
        })

        // Update trade with broker order ID and status
        trade.brokerOrderId = orderResult.id
        trade.status = "open"
        trade.entryPrice = orderResult.filledPrice
        trade.entryTime = new Date()

        await trade.save()
      } catch (error) {
        // Update trade status to rejected if order fails
        trade.status = "rejected"
        trade.notes = `Order rejected: ${error.message}`
        await trade.save()

        logger.error(`Failed to execute trade with broker: ${error.message}`)
        throw new ApiError(500, `Failed to execute trade with broker: ${error.message}`)
      }
    } else {
      // Simulation mode - update trade with simulated values
      trade.status = "open"
      trade.entryPrice = tradeData.entryPrice || 0
      trade.entryTime = new Date()
      await trade.save()
    }

    // Update trader stats
    trader.totalTrades += 1
    await trader.save()

    return trade
  } catch (error) {
    logger.error(`Error in createTrade service: ${error.message}`)
    throw error
  }
}

/**
 * Update a trade
 * @param {string} id - Trade ID
 * @param {Object} tradeData - Trade data
 * @returns {Promise<Object>} Updated trade
 */
const updateTrade = async (id, tradeData) => {
  try {
    const trade = await Trade.findById(id)

    if (!trade) {
      throw new NotFoundError("Trade not found")
    }

    // Check if trade can be updated
    if (trade.status === "closed") {
      throw new ApiError(400, "Cannot update a closed trade")
    }

    // Update allowed fields
    const allowedFields = ["stopLoss", "takeProfit", "notes", "tags", "isPublic"]

    allowedFields.forEach((field) => {
      if (tradeData[field] !== undefined) {
        trade[field] = tradeData[field]
      }
    })

    // Update stop loss and take profit with broker if not in simulation mode
    if ((tradeData.stopLoss || tradeData.takeProfit) && trade.brokerOrderId && process.env.SIMULATION_MODE !== "true") {
      try {
        // Get broker
        const broker = await Broker.findById(trade.brokerId)

        if (!broker) {
          throw new NotFoundError("Broker not found")
        }

        // Get broker credentials
        const credentials = broker.getDecryptedCredentials()

        // Create broker instance
        const brokerInstance = createBroker(broker.name, credentials, {
          accountId: broker.accountId,
        })

        // Connect to broker
        await brokerInstance.connect()

        // Update order
        // Note: This is a simplified example. The actual implementation would depend on the broker's API
        // await brokerInstance.updateOrder(trade.brokerOrderId, {
        //   stopLoss: trade.stopLoss,
        //   takeProfit: trade.takeProfit
        // });
      } catch (error) {
        logger.error(`Failed to update trade with broker: ${error.message}`)
        // Continue with the update in the database even if broker update fails
      }
    }

    await trade.save()

    return trade
  } catch (error) {
    logger.error(`Error in updateTrade service: ${error.message}`)
    throw error
  }
}

/**
 * Close a trade
 * @param {string} id - Trade ID
 * @param {number} exitPrice - Exit price
 * @returns {Promise<Object>} Closed trade
 */
const closeTrade = async (id, exitPrice) => {
  try {
    const trade = await Trade.findById(id)

    if (!trade) {
      throw new NotFoundError("Trade not found")
    }

    // Check if trade can be closed
    if (trade.status !== "open") {
      throw new ApiError(400, `Cannot close a trade with status: ${trade.status}`)
    }

    // Close trade with broker if not in simulation mode
    if (trade.brokerOrderId && process.env.SIMULATION_MODE !== "true") {
      try {
        // Get broker
        const broker = await Broker.findById(trade.brokerId)

        if (!broker) {
          throw new NotFoundError("Broker not found")
        }

        // Get broker credentials
        const credentials = broker.getDecryptedCredentials()

        // Create broker instance
        const brokerInstance = createBroker(broker.name, credentials, {
          accountId: broker.accountId,
        })

        // Connect to broker
        await brokerInstance.connect()

        // Close position
        // Note: This is a simplified example. The actual implementation would depend on the broker's API
        // const closeResult = await brokerInstance.closePosition(trade.brokerOrderId);
        // exitPrice = closeResult.price;
      } catch (error) {
        logger.error(`Failed to close trade with broker: ${error.message}`)
        // Continue with the close in the database even if broker close fails
      }
    }

    // Update trade
    trade.status = "closed"
    trade.exitPrice = exitPrice
    trade.exitTime = new Date()

    // Calculate profit
    if (trade.direction === "long") {
      trade.profit = (exitPrice - trade.entryPrice) * trade.quantity
      trade.profitPercentage = ((exitPrice - trade.entryPrice) / trade.entryPrice) * 100
    } else {
      trade.profit = (trade.entryPrice - exitPrice) * trade.quantity
      trade.profitPercentage = ((trade.entryPrice - exitPrice) / trade.entryPrice) * 100
    }

    await trade.save()

    // Update trader stats
    const trader = await Trader.findById(trade.traderId)

    if (trader) {
      // Update win rate
      const closedTrades = await Trade.find({ traderId: trader._id, status: "closed" })
      const winningTrades = closedTrades.filter((t) => t.profit > 0).length

      trader.winRate = closedTrades.length > 0 ? (winningTrades / closedTrades.length) * 100 : 0

      // Update average profit
      const totalProfit = closedTrades.reduce((sum, t) => sum + t.profit, 0)
      trader.averageProfit = closedTrades.length > 0 ? totalProfit / closedTrades.length : 0

      await trader.save()
    }

    // Close copied trades
    if (trade.copiedBy && trade.copiedBy.length > 0) {
      for (const copy of trade.copiedBy) {
        if (copy.status === "copied") {
          // Calculate exit price for the copy based on the same percentage change
          const copyExitPrice =
            trade.direction === "long"
              ? copy.entryPrice * (1 + trade.profitPercentage / 100)
              : copy.entryPrice * (1 - trade.profitPercentage / 100)

          // Calculate profit for the copy
          const copyProfit =
            trade.direction === "long"
              ? (copyExitPrice - copy.entryPrice) * copy.quantity
              : (copy.entryPrice - copyExitPrice) * copy.quantity

          // Update copy
          copy.status = "copied"
          copy.exitPrice = copyExitPrice
          copy.profit = copyProfit
        }
      }

      await trade.save()
    }

    return trade
  } catch (error) {
    logger.error(`Error in closeTrade service: ${error.message}`)
    throw error
  }
}

/**
 * Delete a trade
 * @param {string} id - Trade ID
 * @returns {Promise<boolean>} Success status
 */
const deleteTrade = async (id) => {
  try {
    const trade = await Trade.findById(id)

    if (!trade) {
      throw new NotFoundError("Trade not found")
    }

    // Check if trade can be deleted
    if (trade.status === "open") {
      throw new ApiError(400, "Cannot delete an open trade. Close it first.")
    }

    await Trade.deleteOne({ _id: id })

    return true
  } catch (error) {
    logger.error(`Error in deleteTrade service: ${error.message}`)
    throw error
  }
}

/**
 * Get copied trades for a user
 * @param {string} userId - User ID
 * @param {Object} options - Query options
 * @returns {Promise<Object>} Trades with pagination
 */
const getCopiedTrades = async (userId, options) => {
  try {
    const { page, limit, status } = options
    const skip = (page - 1) * limit

    // Build query
    const query = { "copiedBy.userId": userId }

    if (status) {
      query.status = status
    }

    // Count total
    const total = await Trade.countDocuments(query)

    // Get trades
    const trades = await Trade.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate("traderId", "userId")
      .populate("brokerId", "name label")

    // Format trades to include copy-specific data
    const formattedTrades = trades.map((trade) => {
      const copy = trade.copiedBy.find((c) => c.userId.toString() === userId.toString())

      return {
        ...trade.toObject(),
        copy: {
          status: copy.status,
          quantity: copy.quantity,
          entryPrice: copy.entryPrice,
          exitPrice: copy.exitPrice,
          profit: copy.profit,
          brokerOrderId: copy.brokerOrderId,
        },
      }
    })

    return {
      trades: formattedTrades,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
    }
  } catch (error) {
    logger.error(`Error in getCopiedTrades service: ${error.message}`)
    throw error
  }
}

/**
 * Copy a trade
 * @param {string} tradeId - Trade ID
 * @param {string} userId - User ID
 * @param {Object} copySettings - Copy settings
 * @returns {Promise<Object>} Copied trade
 */
const copyTrade = async (tradeId, userId, copySettings) => {
  try {
    const trade = await Trade.findById(tradeId)

    if (!trade) {
      throw new NotFoundError("Trade not found")
    }

    // Check if trade can be copied
    if (trade.status !== "open") {
      throw new ApiError(400, "Can only copy open trades")
    }

    // Check if user has already copied this trade
    const alreadyCopied = trade.copiedBy.some((copy) => copy.userId.toString() === userId.toString())

    if (alreadyCopied) {
      throw new ApiError(409, "You have already copied this trade")
    }

    // Get user's broker
    const broker = await Broker.findOne({ userId, isActive: true })

    if (!broker) {
      throw new ApiError(400, "You need to connect a broker first")
    }

    // Calculate quantity based on copy settings
    let quantity = trade.quantity

    if (copySettings.fixedQuantity) {
      quantity = copySettings.fixedQuantity
    } else if (copySettings.multiplier) {
      quantity = trade.quantity * copySettings.multiplier
    }

    // Execute copy trade with broker if not in simulation mode
    const copyData = {
      userId,
      status: "pending",
      quantity,
      entryPrice: trade.entryPrice,
      exitPrice: null,
      profit: 0,
      brokerOrderId: null,
    }

    if (broker.accountType !== "demo" && process.env.SIMULATION_MODE !== "true") {
      try {
        // Get broker credentials
        const credentials = broker.getDecryptedCredentials()

        // Create broker instance
        const brokerInstance = createBroker(broker.name, credentials, {
          accountId: broker.accountId,
        })

        // Connect to broker
        await brokerInstance.connect()

        // Place order
        const orderResult = await brokerInstance.placeMarketOrder({
          symbol: trade.symbol,
          direction: trade.direction,
          quantity: copyData.quantity,
          stopLoss: trade.stopLoss,
          takeProfit: trade.takeProfit,
        })

        // Update copy data
        copyData.status = "copied"
        copyData.brokerOrderId = orderResult.id
        copyData.entryPrice = orderResult.filledPrice || trade.entryPrice
      } catch (error) {
        // Update copy status to failed if order fails
        copyData.status = "failed"

        logger.error(`Failed to execute copy trade with broker: ${error.message}`)
        throw new ApiError(500, `Failed to execute copy trade with broker: ${error.message}`)
      }
    } else {
      // Simulation mode
      copyData.status = "copied"
    }

    // Add copy to trade
    trade.copiedBy.push(copyData)
    await trade.save()

    return trade
  } catch (error) {
    logger.error(`Error in copyTrade service: ${error.message}`)
    throw error
  }
}

module.exports = {
  isUserTrader,
  getAllTrades,
  getTradeById,
  createTrade,
  updateTrade,
  closeTrade,
  deleteTrade,
  getCopiedTrades,
  copyTrade,
}
