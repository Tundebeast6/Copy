/**
 * Portfolio Service
 *
 * This file contains business logic for portfolio-related operations.
 */

const Portfolio = require("../models/portfolio.model")
const Trade = require("../models/trade.model")
const Broker = require("../models/broker.model")
const { createBroker } = require("../brokers/broker.factory")
const { ApiError, NotFoundError } = require("../utils/errors")
const logger = require("../config/logger")

/**
 * Get user portfolio
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Portfolio
 */
const getUserPortfolio = async (userId) => {
  try {
    // Find or create portfolio
    let portfolio = await Portfolio.findOne({ userId })

    if (!portfolio) {
      portfolio = await Portfolio.create({
        userId,
        balance: 0,
        equity: 0,
        allocatedBalance: 0,
        availableBalance: 0,
        currency: "USD",
        positions: [],
        performance: {
          daily: { date: new Date(), balance: 0, profit: 0, profitPercent: 0 },
          weekly: { startDate: new Date(), endDate: new Date(), balance: 0, profit: 0, profitPercent: 0 },
          monthly: {
            month: new Date().getMonth(),
            year: new Date().getFullYear(),
            balance: 0,
            profit: 0,
            profitPercent: 0,
          },
          yearly: { year: new Date().getFullYear(), balance: 0, profit: 0, profitPercent: 0 },
          allTime: { startDate: new Date(), balance: 0, profit: 0, profitPercent: 0 },
        },
        stats: {
          totalTrades: 0,
          winningTrades: 0,
          losingTrades: 0,
          winRate: 0,
          averageWin: 0,
          averageLoss: 0,
          profitFactor: 0,
          maxDrawdown: 0,
          sharpeRatio: 0,
        },
      })
    }

    return portfolio
  } catch (error) {
    logger.error(`Error in getUserPortfolio service: ${error.message}`)
    throw error
  }
}

/**
 * Sync portfolio with brokers
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Updated portfolio
 */
const syncPortfolio = async (userId) => {
  try {
    // Get user portfolio
    const portfolio = await getUserPortfolio(userId)

    // Get user brokers
    const brokers = await Broker.find({ userId, isActive: true })

    if (brokers.length === 0) {
      return portfolio
    }

    // Reset portfolio positions
    portfolio.positions = []

    // Track total balance
    let totalBalance = 0

    // Process each broker
    for (const broker of brokers) {
      try {
        // Get broker credentials
        const credentials = broker.getDecryptedCredentials()

        // Create broker instance
        const brokerInstance = createBroker(broker.name, credentials, { accountId: broker.accountId })

        // Connect to broker
        await brokerInstance.connect()

        // Get account info
        const account = await brokerInstance.getAccount()

        // Update broker balance
        broker.balance = account.balance || 0
        broker.currency = account.currency || "USD"
        broker.status = "connected"
        broker.lastSynced = new Date()

        await broker.save()

        // Add to total balance (simplified - in a real app, would handle currency conversion)
        totalBalance += broker.balance

        // Get positions
        const positions = await brokerInstance.getPositions()

        // Add positions to portfolio
        for (const position of positions) {
          portfolio.positions.push({
            symbol: position.symbol,
            assetClass: position.assetClass || "forex", // Default for OANDA
            direction: position.direction,
            quantity: position.quantity,
            entryPrice: position.entryPrice,
            currentPrice: position.currentPrice,
            marketValue: position.quantity * position.currentPrice,
            unrealizedPL: position.unrealizedPL,
            unrealizedPLPercent: (position.unrealizedPL / (position.entryPrice * position.quantity)) * 100,
            openTime: position.openTime || new Date(),
            trades: [], // Would link to trades in a real implementation
          })
        }
      } catch (error) {
        logger.error(`Failed to sync broker ${broker.name}: ${error.message}`)

        // Update broker status
        broker.status = "error"
        broker.errorMessage = error.message
        broker.lastSynced = new Date()

        await broker.save()
      }
    }

    // Update portfolio balance
    portfolio.balance = totalBalance

    // Calculate equity (balance + unrealized P/L)
    const unrealizedPL = portfolio.positions.reduce((sum, position) => sum + position.unrealizedPL, 0)
    portfolio.equity = portfolio.balance + unrealizedPL

    // Update allocated balance (simplified)
    portfolio.allocatedBalance = portfolio.positions.reduce((sum, position) => {
      return sum + position.entryPrice * position.quantity
    }, 0)

    // Update available balance
    portfolio.availableBalance = portfolio.balance - portfolio.allocatedBalance

    // Update last updated timestamp
    portfolio.lastUpdated = new Date()

    await portfolio.save()

    return portfolio
  } catch (error) {
    logger.error(`Error in syncPortfolio service: ${error.message}`)
    throw error
  }
}

/**
 * Update portfolio performance
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Updated portfolio
 */
const updatePortfolioPerformance = async (userId) => {
  try {
    // Get user portfolio
    const portfolio = await getUserPortfolio(userId)

    // Get closed trades
    const trades = await Trade.find({
      $or: [
        { traderId: userId, status: "closed" },
        { "copiedBy.userId": userId, status: "closed" },
      ],
    }).sort({ exitTime: 1 })

    if (trades.length === 0) {
      return portfolio
    }

    // Calculate performance metrics
    const now = new Date()
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const startOfWeek = new Date(now)
    startOfWeek.setDate(now.getDate() - now.getDay())
    startOfWeek.setHours(0, 0, 0, 0)
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
    const startOfYear = new Date(now.getFullYear(), 0, 1)

    // Filter trades by period
    const todayTrades = trades.filter((trade) => {
      const exitTime = new Date(trade.exitTime)
      return exitTime >= today
    })

    const weekTrades = trades.filter((trade) => {
      const exitTime = new Date(trade.exitTime)
      return exitTime >= startOfWeek
    })

    const monthTrades = trades.filter((trade) => {
      const exitTime = new Date(trade.exitTime)
      return exitTime >= startOfMonth
    })

    const yearTrades = trades.filter((trade) => {
      const exitTime = new Date(trade.exitTime)
      return exitTime >= startOfYear
    })

    // Calculate daily performance
    const dailyProfit = todayTrades.reduce((sum, trade) => {
      // If user is the trader
      if (trade.traderId.toString() === userId.toString()) {
        return sum + trade.profit
      }

      // If user copied the trade
      const copy = trade.copiedBy.find((copy) => copy.userId.toString() === userId.toString())
      if (copy) {
        return sum + copy.profit
      }

      return sum
    }, 0)

    // Calculate weekly performance
    const weeklyProfit = weekTrades.reduce((sum, trade) => {
      // If user is the trader
      if (trade.traderId.toString() === userId.toString()) {
        return sum + trade.profit
      }

      // If user copied the trade
      const copy = trade.copiedBy.find((copy) => copy.userId.toString() === userId.toString())
      if (copy) {
        return sum + copy.profit
      }

      return sum
    }, 0)

    // Calculate monthly performance
    const monthlyProfit = monthTrades.reduce((sum, trade) => {
      // If user is the trader
      if (trade.traderId.toString() === userId.toString()) {
        return sum + trade.profit
      }

      // If user copied the trade
      const copy = trade.copiedBy.find((copy) => copy.userId.toString() === userId.toString())
      if (copy) {
        return sum + copy.profit
      }

      return sum
    }, 0)

    // Calculate yearly performance
    const yearlyProfit = yearTrades.reduce((sum, trade) => {
      // If user is the trader
      if (trade.traderId.toString() === userId.toString()) {
        return sum + trade.profit
      }

      // If user copied the trade
      const copy = trade.copiedBy.find((copy) => copy.userId.toString() === userId.toString())
      if (copy) {
        return sum + copy.profit
      }

      return sum
    }, 0)

    // Calculate all-time performance
    const allTimeProfit = trades.reduce((sum, trade) => {
      // If user is the trader
      if (trade.traderId.toString() === userId.toString()) {
        return sum + trade.profit
      }

      // If user copied the trade
      const copy = trade.copiedBy.find((copy) => copy.userId.toString() === userId.toString())
      if (copy) {
        return sum + copy.profit
      }

      return sum
    }, 0)

    // Update portfolio performance
    portfolio.performance = {
      daily: {
        date: today,
        balance: portfolio.balance,
        profit: dailyProfit,
        profitPercent: portfolio.balance > 0 ? (dailyProfit / portfolio.balance) * 100 : 0,
      },
      weekly: {
        startDate: startOfWeek,
        endDate: now,
        balance: portfolio.balance,
        profit: weeklyProfit,
        profitPercent: portfolio.balance > 0 ? (weeklyProfit / portfolio.balance) * 100 : 0,
      },
      monthly: {
        month: now.getMonth(),
        year: now.getFullYear(),
        balance: portfolio.balance,
        profit: monthlyProfit,
        profitPercent: portfolio.balance > 0 ? (monthlyProfit / portfolio.balance) * 100 : 0,
      },
      yearly: {
        year: now.getFullYear(),
        balance: portfolio.balance,
        profit: yearlyProfit,
        profitPercent: portfolio.balance > 0 ? (yearlyProfit / portfolio.balance) * 100 : 0,
      },
      allTime: {
        startDate: trades[0].exitTime,
        balance: portfolio.balance,
        profit: allTimeProfit,
        profitPercent: portfolio.balance > 0 ? (allTimeProfit / portfolio.balance) * 100 : 0,
      },
    }

    // Calculate trading statistics
    const userTrades = trades.filter((trade) => {
      // If user is the trader
      if (trade.traderId.toString() === userId.toString()) {
        return true
      }

      // If user copied the trade
      return trade.copiedBy.some((copy) => copy.userId.toString() === userId.toString())
    })

    const winningTrades = userTrades.filter((trade) => {
      // If user is the trader
      if (trade.traderId.toString() === userId.toString()) {
        return trade.profit > 0
      }

      // If user copied the trade
      const copy = trade.copiedBy.find((copy) => copy.userId.toString() === userId.toString())
      return copy && copy.profit > 0
    })

    const losingTrades = userTrades.filter((trade) => {
      // If user is the trader
      if (trade.traderId.toString() === userId.toString()) {
        return trade.profit <= 0
      }

      // If user copied the trade
      const copy = trade.copiedBy.find((copy) => copy.userId.toString() === userId.toString())
      return copy && copy.profit <= 0
    })

    const totalTrades = userTrades.length
    const winRate = totalTrades > 0 ? (winningTrades.length / totalTrades) * 100 : 0

    // Calculate average win and loss
    const totalWinAmount = winningTrades.reduce((sum, trade) => {
      // If user is the trader
      if (trade.traderId.toString() === userId.toString()) {
        return sum + trade.profit
      }

      // If user copied the trade
      const copy = trade.copiedBy.find((copy) => copy.userId.toString() === userId.toString())
      if (copy) {
        return sum + copy.profit
      }

      return sum
    }, 0)

    const totalLossAmount = Math.abs(
      losingTrades.reduce((sum, trade) => {
        // If user is the trader
        if (trade.traderId.toString() === userId.toString()) {
          return sum + trade.profit
        }

        // If user copied the trade
        const copy = trade.copiedBy.find((copy) => copy.userId.toString() === userId.toString())
        if (copy) {
          return sum + copy.profit
        }

        return sum
      }, 0),
    )

    const averageWin = winningTrades.length > 0 ? totalWinAmount / winningTrades.length : 0
    const averageLoss = losingTrades.length > 0 ? totalLossAmount / losingTrades.length : 0

    // Calculate profit factor
    const profitFactor = totalLossAmount > 0 ? totalWinAmount / totalLossAmount : 0

    // Calculate max drawdown
    let maxDrawdown = 0
    let peak = 0
    let runningTotal = 0

    userTrades.forEach((trade) => {
      let profit = 0

      // If user is the trader
      if (trade.traderId.toString() === userId.toString()) {
        profit = trade.profit
      } else {
        // If user copied the trade
        const copy = trade.copiedBy.find((copy) => copy.userId.toString() === userId.toString())
        if (copy) {
          profit = copy.profit
        }
      }

      runningTotal += profit

      if (runningTotal > peak) {
        peak = runningTotal
      }

      const drawdown = peak - runningTotal

      if (drawdown > maxDrawdown) {
        maxDrawdown = drawdown
      }
    })

    // Update portfolio stats
    portfolio.stats = {
      totalTrades,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      winRate,
      averageWin,
      averageLoss,
      profitFactor,
      maxDrawdown,
      sharpeRatio: 0, // Would require more complex calculation with daily returns
    }

    await portfolio.save()

    return portfolio
  } catch (error) {
    logger.error(`Error in updatePortfolioPerformance service: ${error.message}`)
    throw error
  }
}

/**
 * Get portfolio performance
 * @param {string} userId - User ID
 * @param {string} period - Time period (daily, weekly, monthly, yearly, all)
 * @returns {Promise<Object>} Portfolio performance
 */
const getPortfolioPerformance = async (userId, period = "all") => {
  try {
    // Get user portfolio
    const portfolio = await getUserPortfolio(userId)

    // Return performance for the requested period
    switch (period) {
      case "daily":
        return portfolio.performance.daily
      case "weekly":
        return portfolio.performance.weekly
      case "monthly":
        return portfolio.performance.monthly
      case "yearly":
        return portfolio.performance.yearly
      case "all":
      default:
        return portfolio.performance.allTime
    }
  } catch (error) {
    logger.error(`Error in getPortfolioPerformance service: ${error.message}`)
    throw error
  }
}

/**
 * Get portfolio positions
 * @param {string} userId - User ID
 * @returns {Promise<Array>} Portfolio positions
 */
const getPortfolioPositions = async (userId) => {
  try {
    // Get user portfolio
    const portfolio = await getUserPortfolio(userId)

    return portfolio.positions
  } catch (error) {
    logger.error(`Error in getPortfolioPositions service: ${error.message}`)
    throw error
  }
}

/**
 * Get portfolio statistics
 * @param {string} userId - User ID
 * @returns {Promise<Object>} Portfolio statistics
 */
const getPortfolioStats = async (userId) => {
  try {
    // Get user portfolio
    const portfolio = await getUserPortfolio(userId)

    return portfolio.stats
  } catch (error) {
    logger.error(`Error in getPortfolioStats service: ${error.message}`)
    throw error
  }
}

module.exports = {
  getUserPortfolio,
  syncPortfolio,
  updatePortfolioPerformance,
  getPortfolioPerformance,
  getPortfolioPositions,
  getPortfolioStats,
}
