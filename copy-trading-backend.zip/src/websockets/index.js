/**
 * WebSocket Server Setup
 *
 * This file initializes the WebSocket server and sets up event handlers.
 */

const { Server } = require("socket.io")
const jwt = require("jsonwebtoken")
const { jwt: jwtConfig } = require("../config/env")
const logger = require("../config/logger")
const User = require("../models/user.model")
const tradeHandler = require("./handlers/trade.handler")
const marketHandler = require("./handlers/market.handler")
const notificationHandler = require("./handlers/notification.handler")

/**
 * Set up WebSocket server
 * @param {Object} httpServer - HTTP server instance
 * @returns {Object} Socket.io server instance
 */
const setupWebSocketServer = (httpServer) => {
  const io = new Server(httpServer, {
    cors: {
      origin: process.env.CORS_ORIGIN || "*",
      methods: ["GET", "POST"],
    },
  })

  // Middleware for authentication
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth.token

      if (!token) {
        return next(new Error("Authentication required"))
      }

      // Verify token
      const decoded = jwt.verify(token, jwtConfig.secret)

      // Find user
      const user = await User.findById(decoded.id).select("-password")

      if (!user) {
        return next(new Error("Invalid authentication token"))
      }

      // Attach user to socket
      socket.user = user

      next()
    } catch (error) {
      if (error.name === "JsonWebTokenError") {
        return next(new Error("Invalid authentication token"))
      }

      if (error.name === "TokenExpiredError") {
        return next(new Error("Authentication token expired"))
      }

      next(error)
    }
  })

  // Connection event
  io.on("connection", (socket) => {
    logger.info(`User connected: ${socket.user._id}`)

    // Join user-specific room
    socket.join(`user:${socket.user._id}`)

    // Set up event handlers
    tradeHandler(io, socket)
    marketHandler(io, socket)
    notificationHandler(io, socket)

    // Disconnect event
    socket.on("disconnect", () => {
      logger.info(`User disconnected: ${socket.user._id}`)
    })

    // Error event
    socket.on("error", (error) => {
      logger.error(`Socket error: ${error.message}`, { userId: socket.user._id })
    })
  })

  return io
}

module.exports = {
  setupWebSocketServer,
}
