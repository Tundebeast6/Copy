/**
 * Market WebSocket Handler
 *
 * This file handles WebSocket events related to market data.
 */

const logger = require("../../config/logger")

/**
 * Set up market-related WebSocket events
 * @param {Object} io - Socket.io server instance
 * @param {Object} socket - Socket.io socket instance
 */
const marketHandler = (io, socket) => {
  // Subscribe to market data
  socket.on("market:subscribe", async (symbols) => {
    try {
      if (!Array.isArray(symbols)) {
        symbols = [symbols]
      }

      // Join symbol rooms
      symbols.forEach((symbol) => {
        socket.join(`market:${symbol}`)
      })

      logger.info(`User ${socket.user._id} subscribed to market data for ${symbols.join(", ")}`)

      socket.emit("market:subscribed", { symbols })

      // Send initial market data
      symbols.forEach((symbol) => {
        // Mock market data - in a real app, this would come from a market data service
        const marketData = {
          symbol,
          price: Math.random() * 1000,
          change: Math.random() * 10 - 5,
          volume: Math.floor(Math.random() * 1000000),
          high: Math.random() * 1100,
          low: Math.random() * 900,
          timestamp: new Date().toISOString(),
        }

        socket.emit("market:data", marketData)
      })
    } catch (error) {
      logger.error("Error in market:subscribe:", error)
      socket.emit("error", { message: "Failed to subscribe to market data" })
    }
  })

  // Unsubscribe from market data
  socket.on("market:unsubscribe", (symbols) => {
    try {
      if (!Array.isArray(symbols)) {
        symbols = [symbols]
      }

      // Leave symbol rooms
      symbols.forEach((symbol) => {
        socket.leave(`market:${symbol}`)
      })

      logger.info(`User ${socket.user._id} unsubscribed from market data for ${symbols.join(", ")}`)

      socket.emit("market:unsubscribed", { symbols })
    } catch (error) {
      logger.error("Error in market:unsubscribe:", error)
      socket.emit("error", { message: "Failed to unsubscribe from market data" })
    }
  })
}

module.exports = marketHandler
