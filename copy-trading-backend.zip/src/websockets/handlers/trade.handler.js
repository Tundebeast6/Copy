/**
 * Trade WebSocket Handler
 *
 * This file handles WebSocket events related to trades.
 */

const logger = require("../../config/logger")

/**
 * Set up trade-related WebSocket events
 * @param {Object} io - Socket.io server instance
 * @param {Object} socket - Socket.io socket instance
 */
const tradeHandler = (io, socket) => {
  // Subscribe to trader's trades
  socket.on("trade:subscribe", async (traderId) => {
    try {
      // Join trader room
      socket.join(`trader:${traderId}`)

      logger.info(`User ${socket.user._id} subscribed to trader ${traderId}`)

      socket.emit("trade:subscribed", { traderId })
    } catch (error) {
      logger.error("Error in trade:subscribe:", error)
      socket.emit("error", { message: "Failed to subscribe to trader" })
    }
  })

  // Unsubscribe from trader's trades
  socket.on("trade:unsubscribe", (traderId) => {
    try {
      // Leave trader room
      socket.leave(`trader:${traderId}`)

      logger.info(`User ${socket.user._id} unsubscribed from trader ${traderId}`)

      socket.emit("trade:unsubscribed", { traderId })
    } catch (error) {
      logger.error("Error in trade:unsubscribe:", error)
      socket.emit("error", { message: "Failed to unsubscribe from trader" })
    }
  })

  // Create a new trade (for traders)
  socket.on("trade:create", async (tradeData) => {
    try {
      // Check if user is a trader
      if (socket.user.role !== "trader") {
        return socket.emit("error", { message: "Only traders can create trades" })
      }

      // TODO: Process trade creation through trade service

      // Broadcast trade to followers
      io.to(`trader:${socket.user._id}`).emit("trade:new", {
        traderId: socket.user._id,
        trade: {
          // Trade data would come from the trade service
          id: "trade-id",
          symbol: tradeData.symbol,
          type: tradeData.type,
          side: tradeData.side,
          quantity: tradeData.quantity,
          price: tradeData.price,
          timestamp: new Date().toISOString(),
        },
      })

      logger.info(`Trader ${socket.user._id} created a new trade`)
    } catch (error) {
      logger.error("Error in trade:create:", error)
      socket.emit("error", { message: "Failed to create trade" })
    }
  })

  // Update trade status
  socket.on("trade:update", async (tradeData) => {
    try {
      // Check if user is a trader
      if (socket.user.role !== "trader") {
        return socket.emit("error", { message: "Only traders can update trades" })
      }

      // TODO: Process trade update through trade service

      // Broadcast trade update to followers
      io.to(`trader:${socket.user._id}`).emit("trade:updated", {
        traderId: socket.user._id,
        trade: {
          // Updated trade data would come from the trade service
          id: tradeData.id,
          status: tradeData.status,
          exitPrice: tradeData.exitPrice,
          profit: tradeData.profit,
          updatedAt: new Date().toISOString(),
        },
      })

      logger.info(`Trader ${socket.user._id} updated trade ${tradeData.id}`)
    } catch (error) {
      logger.error("Error in trade:update:", error)
      socket.emit("error", { message: "Failed to update trade" })
    }
  })
}

module.exports = tradeHandler
