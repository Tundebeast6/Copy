/**
 * Custom Error Classes
 *
 * This file defines custom error classes for the application.
 */

/**
 * API Error class for handling HTTP errors
 * @extends Error
 */
class ApiError extends Error {
  /**
   * Create an API error
   * @param {number} statusCode - HTTP status code
   * @param {string} message - Error message
   * @param {Array} errors - Array of validation errors
   */
  constructor(statusCode, message, errors = []) {
    super(message)
    this.statusCode = statusCode
    this.name = this.constructor.name
    this.errors = errors

    Error.captureStackTrace(this, this.constructor)
  }
}

/**
 * Not Found Error class
 * @extends ApiError
 */
class NotFoundError extends ApiError {
  /**
   * Create a not found error
   * @param {string} message - Error message
   */
  constructor(message = "Resource not found") {
    super(404, message)
  }
}

/**
 * Unauthorized Error class
 * @extends ApiError
 */
class UnauthorizedError extends ApiError {
  /**
   * Create an unauthorized error
   * @param {string} message - Error message
   */
  constructor(message = "Unauthorized") {
    super(401, message)
  }
}

/**
 * Forbidden Error class
 * @extends ApiError
 */
class ForbiddenError extends ApiError {
  /**
   * Create a forbidden error
   * @param {string} message - Error message
   */
  constructor(message = "Forbidden") {
    super(403, message)
  }
}

/**
 * Bad Request Error class
 * @extends ApiError
 */
class BadRequestError extends ApiError {
  /**
   * Create a bad request error
   * @param {string} message - Error message
   * @param {Array} errors - Array of validation errors
   */
  constructor(message = "Bad request", errors = []) {
    super(400, message, errors)
  }
}

/**
 * Conflict Error class
 * @extends ApiError
 */
class ConflictError extends ApiError {
  /**
   * Create a conflict error
   * @param {string} message - Error message
   */
  constructor(message = "Conflict") {
    super(409, message)
  }
}

module.exports = {
  ApiError,
  NotFoundError,
  UnauthorizedError,
  ForbiddenError,
  BadRequestError,
  ConflictError,
}
