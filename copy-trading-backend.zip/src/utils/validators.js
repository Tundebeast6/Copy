/**
 * Validation Schemas
 *
 * This file defines Joi validation schemas for request data.
 */

const Joi = require("joi")

// Auth validation schemas
const authValidation = {
  register: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().min(8).required(),
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    role: Joi.string().valid("admin", "trader", "follower"),
  }),

  login: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
  }),

  refreshToken: Joi.object({
    refreshToken: Joi.string().required(),
  }),

  verifyEmail: Joi.object({
    token: Joi.string().required(),
  }),

  forgotPassword: Joi.object({
    email: Joi.string().email().required(),
  }),

  resetPassword: Joi.object({
    token: Joi.string().required(),
    password: Joi.string().min(8).required(),
  }),
}

// User validation schemas
const userValidation = {
  updateProfile: Joi.object({
    firstName: Joi.string(),
    lastName: Joi.string(),
    phoneNumber: Joi.string(),
    country: Joi.string(),
    profilePicture: Joi.string(),
  }),

  changePassword: Joi.object({
    currentPassword: Joi.string().required(),
    newPassword: Joi.string().min(8).required(),
  }),

  enableTwoFactor: Joi.object({
    code: Joi.string().required(),
  }),
}

// Trader validation schemas
const traderValidation = {
  createProfile: Joi.object({
    bio: Joi.string().max(500),
    experience: Joi.string().valid("beginner", "intermediate", "advanced", "professional"),
    tradingStyle: Joi.string().valid("day", "swing", "position", "scalping", "algorithmic"),
    riskLevel: Joi.string().valid("conservative", "moderate", "aggressive"),
    performanceFee: Joi.number().min(0).max(50),
    preferredAssets: Joi.array().items(
      Joi.string().valid("stocks", "options", "forex", "crypto", "futures", "commodities"),
    ),
    socialLinks: Joi.object({
      twitter: Joi.string(),
      linkedin: Joi.string(),
      website: Joi.string(),
    }),
  }),

  updateProfile: Joi.object({
    bio: Joi.string().max(500),
    experience: Joi.string().valid("beginner", "intermediate", "advanced", "professional"),
    tradingStyle: Joi.string().valid("day", "swing", "position", "scalping", "algorithmic"),
    riskLevel: Joi.string().valid("conservative", "moderate", "aggressive"),
    performanceFee: Joi.number().min(0).max(50),
    preferredAssets: Joi.array().items(
      Joi.string().valid("stocks", "options", "forex", "crypto", "futures", "commodities"),
    ),
    socialLinks: Joi.object({
      twitter: Joi.string(),
      linkedin: Joi.string(),
      website: Joi.string(),
    }),
  }),

  followTrader: Joi.object({
    copySettings: Joi.object({
      multiplier: Joi.number().min(0.1).max(10),
      fixedQuantity: Joi.number().min(0),
      maxPositionSize: Joi.number().min(0),
      maxRiskPerTrade: Joi.number().min(0).max(100),
      stopLossMultiplier: Joi.number().min(0.1).max(10),
      takeProfitMultiplier: Joi.number().min(0.1).max(10),
    }),
  }),
}

// Broker validation schemas
const brokerValidation = {
  connect: Joi.object({
    name: Joi.string().valid("schwab", "tastytrade", "oanda", "binance").required(),
    label: Joi.string().required(),
    accountId: Joi.string().required(),
    accountType: Joi.string().valid("demo", "live").default("demo"),
    credentials: Joi.object({
      apiKey: Joi.string().when("name", {
        is: Joi.string().valid("oanda", "binance"),
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
      apiSecret: Joi.string().when("name", {
        is: "binance",
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
      accessToken: Joi.string().when("name", {
        is: Joi.string().valid("schwab", "tastytrade"),
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
      refreshToken: Joi.string().when("name", {
        is: Joi.string().valid("schwab", "tastytrade"),
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
      tokenExpiry: Joi.date().when("name", {
        is: Joi.string().valid("schwab", "tastytrade"),
        then: Joi.required(),
        otherwise: Joi.optional(),
      }),
    }).required(),
    supportedAssets: Joi.array().items(
      Joi.string().valid("stocks", "options", "forex", "crypto", "futures", "commodities"),
    ),
  }),

  update: Joi.object({
    label: Joi.string(),
    isActive: Joi.boolean(),
    credentials: Joi.object({
      apiKey: Joi.string(),
      apiSecret: Joi.string(),
      accessToken: Joi.string(),
      refreshToken: Joi.string(),
      tokenExpiry: Joi.date(),
    }),
    supportedAssets: Joi.array().items(
      Joi.string().valid("stocks", "options", "forex", "crypto", "futures", "commodities"),
    ),
  }),
}

// Trade validation schemas
const tradeValidation = {
  createTrade: Joi.object({
    brokerId: Joi.string().required(),
    symbol: Joi.string().required(),
    assetClass: Joi.string().valid("stock", "option", "forex", "crypto", "future", "commodity").required(),
    direction: Joi.string().valid("long", "short").required(),
    orderType: Joi.string().valid("market", "limit", "stop", "stop_limit").default("market"),
    quantity: Joi.number().min(0).required(),
    entryPrice: Joi.number().min(0),
    stopLoss: Joi.number().min(0),
    takeProfit: Joi.number().min(0),
    notes: Joi.string().max(500),
    tags: Joi.array().items(Joi.string()),
    isPublic: Joi.boolean().default(true),
  }),

  updateTrade: Joi.object({
    stopLoss: Joi.number().min(0),
    takeProfit: Joi.number().min(0),
    notes: Joi.string().max(500),
    tags: Joi.array().items(Joi.string()),
    isPublic: Joi.boolean(),
  }),

  closeTrade: Joi.object({
    exitPrice: Joi.number().min(0).required(),
  }),

  copyTrade: Joi.object({
    copySettings: Joi.object({
      multiplier: Joi.number().min(0.1).max(10),
      fixedQuantity: Joi.number().min(0),
    }),
  }),
}

module.exports = {
  authValidation,
  userValidation,
  traderValidation,
  brokerValidation,
  tradeValidation,
}
