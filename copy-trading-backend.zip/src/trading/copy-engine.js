/**
 * Copy Trading Engine
 *
 * This file contains the core logic for copying trades from traders to followers.
 */

const logger = require("../config/logger")

/**
 * Copy Trading Engine class
 */
class CopyTradingEngine {
  constructor() {
    this.activeFollowers = new Map() // Map of follower ID to array of trader IDs they follow
    this.traderPositions = new Map() // Map of trader ID to their open positions
    this.followerSettings = new Map() // Map of follower ID to their copy settings per trader
  }

  /**
   * Initialize the copy trading engine
   */
  async initialize() {
    try {
      logger.info("Initializing copy trading engine")

      // TODO: Load active followers and their settings from database
      // TODO: Load trader positions from database

      logger.info("Copy trading engine initialized successfully")
    } catch (error) {
      logger.error("Error initializing copy trading engine:", error)
      throw error
    }
  }

  /**
   * Process a new trade from a trader
   * @param {string} traderId - Trader ID
   * @param {Object} trade - Trade data
   */
  async processTrade(traderId, trade) {
    try {
      logger.info(`Processing trade from trader ${traderId}`)

      // Get followers for this trader
      const followers = this.getFollowersForTrader(traderId)

      if (!followers || followers.length === 0) {
        logger.info(`No followers for trader ${traderId}`)
        return
      }

      // Process trade for each follower
      for (const followerId of followers) {
        await this.copyTradeToFollower(traderId, followerId, trade)
      }

      // Update trader positions
      this.updateTraderPosition(traderId, trade)

      logger.info(`Trade processed successfully for trader ${traderId}`)
    } catch (error) {
      logger.error(`Error processing trade for trader ${traderId}:`, error)
      throw error
    }
  }

  /**
   * Get followers for a trader
   * @param {string} traderId - Trader ID
   * @returns {string[]} Array of follower IDs
   */
  getFollowersForTrader(traderId) {
    const followers = []

    // Iterate through activeFollowers map
    for (const [followerId, traderIds] of this.activeFollowers.entries()) {
      if (traderIds.includes(traderId)) {
        followers.push(followerId)
      }
    }

    return followers
  }

  /**
   * Copy a trade to a follower
   * @param {string} traderId - Trader ID
   * @param {string} followerId - Follower ID
   * @param {Object} trade - Trade data
   */
  async copyTradeToFollower(traderId, followerId, trade) {
    try {
      logger.info(`Copying trade from trader ${traderId} to follower ${followerId}`)

      // Get follower settings for this trader
      const settings = this.getFollowerSettings(followerId, traderId)

      if (!settings) {
        logger.warn(`No settings found for follower ${followerId} and trader ${traderId}`)
        return
      }

      // Apply risk management
      const adjustedTrade = this.applyRiskManagement(trade, settings)

      // TODO: Execute trade through broker adapter

      logger.info(`Trade copied successfully from trader ${traderId} to follower ${followerId}`)
    } catch (error) {
      logger.error(`Error copying trade from trader ${traderId} to follower ${followerId}:`, error)
      throw error
    }
  }

  /**
   * Get follower settings for a trader
   * @param {string} followerId - Follower ID
   * @param {string} traderId - Trader ID
   * @returns {Object} Follower settings
   */
  getFollowerSettings(followerId, traderId) {
    const followerSettings = this.followerSettings.get(followerId)

    if (!followerSettings) {
      return null
    }

    return followerSettings[traderId]
  }

  /**
   * Apply risk management to a trade
   * @param {Object} trade - Trade data
   * @param {Object} settings - Follower settings
   * @returns {Object} Adjusted trade
   */
  applyRiskManagement(trade, settings) {
    // Clone trade
    const adjustedTrade = { ...trade }

    // Apply multiplier
    if (settings.multiplier) {
      adjustedTrade.quantity = trade.quantity * settings.multiplier
    }

    // Apply fixed lot size
    if (settings.fixedLotSize) {
      adjustedTrade.quantity = settings.fixedLotSize
    }

    // Apply max position size
    if (settings.maxPositionSize && adjustedTrade.quantity > settings.maxPositionSize) {
      adjustedTrade.quantity = settings.maxPositionSize
    }

    return adjustedTrade
  }

  /**
   * Update trader position
   * @param {string} traderId - Trader ID
   * @param {Object} trade - Trade data
   */
  updateTraderPosition(traderId, trade) {
    let positions = this.traderPositions.get(traderId) || []

    // If trade is opening a position
    if (trade.action === "open") {
      positions.push(trade)
    }
    // If trade is closing a position
    else if (trade.action === "close") {
      positions = positions.filter((position) => position.id !== trade.positionId)
    }

    this.traderPositions.set(traderId, positions)
  }

  /**
   * Add a follower to a trader
   * @param {string} followerId - Follower ID
   * @param {string} traderId - Trader ID
   * @param {Object} settings - Copy settings
   */
  addFollower(followerId, traderId, settings) {
    // Update activeFollowers map
    const traderIds = this.activeFollowers.get(followerId) || []

    if (!traderIds.includes(traderId)) {
      traderIds.push(traderId)
      this.activeFollowers.set(followerId, traderIds)
    }

    // Update followerSettings map
    const followerSettings = this.followerSettings.get(followerId) || {}
    followerSettings[traderId] = settings
    this.followerSettings.set(followerId, followerSettings)

    logger.info(`Follower ${followerId} added to trader ${traderId}`)
  }

  /**
   * Remove a follower from a trader
   * @param {string} followerId - Follower ID
   * @param {string} traderId - Trader ID
   */
  removeFollower(followerId, traderId) {
    // Update activeFollowers map
    const traderIds = this.activeFollowers.get(followerId) || []
    const index = traderIds.indexOf(traderId)

    if (index !== -1) {
      traderIds.splice(index, 1)
      this.activeFollowers.set(followerId, traderIds)
    }

    // Update followerSettings map
    const followerSettings = this.followerSettings.get(followerId) || {}
    delete followerSettings[traderId]
    this.followerSettings.set(followerId, followerSettings)

    logger.info(`Follower ${followerId} removed from trader ${traderId}`)
  }
}

module.exports = new CopyTradingEngine()
