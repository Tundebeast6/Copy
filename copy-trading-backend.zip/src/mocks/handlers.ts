import { rest } from "msw"

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api"

export const handlers = [
  // Auth handlers
  rest.post(`${API_URL}/auth/login`, (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({
        success: true,
        message: "Login successful",
        data: {
          user: {
            id: "user-123",
            email: "user@example.com",
            firstName: "John",
            lastName: "Doe",
            role: "follower",
            isEmailVerified: true,
            isKycVerified: false,
            createdAt: "2023-01-01T00:00:00.000Z",
            updatedAt: "2023-01-01T00:00:00.000Z",
          },
          token: "mock-token",
          refreshToken: "mock-refresh-token",
        },
      }),
    )
  }),

  rest.post(`${API_URL}/auth/register`, (req, res, ctx) => {
    return res(
      ctx.status(201),
      ctx.json({
        success: true,
        message: "User registered successfully",
        data: {
          user: {
            id: "user-123",
            email: "user@example.com",
            firstName: "John",
            lastName: "Doe",
            role: "follower",
            isEmailVerified: false,
            isKycVerified: false,
            createdAt: "2023-01-01T00:00:00.000Z",
            updatedAt: "2023-01-01T00:00:00.000Z",
          },
          token: "mock-token",
          refreshToken: "mock-refresh-token",
        },
      }),
    )
  }),

  rest.get(`${API_URL}/auth/me`, (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({
        success: true,
        data: {
          user: {
            id: "user-123",
            email: "user@example.com",
            firstName: "John",
            lastName: "Doe",
            role: "follower",
            isEmailVerified: true,
            isKycVerified: false,
            createdAt: "2023-01-01T00:00:00.000Z",
            updatedAt: "2023-01-01T00:00:00.000Z",
          },
        },
      }),
    )
  }),

  // Traders handlers
  rest.get(`${API_URL}/traders`, (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({
        success: true,
        data: {
          traders: [
            {
              _id: "trader-123",
              userId: {
                _id: "user-456",
                firstName: "Jane",
                lastName: "Smith",
                email: "jane@example.com",
                profilePicture: "https://example.com/avatar.jpg",
              },
              bio: "Experienced forex trader with 5+ years of experience.",
              experience: "advanced",
              tradingStyle: "swing",
              riskLevel: "moderate",
              performanceFee: 20,
              isVerified: true,
              isActive: true,
              followers: ["user-123"],
              followersCount: 1,
              totalTrades: 150,
              winRate: 68.5,
              averageProfit: 3.2,
              profitLossRatio: 2.1,
              maxDrawdown: 15.3,
              preferredAssets: ["forex", "crypto"],
              socialLinks: {
                twitter: "https://twitter.com/janesmith",
                linkedin: "https://linkedin.com/in/janesmith",
              },
              createdAt: "2022-01-01T00:00:00.000Z",
              updatedAt: "2023-01-01T00:00:00.000Z",
            },
          ],
          pagination: {
            total: 1,
            page: 1,
            limit: 10,
            pages: 1,
          },
        },
      }),
    )
  }),

  // Portfolio handlers
  rest.get(`${API_URL}/users/portfolio`, (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({
        success: true,
        data: {
          _id: "portfolio-123",
          userId: "user-123",
          balance: 10000,
          equity: 12500,
          allocatedBalance: 8000,
          availableBalance: 2000,
          currency: "USD",
          positions: [
            {
              symbol: "EURUSD",
              assetClass: "forex",
              direction: "long",
              quantity: 1000,
              entryPrice: 1.1,
              currentPrice: 1.12,
              marketValue: 1120,
              unrealizedPL: 20,
              unrealizedPLPercent: 1.82,
              openTime: "2023-01-15T00:00:00.000Z",
              trades: ["trade-123"],
            },
          ],
          performance: {
            daily: {
              date: "2023-01-01T00:00:00.000Z",
              balance: 10000,
              profit: 100,
              profitPercent: 1,
            },
            weekly: {
              startDate: "2022-12-25T00:00:00.000Z",
              endDate: "2023-01-01T00:00:00.000Z",
              balance: 10000,
              profit: 300,
              profitPercent: 3,
            },
            monthly: {
              month: 0,
              year: 2023,
              balance: 10000,
              profit: 500,
              profitPercent: 5,
            },
            yearly: {
              year: 2023,
              balance: 10000,
              profit: 500,
              profitPercent: 5,
            },
            allTime: {
              startDate: "2022-01-01T00:00:00.000Z",
              balance: 10000,
              profit: 2500,
              profitPercent: 25,
            },
          },
          stats: {
            totalTrades: 50,
            winningTrades: 35,
            losingTrades: 15,
            winRate: 70,
            averageWin: 100,
            averageLoss: 50,
            profitFactor: 2,
            maxDrawdown: 10,
            sharpeRatio: 1.5,
          },
          lastUpdated: "2023-01-01T00:00:00.000Z",
          createdAt: "2022-01-01T00:00:00.000Z",
          updatedAt: "2023-01-01T00:00:00.000Z",
        },
      }),
    )
  }),
]
