"use client"

import { render, screen, waitFor, act } from "@testing-library/react"
import userEvent from "@testing-library/user-event"
import { AuthProvider, useAuth } from "./AuthContext"
import { api } from "../services/api"

// Mock the API module
jest.mock("../services/api", () => ({
  api: {
    get: jest.fn(),
    post: jest.fn(),
    defaults: {
      headers: {
        common: {
          Authorization: "",
        },
      },
    },
  },
}))

// Test component that uses the auth context
const TestComponent = () => {
  const { user, loading, login, logout } = useAuth()

  return (
    <div>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <>
          {user ? (
            <>
              <p>Logged in as: {user.email}</p>
              <button onClick={logout}>Logout</button>
            </>
          ) : (
            <button onClick={() => login("test@example.com", "password")}>Login</button>
          )}
        </>
      )}
    </div>
  )
}

describe("AuthContext", () => {
  beforeEach(() => {
    // Clear localStorage
    localStorage.clear()

    // Reset mocks
    jest.clearAllMocks()
  })

  test("should show loading state initially", () => {
    // Mock API response for auth check
    ;(api.get as jest.Mock).mockResolvedValueOnce({
      data: {
        data: {
          user: {
            id: "user-123",
            email: "test@example.com",
            firstName: "Test",
            lastName: "User",
            role: "follower",
          },
        },
      },
    })

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>,
    )

    expect(screen.getByText("Loading...")).toBeInTheDocument()
  })

  test("should check for existing token on mount", async () => {
    // Set token in localStorage
    localStorage.setItem("token", "test-token")

    // Mock API response for auth check
    ;(api.get as jest.Mock).mockResolvedValueOnce({
      data: {
        data: {
          user: {
            id: "user-123",
            email: "test@example.com",
            firstName: "Test",
            lastName: "User",
            role: "follower",
          },
        },
      },
    })

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>,
    )

    // Wait for auth check to complete
    await waitFor(() => {
      expect(screen.getByText("Logged in as: test@example.com")).toBeInTheDocument()
    })

    // Verify API was called with correct auth header
    expect(api.get).toHaveBeenCalledWith("/auth/me")
    expect(api.defaults.headers.common.Authorization).toBe("Bearer test-token")
  })

  test("should handle login correctly", async () => {
    // Mock API response for login
    ;(api.post as jest.Mock).mockResolvedValueOnce({
      data: {
        data: {
          token: "new-token",
          refreshToken: "new-refresh-token",
          user: {
            id: "user-123",
            email: "test@example.com",
            firstName: "Test",
            lastName: "User",
            role: "follower",
          },
        },
      },
    })

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>,
    )

    // Wait for initial auth check to complete
    await waitFor(() => {
      expect(screen.getByText("Login")).toBeInTheDocument()
    })

    // Click login button
    await act(async () => {
      userEvent.click(screen.getByText("Login"))
    })

    // Wait for login to complete
    await waitFor(() => {
      expect(screen.getByText("Logged in as: test@example.com")).toBeInTheDocument()
    })

    // Verify API was called correctly
    expect(api.post).toHaveBeenCalledWith("/auth/login", {
      email: "test@example.com",
      password: "password",
    })

    // Verify tokens were stored
    expect(localStorage.getItem("token")).toBe("new-token")
    expect(localStorage.getItem("refreshToken")).toBe("new-refresh-token")

    // Verify auth header was set
    expect(api.defaults.headers.common.Authorization).toBe("Bearer new-token")
  })

  test("should handle logout correctly", async () => {
    // Set initial state as logged in
    localStorage.setItem("token", "test-token")
    localStorage.setItem("refreshToken", "test-refresh-token")

    // Mock API response for auth check
    ;(api.get as jest.Mock).mockResolvedValueOnce({
      data: {
        data: {
          user: {
            id: "user-123",
            email: "test@example.com",
            firstName: "Test",
            lastName: "User",
            role: "follower",
          },
        },
      },
    })

    render(
      <AuthProvider>
        <TestComponent />
      </AuthProvider>,
    )

    // Wait for auth check to complete
    await waitFor(() => {
      expect(screen.getByText("Logged in as: test@example.com")).toBeInTheDocument()
    })

    // Click logout button
    await act(async () => {
      userEvent.click(screen.getByText("Logout"))
    })

    // Verify user is logged out
    await waitFor(() => {
      expect(screen.getByText("Login")).toBeInTheDocument()
    })

    // Verify tokens were removed
    expect(localStorage.getItem("token")).toBeNull()
    expect(localStorage.getItem("refreshToken")).toBeNull()

    // Verify auth header was cleared
    expect(api.defaults.headers.common.Authorization).toBe("")
  })
})
