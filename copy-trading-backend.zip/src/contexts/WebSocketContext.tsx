"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { io, type Socket } from "socket.io-client"
import { useAuth } from "./AuthContext"
import type { Trade, MarketData, Notification } from "../types"

interface WebSocketContextType {
  connected: boolean
  subscribeToTrader: (traderId: string) => void
  unsubscribeFromTrader: (traderId: string) => void
  subscribeToMarket: (symbols: string | string[]) => void
  unsubscribeFromMarket: (symbols: string | string[]) => void
  trades: Record<string, Trade[]>
  marketData: Record<string, MarketData>
  notifications: Notification[]
}

const WebSocketContext = createContext<WebSocketContextType | undefined>(undefined)

export const useWebSocket = () => {
  const context = useContext(WebSocketContext)
  if (context === undefined) {
    throw new Error("useWebSocket must be used within a WebSocketProvider")
  }
  return context
}

export const WebSocketProvider = ({ children }: { children: ReactNode }) => {
  const { user, refreshToken } = useAuth()
  const [socket, setSocket] = useState<Socket | null>(null)
  const [connected, setConnected] = useState(false)
  const [trades, setTrades] = useState<Record<string, Trade[]>>({})
  const [marketData, setMarketData] = useState<Record<string, MarketData>>({})
  const [notifications, setNotifications] = useState<Notification[]>([])

  useEffect(() => {
    if (!user) {
      if (socket) {
        socket.disconnect()
        setSocket(null)
        setConnected(false)
      }
      return
    }

    // Initialize socket connection
    const token = localStorage.getItem("token")
    const socketInstance = io(process.env.REACT_APP_API_URL || "http://localhost:5000", {
      auth: { token },
      transports: ["websocket"],
    })

    socketInstance.on("connect", () => {
      console.log("WebSocket connected")
      setConnected(true)
    })

    socketInstance.on("disconnect", () => {
      console.log("WebSocket disconnected")
      setConnected(false)
    })

    socketInstance.on("error", async (error) => {
      console.error("WebSocket error:", error)

      // If error is authentication related, try to refresh token
      if (error.message === "Authentication token expired") {
        const refreshed = await refreshToken()
        if (refreshed) {
          // Reconnect with new token
          socketInstance.auth = { token: localStorage.getItem("token") }
          socketInstance.connect()
        }
      }
    })

    // Handle trade events
    socketInstance.on("trade:new", (data) => {
      setTrades((prev) => {
        const traderId = data.traderId
        const traderTrades = prev[traderId] || []
        return {
          ...prev,
          [traderId]: [data.trade, ...traderTrades],
        }
      })
    })

    socketInstance.on("trade:updated", (data) => {
      setTrades((prev) => {
        const traderId = data.traderId
        const traderTrades = prev[traderId] || []
        const updatedTrades = traderTrades.map((trade) =>
          trade.id === data.trade.id ? { ...trade, ...data.trade } : trade,
        )
        return {
          ...prev,
          [traderId]: updatedTrades,
        }
      })
    })

    // Handle market data events
    socketInstance.on("market:data", (data) => {
      setMarketData((prev) => ({
        ...prev,
        [data.symbol]: data,
      }))
    })

    // Handle notification events
    socketInstance.on("notification:new", (notification) => {
      setNotifications((prev) => [notification, ...prev])
    })

    setSocket(socketInstance)

    // Cleanup on unmount
    return () => {
      socketInstance.disconnect()
    }
  }, [user, refreshToken])

  const subscribeToTrader = (traderId: string) => {
    if (socket && connected) {
      socket.emit("trade:subscribe", traderId)
    }
  }

  const unsubscribeFromTrader = (traderId: string) => {
    if (socket && connected) {
      socket.emit("trade:unsubscribe", traderId)
    }
  }

  const subscribeToMarket = (symbols: string | string[]) => {
    if (socket && connected) {
      socket.emit("market:subscribe", symbols)
    }
  }

  const unsubscribeFromMarket = (symbols: string | string[]) => {
    if (socket && connected) {
      socket.emit("market:unsubscribe", symbols)
    }
  }

  return (
    <WebSocketContext.Provider
      value={{
        connected,
        subscribeToTrader,
        unsubscribeFromTrader,
        subscribeToMarket,
        unsubscribeFromMarket,
        trades,
        marketData,
        notifications,
      }}
    >
      {children}
    </WebSocketContext.Provider>
  )
}
