"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { api } from "../services/api"
import type { User } from "../types"

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  register: (userData: RegisterData) => Promise<void>
  logout: () => void
  refreshToken: () => Promise<boolean>
}

interface RegisterData {
  email: string
  password: string
  firstName: string
  lastName: string
  role?: string
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user is already logged in
    const checkAuth = async () => {
      try {
        const token = localStorage.getItem("token")
        if (!token) {
          setLoading(false)
          return
        }

        // Set default auth header
        api.defaults.headers.common["Authorization"] = `Bearer ${token}`

        // Get current user
        const response = await api.get("/auth/me")
        setUser(response.data.data.user)
      } catch (error) {
        console.error("Authentication check failed:", error)
        localStorage.removeItem("token")
        localStorage.removeItem("refreshToken")
        api.defaults.headers.common["Authorization"] = ""
      } finally {
        setLoading(false)
      }
    }

    checkAuth()
  }, [])

  const login = async (email: string, password: string) => {
    try {
      const response = await api.post("/auth/login", { email, password })
      const { token, refreshToken, user } = response.data.data

      localStorage.setItem("token", token)
      localStorage.setItem("refreshToken", refreshToken)
      api.defaults.headers.common["Authorization"] = `Bearer ${token}`

      setUser(user)
    } catch (error) {
      console.error("Login failed:", error)
      throw error
    }
  }

  const register = async (userData: RegisterData) => {
    try {
      const response = await api.post("/auth/register", userData)
      const { token, refreshToken, user } = response.data.data

      localStorage.setItem("token", token)
      localStorage.setItem("refreshToken", refreshToken)
      api.defaults.headers.common["Authorization"] = `Bearer ${token}`

      setUser(user)
    } catch (error) {
      console.error("Registration failed:", error)
      throw error
    }
  }

  const logout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("refreshToken")
    api.defaults.headers.common["Authorization"] = ""
    setUser(null)
  }

  const refreshToken = async (): Promise<boolean> => {
    try {
      const refreshToken = localStorage.getItem("refreshToken")
      if (!refreshToken) {
        return false
      }

      const response = await api.post("/auth/refresh-token", { refreshToken })
      const { token, newRefreshToken } = response.data.data

      localStorage.setItem("token", token)
      localStorage.setItem("refreshToken", newRefreshToken)
      api.defaults.headers.common["Authorization"] = `Bearer ${token}`

      return true
    } catch (error) {
      console.error("Token refresh failed:", error)
      logout()
      return false
    }
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, refreshToken }}>
      {children}
    </AuthContext.Provider>
  )
}
