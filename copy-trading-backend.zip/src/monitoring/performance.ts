import { captureException } from "./sentry"

// Web Vitals reporting
export const reportWebVitals = (metric: any) => {
  if (process.env.NODE_ENV === "production") {
    // Send to analytics
    if (window.gtag) {
      window.gtag("event", "web_vitals", {
        event_category: "Web Vitals",
        event_label: metric.name,
        value: Math.round(metric.name === "CLS" ? metric.value * 1000 : metric.value),
        non_interaction: true,
      })
    }

    // Log to console in development
  } else {
    console.log(metric)
  }
}

// Performance monitoring
export const measurePerformance = (name: string, fn: () => any) => {
  try {
    const startTime = performance.now()
    const result = fn()
    const endTime = performance.now()
    const duration = endTime - startTime

    // Log performance metric
    if (process.env.NODE_ENV === "production" && window.gtag) {
      window.gtag("event", "performance", {
        event_category: "Performance",
        event_label: name,
        value: Math.round(duration),
        non_interaction: true,
      })
    } else {
      console.log(`Performance [${name}]: ${duration.toFixed(2)}ms`)
    }

    return result
  } catch (error) {
    captureException(error as Error, { performanceMeasure: name })
    throw error
  }
}

// Track API call performance
export const trackApiCall = (endpoint: string, method: string, startTime: number) => {
  const endTime = performance.now()
  const duration = endTime - startTime

  if (process.env.NODE_ENV === "production" && window.gtag) {
    window.gtag("event", "api_call", {
      event_category: "API",
      event_label: `${method} ${endpoint}`,
      value: Math.round(duration),
      non_interaction: true,
    })
  } else {
    console.log(`API Call [${method} ${endpoint}]: ${duration.toFixed(2)}ms`)
  }
}
