// Simple analytics tracking
export const trackEvent = (eventName: string, properties?: Record<string, any>) => {
  if (process.env.NODE_ENV === "production" && window.gtag) {
    window.gtag("event", eventName, properties)
  } else {
    console.log("Analytics Event:", eventName, properties)
  }
}

export const trackPageView = (path: string) => {
  if (process.env.NODE_ENV === "production" && window.gtag) {
    window.gtag("config", process.env.REACT_APP_GA_MEASUREMENT_ID || "", {
      page_path: path,
    })
  } else {
    console.log("Page View:", path)
  }
}

export const trackUserLogin = (userId: string, method: string) => {
  trackEvent("login", { userId, method })
}

export const trackUserRegistration = (userId: string) => {
  trackEvent("registration", { userId })
}

export const trackTradeCreation = (tradeId: string, symbol: string, direction: string) => {
  trackEvent("trade_created", { tradeId, symbol, direction })
}

export const trackTradeClosure = (tradeId: string, profit: number, profitPercentage: number) => {
  trackEvent("trade_closed", { tradeId, profit, profitPercentage })
}

export const trackTraderFollow = (traderId: string, userId: string) => {
  trackEvent("trader_followed", { traderId, userId })
}

export const trackTraderUnfollow = (traderId: string, userId: string) => {
  trackEvent("trader_unfollowed", { traderId, userId })
}

export const trackBrokerConnection = (brokerId: string, brokerName: string) => {
  trackEvent("broker_connected", { brokerId, brokerName })
}
