import * as Sentry from "@sentry/react"
import { BrowserTracing } from "@sentry/tracing"

export const initSentry = () => {
  if (process.env.NODE_ENV === "production" && process.env.REACT_APP_SENTRY_DSN) {
    Sentry.init({
      dsn: process.env.REACT_APP_SENTRY_DSN,
      integrations: [new BrowserTracing()],
      tracesSampleRate: 0.2,
      environment: process.env.NODE_ENV,
      release: process.env.REACT_APP_VERSION || "development",
    })
  }
}

export const captureException = (error: Error, context?: Record<string, any>) => {
  if (process.env.NODE_ENV === "production") {
    Sentry.captureException(error, {
      extra: context,
    })
  } else {
    console.error("Error:", error, "Context:", context)
  }
}

export const setUserContext = (user: { id: string; email: string; role: string }) => {
  Sentry.setUser({
    id: user.id,
    email: user.email,
    role: user.role,
  })
}

export const clearUserContext = () => {
  Sentry.setUser(null)
}
