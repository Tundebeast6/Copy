/**
 * Database Configuration
 *
 * This file handles the MongoDB connection setup and exports
 * functions to connect and disconnect from the database.
 */

const mongoose = require("mongoose")
const config = require("./env")
const logger = require("./logger")

/**
 * Connect to MongoDB
 * @returns {Promise<void>}
 */
const connectDatabase = async () => {
  try {
    await mongoose.connect(config.mongodb.uri, config.mongodb.options)
    logger.info("MongoDB connected successfully")

    // Log when MongoDB connection is lost
    mongoose.connection.on("disconnected", () => {
      logger.warn("MongoDB disconnected")
    })

    // Log MongoDB connection errors
    mongoose.connection.on("error", (err) => {
      logger.error("MongoDB connection error:", err)
    })

    // Log when MongoDB reconnects
    mongoose.connection.on("reconnected", () => {
      logger.info("MongoDB reconnected")
    })

    return mongoose.connection
  } catch (error) {
    logger.error("MongoDB connection error:", error)
    throw error
  }
}

/**
 * Disconnect from MongoDB
 * @returns {Promise<void>}
 */
const disconnectDatabase = async () => {
  try {
    await mongoose.disconnect()
    logger.info("MongoDB disconnected successfully")
  } catch (error) {
    logger.error("Error disconnecting from MongoDB:", error)
    throw error
  }
}

module.exports = {
  connectDatabase,
  disconnectDatabase,
}
