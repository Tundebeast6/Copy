/**
 * Environment Configuration
 *
 * This file validates required environment variables and exports them
 * in a structured format for use throughout the application.
 */

const dotenv = require("dotenv")
const path = require("path")

// Load environment variables from .env file
dotenv.config({ path: path.resolve(process.cwd(), ".env") })

// Required environment variables
const requiredEnvVars = ["NODE_ENV", "PORT", "MONGODB_URI", "JWT_SECRET", "JWT_EXPIRES_IN"]

// Check for missing environment variables
const missingEnvVars = requiredEnvVars.filter((envVar) => !process.env[envVar])

if (missingEnvVars.length > 0) {
  throw new Error(`Missing required environment variables: ${missingEnvVars.join(", ")}`)
}

// Export environment variables
module.exports = {
  // Server configuration
  env: process.env.NODE_ENV || "development",
  port: Number.parseInt(process.env.PORT, 10) || 5000,

  // MongoDB configuration
  mongodb: {
    uri: process.env.MONGODB_URI,
    options: {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    },
  },

  // JWT configuration
  jwt: {
    secret: process.env.JWT_SECRET,
    expiresIn: process.env.JWT_EXPIRES_IN || "1d",
    refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || "7d",
  },

  // CORS configuration
  cors: {
    origin: process.env.CORS_ORIGIN || "*",
  },

  // Broker API keys
  brokers: {
    schwab: {
      clientId: process.env.SCHWAB_CLIENT_ID,
      clientSecret: process.env.SCHWAB_CLIENT_SECRET,
      redirectUri: process.env.SCHWAB_REDIRECT_URI,
    },
    tastytrade: {
      baseUrl: process.env.TASTYTRADE_BASE_URL,
    },
    oanda: {
      apiKey: process.env.OANDA_API_KEY,
      baseUrl: process.env.OANDA_BASE_URL || "https://api-fxpractice.oanda.com",
    },
    binance: {
      baseUrl: process.env.BINANCE_BASE_URL || "https://api.binance.com",
    },
  },

  // Notification services
  notifications: {
    email: {
      host: process.env.EMAIL_HOST,
      port: Number.parseInt(process.env.EMAIL_PORT, 10) || 587,
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
      from: process.env.EMAIL_FROM,
    },
    sms: {
      twilioAccountSid: process.env.TWILIO_ACCOUNT_SID,
      twilioAuthToken: process.env.TWILIO_AUTH_TOKEN,
      twilioPhoneNumber: process.env.TWILIO_PHONE_NUMBER,
    },
  },

  // Redis configuration (for caching and WebSocket state)
  redis: {
    host: process.env.REDIS_HOST || "localhost",
    port: Number.parseInt(process.env.REDIS_PORT, 10) || 6379,
    password: process.env.REDIS_PASSWORD,
  },
}
