/**
 * Express Application Setup
 *
 * This file configures the Express application with middleware,
 * routes, and error handling for the copy trading platform.
 */

const express = require("express")
const cors = require("cors")
const helmet = require("helmet")
const compression = require("compression")
const morgan = require("morgan")
const rateLimit = require("express-rate-limit")

const apiRoutes = require("./api")
const errorMiddleware = require("./api/middlewares/error.middleware")
const logger = require("./config/logger")

// Initialize express app
const app = express()

// Apply security headers
app.use(helmet())

// Enable CORS
app.use(
  cors({
    origin: process.env.CORS_ORIGIN || "*",
    methods: ["GET", "POST", "PUT", "DELETE", "PATCH"],
    allowedHeaders: ["Content-Type", "Authorization"],
  }),
)

// Parse JSON request body
app.use(express.json({ limit: "1mb" }))

// Parse URL-encoded request body
app.use(express.urlencoded({ extended: true, limit: "1mb" }))

// Compress responses
app.use(compression())

// Request logging
app.use(morgan("combined", { stream: { write: (message) => logger.info(message.trim()) } }))

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
  message: "Too many requests from this IP, please try again after 15 minutes",
})
app.use("/api/", limiter)

// Health check endpoint
app.get("/health", (req, res) => {
  res.status(200).json({ status: "ok", timestamp: new Date().toISOString() })
})

// API routes
app.use("/api", apiRoutes)

// 404 handler
app.use((req, res, next) => {
  res.status(404).json({
    success: false,
    message: `Cannot ${req.method} ${req.originalUrl}`,
    error: "Not Found",
  })
})

// Error handling middleware
app.use(errorMiddleware)

module.exports = app
